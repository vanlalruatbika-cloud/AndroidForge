package com.example

import com.example.archive.ArchiveListingResult
import com.example.archive.ArchiveRepository
import com.example.utils.FileCategory
import com.example.utils.FormatUtils
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class HzFileManagerUnitTest {

  @get:Rule
  val tempFolder = TemporaryFolder()

  @Test
  fun formatAndClassification_workAccurately() {
    assertEquals("1.5 KB", FormatUtils.formatFileSize(1536L))
    assertEquals(FileCategory.ARCHIVE, FormatUtils.classifyName("backup.7z", false))
    assertEquals(FileCategory.IMAGE, FormatUtils.classifyName("wallpaper.webp", false))
    assertEquals(FileCategory.PDF, FormatUtils.classifyName("manual.pdf", false))
    assertEquals(FileCategory.APK, FormatUtils.classifyName("hz_release.apk", false))
  }

  @Test
  fun archiveRepository_createsInspectsAndExtractsZipAnd7z() = runBlocking {
    val repo = ArchiveRepository()
    val srcDir = tempFolder.newFolder("source_docs")
    val fileA = File(srcDir, "hello.txt").apply { writeText("Hello Huzuni Liquid Glass!") }
    val fileB = File(srcDir, "nested.json").apply { writeText("{\"app\":\"Hz\"}") }

    // Test ZIP round-trip
    val zipOut = File(tempFolder.root, "test_pack.zip")
    val zipCreate = repo.createZipArchive(listOf(fileA, fileB), zipOut.absolutePath)
    assertTrue(zipCreate.success)
    assertTrue(zipOut.exists() && zipOut.length() > 0)

    val zipInspect = repo.inspectArchive(zipOut.absolutePath)
    assertTrue(zipInspect is ArchiveListingResult.Success)
    val zipSuccess = zipInspect as ArchiveListingResult.Success
    assertEquals(2, zipSuccess.entries.size)

    val extractZipDir = tempFolder.newFolder("extracted_zip")
    val zipExtract = repo.extractArchive(zipOut.absolutePath, extractZipDir.absolutePath, setOf("hello.txt"))
    assertTrue(zipExtract.success)
    assertEquals("Hello Huzuni Liquid Glass!", File(extractZipDir, "hello.txt").readText())
    assertTrue(!File(extractZipDir, "nested.json").exists())

    // Test 7Z round-trip
    val sevenZOut = File(tempFolder.root, "test_pack.7z")
    val sevenZCreate = repo.createSevenZArchive(listOf(srcDir), sevenZOut.absolutePath)
    assertTrue(sevenZCreate.success)
    assertTrue(sevenZOut.exists() && sevenZOut.length() > 0)

    val sevenZInspect = repo.inspectArchive(sevenZOut.absolutePath)
    assertTrue(sevenZInspect is ArchiveListingResult.Success)
    val extract7zDir = tempFolder.newFolder("extracted_7z")
    val sevenZExtract = repo.extractArchive(sevenZOut.absolutePath, extract7zDir.absolutePath)
    assertTrue(sevenZExtract.success)
    assertEquals("Hello Huzuni Liquid Glass!", File(extract7zDir, "source_docs/hello.txt").readText())
  }
}
