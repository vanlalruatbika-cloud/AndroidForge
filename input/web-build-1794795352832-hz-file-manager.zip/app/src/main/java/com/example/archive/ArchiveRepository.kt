package com.example.archive

import android.os.Environment
import com.example.data.ArchiveEntryItem
import com.example.data.ArchiveInfo
import com.example.data.FileItem
import com.example.data.OperationProgress
import com.example.utils.FileCategory
import com.example.utils.FormatUtils
import com.github.junrar.Archive
import com.github.junrar.exception.UnsupportedRarV5Exception
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.apache.commons.compress.archivers.sevenz.SevenZFile
import org.apache.commons.compress.archivers.sevenz.SevenZOutputFile
import org.apache.commons.compress.archivers.tar.TarArchiveInputStream
import org.apache.commons.compress.compressors.bzip2.BZip2CompressorInputStream
import org.apache.commons.compress.compressors.gzip.GzipCompressorInputStream
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

sealed interface ArchiveListingResult {
  data class Success(val info: ArchiveInfo, val entries: List<ArchiveEntryItem>) : ArchiveListingResult
  data class Unsupported(val format: String, val reason: String) : ArchiveListingResult
  data class Error(val message: String) : ArchiveListingResult
}

data class ArchiveOpResult(
  val success: Boolean,
  val message: String,
  val outputPath: String? = null,
)

class ArchiveRepository {

  suspend fun discoverArchives(showHidden: Boolean = false): List<FileItem> =
    withContext(Dispatchers.IO) {
      val root = Environment.getExternalStorageDirectory()
      if (!root.exists() || !root.canRead()) return@withContext emptyList()

      val archives = mutableListOf<FileItem>()
      val stack = ArrayDeque<Pair<File, Int>>()
      stack.add(root to 0)
      var visited = 0

      while (stack.isNotEmpty() && visited < 2000) {
        val (dir, depth) = stack.removeLast()
        visited++
        val children = dir.listFiles() ?: continue
        for (child in children) {
          if (!showHidden && child.name.startsWith(".")) continue
          if (child.isDirectory) {
            val norm = child.absolutePath.replace('\\', '/')
            if (norm.endsWith("/Android/data") || norm.endsWith("/Android/obb")) continue
            if (depth < 6) stack.add(child to depth + 1)
          } else if (FormatUtils.classifyFile(child) == FileCategory.ARCHIVE) {
            archives.add(
              FileItem(
                path = child.absolutePath,
                name = child.name,
                isDirectory = false,
                sizeBytes = child.length(),
                lastModified = child.lastModified(),
                category = FileCategory.ARCHIVE,
                extension = FormatUtils.getExtension(child.name),
                isHidden = child.isHidden || child.name.startsWith("."),
                canRead = child.canRead(),
                canWrite = child.canWrite(),
              ),
            )
          }
        }
      }

      archives.sortedByDescending { it.lastModified }
    }

  suspend fun inspectArchive(archivePath: String): ArchiveListingResult = withContext(Dispatchers.IO) {
    val file = File(archivePath)
    if (!file.exists() || !file.canRead()) {
      return@withContext ArchiveListingResult.Error("Archive file cannot be read or does not exist.")
    }

    val ext = FormatUtils.getExtension(file.name)
    return@withContext when {
      ext == "zip" || ext == "jar" || ext == "apks" || ext == "xapk" -> inspectZip(file)
      ext == "7z" -> inspectSevenZ(file)
      ext == "tar" || ext == "gz" || ext == "tgz" || ext == "bz2" || file.name.lowercase().endsWith(".tar.gz") ||
        file.name.lowercase().endsWith(".tar.bz2") -> inspectTarLike(file)
      ext == "rar" -> inspectRar(file)
      else -> ArchiveListingResult.Unsupported(
        format = ext.uppercase(),
        reason = "The .$ext archive format is not supported in this offline edition.",
      )
    }
  }

  private fun inspectZip(file: File): ArchiveListingResult {
    return try {
      ZipFile(file).use { zip ->
        val entries = mutableListOf<ArchiveEntryItem>()
        var uncompressed = 0L
        val enumEntries = zip.entries()
        while (enumEntries.hasMoreElements()) {
          val e = enumEntries.nextElement()
          val size = e.size.coerceAtLeast(0L)
          if (!e.isDirectory) uncompressed += size
          entries.add(
            ArchiveEntryItem(
              fullPath = e.name,
              name = e.name.trimEnd('/').substringAfterLast('/'),
              isDirectory = e.isDirectory,
              compressedSize = e.compressedSize.coerceAtLeast(0L),
              uncompressedSize = size,
              lastModified = e.time,
            ),
          )
        }
        ArchiveListingResult.Success(
          info = ArchiveInfo(
            path = file.absolutePath,
            name = file.name,
            format = "ZIP",
            fileSizeBytes = file.length(),
            uncompressedBytes = uncompressed,
            entryCount = entries.size,
            isSupported = true,
          ),
          entries = entries,
        )
      }
    } catch (e: Exception) {
      ArchiveListingResult.Error("Failed to open ZIP archive: ${e.message ?: "corrupted or encrypted"}")
    }
  }

  private fun inspectSevenZ(file: File): ArchiveListingResult {
    return try {
      SevenZFile.builder().setFile(file).get().use { sz ->
        val entries = mutableListOf<ArchiveEntryItem>()
        var uncompressed = 0L
        var entry = sz.nextEntry
        while (entry != null) {
          val size = entry.size.coerceAtLeast(0L)
          if (!entry.isDirectory) uncompressed += size
          entries.add(
            ArchiveEntryItem(
              fullPath = entry.name,
              name = entry.name.trimEnd('/').substringAfterLast('/'),
              isDirectory = entry.isDirectory,
              compressedSize = 0L,
              uncompressedSize = size,
              lastModified = if (entry.hasLastModifiedDate) entry.lastModifiedDate.time else 0L,
            ),
          )
          entry = sz.nextEntry
        }
        ArchiveListingResult.Success(
          info = ArchiveInfo(
            path = file.absolutePath,
            name = file.name,
            format = "7Z",
            fileSizeBytes = file.length(),
            uncompressedBytes = uncompressed,
            entryCount = entries.size,
            isSupported = true,
          ),
          entries = entries,
        )
      }
    } catch (e: Exception) {
      ArchiveListingResult.Error("Unable to read 7z archive (password-protected or unsupported codec): ${e.message}")
    }
  }

  private fun inspectTarLike(file: File): ArchiveListingResult {
    val lower = file.name.lowercase()
    return try {
      val baseStream = BufferedInputStream(FileInputStream(file))
      val tarStream = when {
        lower.endsWith(".tar.gz") || lower.endsWith(".tgz") ->
          TarArchiveInputStream(GzipCompressorInputStream(baseStream))
        lower.endsWith(".tar.bz2") || lower.endsWith(".tbz2") ->
          TarArchiveInputStream(BZip2CompressorInputStream(baseStream))
        lower.endsWith(".tar") -> TarArchiveInputStream(baseStream)
        lower.endsWith(".gz") -> {
          baseStream.close()
          val innerName = file.name.dropLast(3)
          return ArchiveListingResult.Success(
            info = ArchiveInfo(
              path = file.absolutePath,
              name = file.name,
              format = "GZIP",
              fileSizeBytes = file.length(),
              uncompressedBytes = file.length(),
              entryCount = 1,
              isSupported = true,
            ),
            entries = listOf(
              ArchiveEntryItem(
                fullPath = innerName,
                name = innerName,
                isDirectory = false,
                compressedSize = file.length(),
                uncompressedSize = file.length(),
                lastModified = file.lastModified(),
              ),
            ),
          )
        }
        else -> {
          baseStream.close()
          return ArchiveListingResult.Unsupported("TAR/BZ2", "Standalone .bz2 without .tar container is not inspectable as a directory.")
        }
      }

      tarStream.use { tar ->
        val entries = mutableListOf<ArchiveEntryItem>()
        var uncompressed = 0L
        var entry = tar.nextEntry
        while (entry != null) {
          val size = entry.size.coerceAtLeast(0L)
          if (!entry.isDirectory) uncompressed += size
          entries.add(
            ArchiveEntryItem(
              fullPath = entry.name,
              name = entry.name.trimEnd('/').substringAfterLast('/'),
              isDirectory = entry.isDirectory,
              compressedSize = size,
              uncompressedSize = size,
              lastModified = entry.lastModifiedDate?.time ?: 0L,
            ),
          )
          entry = tar.nextEntry
        }
        ArchiveListingResult.Success(
          info = ArchiveInfo(
            path = file.absolutePath,
            name = file.name,
            format = "TAR",
            fileSizeBytes = file.length(),
            uncompressedBytes = uncompressed,
            entryCount = entries.size,
            isSupported = true,
          ),
          entries = entries,
        )
      }
    } catch (e: Exception) {
      ArchiveListingResult.Error("Failed to inspect archive: ${e.message ?: "unknown error"}")
    }
  }

  private fun inspectRar(file: File): ArchiveListingResult {
    return try {
      Archive(file).use { rar ->
        if (rar.isEncrypted) {
          return ArchiveListingResult.Unsupported(
            format = "RAR (Encrypted)",
            reason = "Encrypted RAR archives are not supported.",
          )
        }
        val entries = rar.fileHeaders.map { h ->
          ArchiveEntryItem(
            fullPath = h.fileName.replace('\\', '/'),
            name = h.fileName.replace('\\', '/').trimEnd('/').substringAfterLast('/'),
            isDirectory = h.isDirectory,
            compressedSize = h.fullPackSize,
            uncompressedSize = h.fullUnpackSize,
            lastModified = h.mTime?.time ?: 0L,
          )
        }
        val uncompressed = entries.filterNot { it.isDirectory }.sumOf { it.uncompressedSize }
        ArchiveListingResult.Success(
          info = ArchiveInfo(
            path = file.absolutePath,
            name = file.name,
            format = "RAR4",
            fileSizeBytes = file.length(),
            uncompressedBytes = uncompressed,
            entryCount = entries.size,
            isSupported = true,
          ),
          entries = entries,
        )
      }
    } catch (_: UnsupportedRarV5Exception) {
      ArchiveListingResult.Unsupported(
        format = "RAR5",
        reason = "RAR5 uses a proprietary format that open-source pure-JVM extractors cannot legally decode. Classic RAR4, ZIP, 7Z, and TAR/GZ are fully supported.",
      )
    } catch (e: Exception) {
      ArchiveListingResult.Error("Cannot open RAR archive: ${e.message ?: "unsupported or damaged"}")
    }
  }

  suspend fun extractArchive(
    archivePath: String,
    destinationDirPath: String,
    selectedEntryPaths: Set<String>? = null,
    onProgress: suspend (OperationProgress) -> Unit = {},
  ): ArchiveOpResult = withContext(Dispatchers.IO) {
    val file = File(archivePath)
    val destDir = File(destinationDirPath)
    if (!file.exists() || !file.canRead()) {
      return@withContext ArchiveOpResult(false, "Archive file is unreadable.")
    }
    if (!destDir.exists() && !destDir.mkdirs()) {
      return@withContext ArchiveOpResult(false, "Cannot create destination folder.")
    }

    val ext = FormatUtils.getExtension(file.name)
    val lower = file.name.lowercase()
    return@withContext try {
      when {
        ext == "zip" || ext == "jar" || ext == "apks" || ext == "xapk" ->
          extractZip(file, destDir, selectedEntryPaths, onProgress)
        ext == "7z" ->
          extractSevenZ(file, destDir, selectedEntryPaths, onProgress)
        lower.endsWith(".tar.gz") || lower.endsWith(".tgz") || lower.endsWith(".tar") || lower.endsWith(".tar.bz2") ->
          extractTarLike(file, destDir, selectedEntryPaths, onProgress)
        lower.endsWith(".gz") ->
          extractSingleGzip(file, destDir, onProgress)
        ext == "rar" ->
          extractRar(file, destDir, selectedEntryPaths, onProgress)
        else ->
          ArchiveOpResult(false, "Unsupported archive format .$ext.")
      }
    } catch (e: Exception) {
      ArchiveOpResult(false, "Extraction failed: ${e.message ?: "unknown error"}")
    }
  }

  private fun safeTargetFile(destDir: File, entryPath: String): File {
    val clean = entryPath.replace('\\', '/').trimStart('/')
    val outFile = File(destDir, clean)
    val destCanon = destDir.canonicalPath
    val outCanon = outFile.canonicalPath
    if (!outCanon.startsWith("$destCanon/") && outCanon != destCanon) {
      throw SecurityException("Blocked unsafe archive entry path: $entryPath")
    }
    return outFile
  }

  private suspend fun extractZip(
    file: File,
    destDir: File,
    selected: Set<String>?,
    onProgress: suspend (OperationProgress) -> Unit,
  ): ArchiveOpResult {
    ZipFile(file).use { zip ->
      val allEntries = zip.entries().toList().filter { entry ->
        selected == null || entry.name in selected || selected.any { sel -> entry.name.startsWith("$sel/") }
      }
      val total = allEntries.size.coerceAtLeast(1)
      var extractedCount = 0
      val buffer = ByteArray(32 * 1024)

      allEntries.forEachIndexed { idx, entry ->
        currentCoroutineContext().ensureActive()
        onProgress(OperationProgress("Extracting ZIP", entry.name, idx, total, idx.toFloat() / total))
        val target = safeTargetFile(destDir, entry.name)
        if (entry.isDirectory) {
          target.mkdirs()
        } else {
          target.parentFile?.mkdirs()
          zip.getInputStream(entry).use { input ->
            BufferedOutputStream(FileOutputStream(target)).use { output ->
              var read: Int
              while (input.read(buffer).also { read = it } != -1) {
                output.write(buffer, 0, read)
              }
            }
          }
          extractedCount++
        }
      }
      onProgress(OperationProgress("Extracting ZIP", "Complete", total, total, 1f))
      return ArchiveOpResult(true, "Extracted $extractedCount file(s) to ${destDir.name}.", destDir.absolutePath)
    }
  }

  private suspend fun extractSevenZ(
    file: File,
    destDir: File,
    selected: Set<String>?,
    onProgress: suspend (OperationProgress) -> Unit,
  ): ArchiveOpResult {
    SevenZFile.builder().setFile(file).get().use { sz ->
      val totalEntries = sz.entries.count().coerceAtLeast(1)
      var idx = 0
      var extractedCount = 0
      val buffer = ByteArray(32 * 1024)
      var entry = sz.nextEntry
      while (entry != null) {
        currentCoroutineContext().ensureActive()
        val match = selected == null || entry.name in selected || selected.any { entry.name.startsWith("$it/") }
        if (match) {
          onProgress(OperationProgress("Extracting 7Z", entry.name, idx, totalEntries, idx.toFloat() / totalEntries))
          val target = safeTargetFile(destDir, entry.name)
          if (entry.isDirectory) {
            target.mkdirs()
          } else {
            target.parentFile?.mkdirs()
            BufferedOutputStream(FileOutputStream(target)).use { out ->
              var read: Int
              while (sz.read(buffer).also { read = it } > 0) {
                out.write(buffer, 0, read)
              }
            }
            extractedCount++
          }
        }
        idx++
        entry = sz.nextEntry
      }
      onProgress(OperationProgress("Extracting 7Z", "Complete", totalEntries, totalEntries, 1f))
      return ArchiveOpResult(true, "Extracted $extractedCount file(s) to ${destDir.name}.", destDir.absolutePath)
    }
  }

  private suspend fun extractTarLike(
    file: File,
    destDir: File,
    selected: Set<String>?,
    onProgress: suspend (OperationProgress) -> Unit,
  ): ArchiveOpResult {
    val lower = file.name.lowercase()
    val base = BufferedInputStream(FileInputStream(file))
    val tarStream = when {
      lower.endsWith(".tar.gz") || lower.endsWith(".tgz") -> TarArchiveInputStream(GzipCompressorInputStream(base))
      lower.endsWith(".tar.bz2") || lower.endsWith(".tbz2") -> TarArchiveInputStream(BZip2CompressorInputStream(base))
      else -> TarArchiveInputStream(base)
    }

    var extracted = 0
    tarStream.use { tar ->
      val buffer = ByteArray(32 * 1024)
      var entry = tar.nextEntry
      while (entry != null) {
        currentCoroutineContext().ensureActive()
        val match = selected == null || entry.name in selected || selected.any { entry.name.startsWith("$it/") }
        if (match) {
          onProgress(OperationProgress("Extracting TAR", entry.name, extracted, extracted + 1, 0.5f))
          val target = safeTargetFile(destDir, entry.name)
          if (entry.isDirectory) {
            target.mkdirs()
          } else {
            target.parentFile?.mkdirs()
            BufferedOutputStream(FileOutputStream(target)).use { out ->
              var read: Int
              while (tar.read(buffer).also { read = it } != -1) {
                out.write(buffer, 0, read)
              }
            }
            extracted++
          }
        }
        entry = tar.nextEntry
      }
    }
    onProgress(OperationProgress("Extracting TAR", "Complete", 1, 1, 1f))
    return ArchiveOpResult(true, "Extracted $extracted file(s) to ${destDir.name}.", destDir.absolutePath)
  }

  private suspend fun extractSingleGzip(
    file: File,
    destDir: File,
    onProgress: suspend (OperationProgress) -> Unit,
  ): ArchiveOpResult {
    onProgress(OperationProgress("Extracting GZIP", file.name, 0, 1, 0.3f))
    val outName = file.name.removeSuffix(".gz").ifEmpty { "${file.name}_extracted" }
    val target = safeTargetFile(destDir, outName)
    GzipCompressorInputStream(BufferedInputStream(FileInputStream(file))).use { gz ->
      BufferedOutputStream(FileOutputStream(target)).use { out ->
        val buf = ByteArray(32 * 1024)
        var read: Int
        while (gz.read(buf).also { read = it } != -1) {
          out.write(buf, 0, read)
        }
      }
    }
    onProgress(OperationProgress("Extracting GZIP", "Complete", 1, 1, 1f))
    return ArchiveOpResult(true, "Extracted ${target.name} to ${destDir.name}.", destDir.absolutePath)
  }

  private suspend fun extractRar(
    file: File,
    destDir: File,
    selected: Set<String>?,
    onProgress: suspend (OperationProgress) -> Unit,
  ): ArchiveOpResult {
    return try {
      Archive(file).use { rar ->
        if (rar.isEncrypted) {
          return ArchiveOpResult(false, "Encrypted RAR archives are not supported.")
        }
        val headers = rar.fileHeaders.filter { h ->
          val norm = h.fileName.replace('\\', '/')
          selected == null || norm in selected || selected.any { norm.startsWith("$it/") }
        }
        val total = headers.size.coerceAtLeast(1)
        var extracted = 0
        headers.forEachIndexed { idx, header ->
          currentCoroutineContext().ensureActive()
          val norm = header.fileName.replace('\\', '/')
          onProgress(OperationProgress("Extracting RAR", norm, idx, total, idx.toFloat() / total))
          val target = safeTargetFile(destDir, norm)
          if (header.isDirectory) {
            target.mkdirs()
          } else {
            target.parentFile?.mkdirs()
            FileOutputStream(target).use { out ->
              rar.extractFile(header, out)
            }
            extracted++
          }
        }
        onProgress(OperationProgress("Extracting RAR", "Complete", total, total, 1f))
        ArchiveOpResult(true, "Extracted $extracted file(s) to ${destDir.name}.", destDir.absolutePath)
      }
    } catch (_: UnsupportedRarV5Exception) {
      ArchiveOpResult(
        false,
        "RAR5 format is proprietary and not supported for extraction. Classic RAR4, ZIP, 7Z, and TAR/GZ are supported.",
      )
    }
  }

  suspend fun createZipArchive(
    sources: List<File>,
    outputZipPath: String,
    onProgress: suspend (OperationProgress) -> Unit = {},
  ): ArchiveOpResult = withContext(Dispatchers.IO) {
    if (sources.isEmpty()) return@withContext ArchiveOpResult(false, "No files selected to compress.")
    val outFile = File(outputZipPath)
    return@withContext try {
      outFile.parentFile?.mkdirs()
      val flatList = collectFilesForCompression(sources)
      val total = flatList.size.coerceAtLeast(1)
      val buffer = ByteArray(32 * 1024)

      ZipOutputStream(BufferedOutputStream(FileOutputStream(outFile))).use { zos ->
        flatList.forEachIndexed { idx, (file, entryName) ->
          currentCoroutineContext().ensureActive()
          onProgress(OperationProgress("Creating ZIP", entryName, idx, total, idx.toFloat() / total))
          if (file.isDirectory) {
            zos.putNextEntry(ZipEntry("$entryName/"))
            zos.closeEntry()
          } else {
            zos.putNextEntry(ZipEntry(entryName))
            FileInputStream(file).use { fis ->
              var read: Int
              while (fis.read(buffer).also { read = it } != -1) {
                zos.write(buffer, 0, read)
              }
            }
            zos.closeEntry()
          }
        }
      }
      onProgress(OperationProgress("Creating ZIP", outFile.name, total, total, 1f))
      ArchiveOpResult(true, "Created ${outFile.name} (${FormatUtils.formatFileSize(outFile.length())}).", outFile.absolutePath)
    } catch (e: Exception) {
      runCatching { outFile.delete() }
      ArchiveOpResult(false, "Compression failed: ${e.message ?: "unknown error"}")
    }
  }

  suspend fun createSevenZArchive(
    sources: List<File>,
    output7zPath: String,
    onProgress: suspend (OperationProgress) -> Unit = {},
  ): ArchiveOpResult = withContext(Dispatchers.IO) {
    if (sources.isEmpty()) return@withContext ArchiveOpResult(false, "No files selected to compress.")
    val outFile = File(output7zPath)
    return@withContext try {
      outFile.parentFile?.mkdirs()
      val flatList = collectFilesForCompression(sources)
      val total = flatList.size.coerceAtLeast(1)
      val buffer = ByteArray(32 * 1024)

      SevenZOutputFile(outFile).use { szOut ->
        flatList.forEachIndexed { idx, (file, entryName) ->
          currentCoroutineContext().ensureActive()
          onProgress(OperationProgress("Creating 7Z", entryName, idx, total, idx.toFloat() / total))
          val entry = szOut.createArchiveEntry(file, entryName)
          szOut.putArchiveEntry(entry)
          if (!file.isDirectory) {
            FileInputStream(file).use { fis ->
              var read: Int
              while (fis.read(buffer).also { read = it } != -1) {
                szOut.write(buffer, 0, read)
              }
            }
          }
          szOut.closeArchiveEntry()
        }
        szOut.finish()
      }
      onProgress(OperationProgress("Creating 7Z", outFile.name, total, total, 1f))
      ArchiveOpResult(true, "Created ${outFile.name} (${FormatUtils.formatFileSize(outFile.length())}).", outFile.absolutePath)
    } catch (e: Exception) {
      runCatching { outFile.delete() }
      ArchiveOpResult(false, "7Z compression failed: ${e.message ?: "unknown error"}")
    }
  }

  private fun collectFilesForCompression(sources: List<File>): List<Pair<File, String>> {
    val result = mutableListOf<Pair<File, String>>()
    fun walk(file: File, entryPath: String) {
      if (file.isDirectory) {
        val children = file.listFiles()
        if (children.isNullOrEmpty()) {
          result.add(file to entryPath)
        } else {
          children.forEach { child -> walk(child, "$entryPath/${child.name}") }
        }
      } else {
        result.add(file to entryPath)
      }
    }
    sources.forEach { src ->
      if (src.exists()) walk(src, src.name)
    }
    return result
  }
}
