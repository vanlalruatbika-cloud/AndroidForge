package com.example.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.components.HzGlossyBadge
import com.example.ui.theme.LocalLiquidGlassPalette
import com.example.ui.theme.OutfitFontFamily
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(
  onSplashComplete: () -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  val progress = remember { Animatable(0f) }
  val logoScale = remember { Animatable(0.84f) }
  val contentAlpha = remember { Animatable(0f) }

  LaunchedEffect(Unit) {
    contentAlpha.animateTo(1f, animationSpec = tween(420, easing = FastOutSlowInEasing))
    logoScale.animateTo(1f, animationSpec = tween(520, easing = FastOutSlowInEasing))
    progress.animateTo(1f, animationSpec = tween(950, easing = FastOutSlowInEasing))
    delay(180)
    onSplashComplete()
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(
          colors = listOf(
            Color(0xFF1A1828),
            Color(0xFF28243E),
            Color(0xFFE6E1F8),
            Color(0xFFF6F6FC),
          ),
        ),
      ),
  ) {
    // Huzuni mascot upper showcase (preserving original aspect without distortion)
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(430.dp)
        .align(Alignment.TopCenter),
      contentAlignment = Alignment.TopCenter,
    ) {
      Image(
        painter = painterResource(id = R.drawable.huzuni_mascot),
        contentDescription = "Huzuni Mascot",
        contentScale = ContentScale.Crop,
        alignment = Alignment.TopCenter,
        modifier = Modifier
          .fillMaxSize()
          .alpha(0.92f),
      )
      Box(
        modifier = Modifier
          .fillMaxSize()
          .background(
            Brush.verticalGradient(
              colors = listOf(
                Color.Transparent,
                Color(0x331B182A),
                Color(0xDD221E36),
              ),
            ),
          ),
      )
    }

    Column(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(horizontal = 32.dp, vertical = 28.dp)
        .graphicsLayer { alpha = contentAlpha.value },
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Bottom,
    ) {
      // Glossy glass Hz Emblem
      Box(
        modifier = Modifier
          .graphicsLayer {
            scaleX = logoScale.value
            scaleY = logoScale.value
          },
        contentAlignment = Alignment.Center,
      ) {
        HzGlossyBadge(size = 96.dp)
      }

      Spacer(modifier = Modifier.height(22.dp))

      Text(
        text = "Hz File Manager",
        fontFamily = OutfitFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 30.sp,
        color = Color.White,
      )

      Spacer(modifier = Modifier.height(6.dp))

      Text(
        text = "Powered by Huzuni",
        style = MaterialTheme.typography.titleSmall,
        color = Color.White.copy(alpha = 0.84f),
      )

      Spacer(modifier = Modifier.height(34.dp))

      // Frosted liquid glass progress bar
      Box(
        modifier = Modifier
          .fillMaxWidth(0.68f)
          .height(9.dp)
          .shadow(8.dp, CircleShape, ambientColor = palette.shadowColor)
          .clip(CircleShape)
          .background(Color.White.copy(alpha = 0.35f))
          .border(1.dp, Color.White.copy(alpha = 0.7f), CircleShape),
      ) {
        Box(
          modifier = Modifier
            .fillMaxWidth(progress.value)
            .height(9.dp)
            .clip(CircleShape)
            .background(
              Brush.horizontalGradient(
                colors = listOf(Color.White, palette.accent.primary),
              ),
            ),
        )
      }

      Spacer(modifier = Modifier.height(42.dp))

      Box(
        modifier = Modifier
          .clip(RoundedCornerShape(20.dp))
          .background(Color.White.copy(alpha = 0.68f))
          .border(1.dp, Color.White, RoundedCornerShape(20.dp))
          .padding(horizontal = 18.dp, vertical = 8.dp),
      ) {
        Text(
          text = "Manage • Organize • Explore",
          style = MaterialTheme.typography.labelLarge,
          color = Color(0xFF2B2742),
        )
      }

      Spacer(modifier = Modifier.height(14.dp))
    }
  }
}
