package com.example.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.components.GlossyAccentButton
import com.example.components.HuzuniMascotAvatar
import com.example.components.LiquidGlassCard
import com.example.data.SortDirection
import com.example.data.SortField
import com.example.data.ViewMode
import com.example.permissions.StoragePermissionHelper
import com.example.ui.theme.AccentPalette
import com.example.ui.theme.DangerRed
import com.example.ui.theme.LocalLiquidGlassPalette
import com.example.ui.theme.OutfitFontFamily
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.ThemeMode

@Composable
fun SettingsScreen(
  sharedVm: MainAppViewModel,
) {
  val context = LocalContext.current
  val palette = LocalLiquidGlassPalette.current
  val settings by sharedVm.settings.collectAsStateWithLifecycle()
  val hasAccess by sharedVm.hasAllFilesAccess.collectAsStateWithLifecycle()

  var showAboutDialog by remember { mutableStateOf(false) }

  if (showAboutDialog) {
    AboutHzDialog(onDismiss = { showAboutDialog = false })
  }

  Box(
    modifier = Modifier.fillMaxSize(),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier
        .widthIn(max = 640.dp)
        .fillMaxSize()
        .statusBarsPadding(),
      contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 112.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      item {
        Text(
          text = "Settings",
          style = MaterialTheme.typography.headlineMedium,
          color = palette.textPrimary,
        )
      }

      // Profile / Brand Card matching reference panel 7
      item {
        LiquidGlassCard(
          elevated = true,
          shape = RoundedCornerShape(28.dp),
          onClick = { showAboutDialog = true },
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            HuzuniMascotAvatar(size = 64.dp)
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = "Hz File Manager",
                style = MaterialTheme.typography.titleLarge,
                color = palette.textPrimary,
              )
              Text(
                text = "Version 1.0.0",
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary,
              )
              Spacer(modifier = Modifier.height(6.dp))
              Row(
                modifier = Modifier
                  .clip(RoundedCornerShape(12.dp))
                  .background(palette.accent.softTint)
                  .padding(horizontal = 10.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Icon(
                  imageVector = Icons.Filled.Star,
                  contentDescription = null,
                  tint = palette.accent.primary,
                  modifier = Modifier.size(14.dp),
                )
                Spacer(modifier = Modifier.width(5.dp))
                Text(
                  text = "Huzuni Edition",
                  style = MaterialTheme.typography.labelMedium,
                  color = palette.accent.primary,
                )
              }
            }
            Icon(
              imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
              contentDescription = null,
              tint = palette.textMuted,
            )
          }
        }
      }

      // Appearance Section
      item {
        LiquidGlassCard(shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) {
          Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Filled.Palette, null, tint = palette.accent.primary, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("Appearance", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
            }

            // Theme mode selector (Liquid Glass default, Light, Dark)
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              ThemeMode.entries.forEach { mode ->
                val selected = settings.themeMode == mode
                Box(
                  modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(14.dp))
                    .background(if (selected) palette.accent.primary else palette.accent.softTint.copy(alpha = 0.55f))
                    .clickable { sharedVm.updateThemeMode(mode) }
                    .padding(vertical = 10.dp)
                    .testTag("theme_mode_${mode.name.lowercase()}"),
                  contentAlignment = Alignment.Center,
                ) {
                  Text(
                    text = mode.label,
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = if (selected) Color.White else palette.textPrimary,
                  )
                }
              }
            }

            // Accent color picker
            Text("Accent Color", style = MaterialTheme.typography.labelMedium, color = palette.textSecondary)
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
              AccentPalette.entries.forEach { accent ->
                val selected = settings.accentPalette == accent
                Box(
                  modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .background(accent.primary)
                    .border(
                      width = if (selected) 3.dp else 1.dp,
                      color = if (selected) palette.textPrimary else Color.White,
                      shape = CircleShape,
                    )
                    .clickable { sharedVm.updateAccentPalette(accent) },
                  contentAlignment = Alignment.Center,
                ) {
                  if (selected) {
                    Icon(Icons.Filled.Check, contentDescription = accent.label, tint = Color.White, modifier = Modifier.size(18.dp))
                  }
                }
              }
            }
          }
        }
      }

      // File Manager Preferences Section
      item {
        LiquidGlassCard(shape = RoundedCornerShape(26.dp), modifier = Modifier.fillMaxWidth()) {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Filled.FolderOpen, null, tint = palette.accent.primary, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("File Manager", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
            }

            // Default View Mode
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text("Default View", style = MaterialTheme.typography.bodyMedium, color = palette.textPrimary)
              Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ViewMode.entries.forEach { mode ->
                  val selected = settings.defaultViewMode == mode
                  Text(
                    text = mode.label,
                    style = MaterialTheme.typography.labelMedium,
                    color = if (selected) Color.White else palette.textPrimary,
                    modifier = Modifier
                      .clip(RoundedCornerShape(12.dp))
                      .background(if (selected) palette.accent.primary else palette.accent.softTint)
                      .clickable { sharedVm.updateDefaultViewMode(mode) }
                      .padding(horizontal = 12.dp, vertical = 6.dp),
                  )
                }
              }
            }

            // Default Sort Field
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text("Default Sort", style = MaterialTheme.typography.bodyMedium, color = palette.textPrimary)
              Text(
                text = "${settings.sortField.label} (${settings.sortDirection.label})",
                style = MaterialTheme.typography.labelLarge,
                color = palette.accent.primary,
                modifier = Modifier
                  .clip(RoundedCornerShape(10.dp))
                  .clickable {
                    val fields = SortField.entries
                    val nextField = fields[(fields.indexOf(settings.sortField) + 1) % fields.size]
                    sharedVm.updateSort(nextField, settings.sortDirection)
                  }
                  .padding(horizontal = 8.dp, vertical = 4.dp),
              )
            }

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text("Sort Direction", style = MaterialTheme.typography.bodyMedium, color = palette.textPrimary)
              Text(
                text = settings.sortDirection.label,
                style = MaterialTheme.typography.labelLarge,
                color = palette.accent.primary,
                modifier = Modifier
                  .clip(RoundedCornerShape(10.dp))
                  .clickable {
                    val nextDir = if (settings.sortDirection == SortDirection.ASCENDING) {
                      SortDirection.DESCENDING
                    } else {
                      SortDirection.ASCENDING
                    }
                    sharedVm.updateSort(settings.sortField, nextDir)
                  }
                  .padding(horizontal = 8.dp, vertical = 4.dp),
              )
            }

            HorizontalDivider(color = palette.divider)

            SettingsToggleRow(
              icon = Icons.Filled.Visibility,
              title = "Show Hidden Files",
              subtitle = "Display dotfiles and hidden system folders",
              checked = settings.showHiddenFiles,
              onCheckedChange = { sharedVm.updateShowHidden(it) },
            )
            SettingsToggleRow(
              icon = Icons.Filled.Security,
              title = "Confirm Before Delete",
              subtitle = "Ask confirmation before permanent deletion",
              checked = settings.confirmBeforeDelete,
              onCheckedChange = { sharedVm.updateConfirmDelete(it) },
            )
            SettingsToggleRow(
              icon = Icons.Filled.DarkMode,
              title = "Auto-Rename Conflicts",
              subtitle = "Keep both files instead of overwriting",
              checked = settings.confirmOverwrite,
              onCheckedChange = { sharedVm.updateConfirmOverwrite(it) },
            )
          }
        }
      }

      // Permissions Section
      item {
        LiquidGlassCard(
          shape = RoundedCornerShape(24.dp),
          onClick = { StoragePermissionHelper.openAllFilesAccessSettings(context) },
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Box(
              modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background((if (hasAccess) SuccessGreen else DangerRed).copy(alpha = 0.14f)),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Filled.Security,
                contentDescription = null,
                tint = if (hasAccess) SuccessGreen else DangerRed,
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text("Permissions", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
              Text(
                text = if (hasAccess) "All Files Access: Granted" else "All Files Access: Tap to allow",
                style = MaterialTheme.typography.bodySmall,
                color = if (hasAccess) SuccessGreen else DangerRed,
              )
            }
            Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = palette.textMuted)
          }
        }
      }

      // About Hz & Thanks to Huzuni
      item {
        LiquidGlassCard(
          shape = RoundedCornerShape(24.dp),
          onClick = { showAboutDialog = true },
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(Icons.Filled.Info, null, tint = palette.accent.primary)
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text("About Hz", style = MaterialTheme.typography.titleMedium, color = palette.textPrimary)
                Text("App Info, Offline Privacy & Credits", style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
              }
              Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = palette.textMuted)
            }
            HorizontalDivider(color = palette.divider)
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Filled.Favorite, null, tint = palette.accent.primary)
              Spacer(modifier = Modifier.width(12.dp))
              Text("Thanks to Huzuni ♡", style = MaterialTheme.typography.titleSmall, color = palette.textPrimary)
            }
          }
        }
      }

      // Bottom Huzuni Mascot Promotional Banner matching reference panel 7
      item {
        LiquidGlassCard(
          elevated = true,
          shape = RoundedCornerShape(24.dp),
          contentPadding = PaddingValues(0.dp),
          onClick = { showAboutDialog = true },
          modifier = Modifier.fillMaxWidth(),
        ) {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .height(106.dp)
              .background(
                Brush.horizontalGradient(
                  listOf(
                    Color(0xFF232036),
                    palette.accent.primary.copy(alpha = 0.82f),
                  ),
                ),
              ),
          ) {
            Row(
              modifier = Modifier
                .fillMaxSize()
                .padding(start = 20.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "Huzuni",
                  fontFamily = OutfitFontFamily,
                  fontWeight = FontWeight.Bold,
                  style = MaterialTheme.typography.headlineMedium,
                  color = Color.White,
                )
                Text(
                  text = "\"Dream Bigger...\"",
                  style = MaterialTheme.typography.bodyMedium,
                  color = Color.White.copy(alpha = 0.85f),
                )
              }
              Image(
                painter = painterResource(id = R.drawable.huzuni_mascot),
                contentDescription = "Huzuni Banner",
                contentScale = ContentScale.Crop,
                alignment = Alignment.TopCenter,
                modifier = Modifier
                  .width(120.dp)
                  .fillMaxSize(),
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun SettingsToggleRow(
  icon: ImageVector,
  title: String,
  subtitle: String,
  checked: Boolean,
  onCheckedChange: (Boolean) -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 2.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Icon(icon, contentDescription = null, tint = palette.textSecondary, modifier = Modifier.size(20.dp))
    Spacer(modifier = Modifier.width(10.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, color = palette.textPrimary)
      Text(subtitle, style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
    }
    Switch(
      checked = checked,
      onCheckedChange = onCheckedChange,
      colors = SwitchDefaults.colors(
        checkedThumbColor = Color.White,
        checkedTrackColor = palette.accent.primary,
      ),
    )
  }
}

@Composable
private fun AboutHzDialog(onDismiss: () -> Unit) {
  val palette = LocalLiquidGlassPalette.current
  Dialog(onDismissRequest = onDismiss) {
    LiquidGlassCard(elevated = true, shape = RoundedCornerShape(30.dp)) {
      Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        HuzuniMascotAvatar(size = 84.dp)
        Spacer(modifier = Modifier.height(14.dp))
        Text("Hz File Manager", style = MaterialTheme.typography.headlineMedium, color = palette.textPrimary)
        Text("Version 1.0.0 • Huzuni Liquid Glass Edition", style = MaterialTheme.typography.bodySmall, color = palette.accent.primary)
        Spacer(modifier = Modifier.height(10.dp))
        Text(
          text = "Powered by Huzuni. Built natively for Android with Jetpack Compose, Media3, and offline ZIP/7Z/TAR/RAR4 archive management. Zero tracking, zero cloud uploads — your files stay 100% on your device.",
          style = MaterialTheme.typography.bodyMedium,
          color = palette.textSecondary,
          textAlign = TextAlign.Center,
        )
        Spacer(modifier = Modifier.height(18.dp))
        GlossyAccentButton(text = "Done", onClick = onDismiss, modifier = Modifier.fillMaxWidth())
      }
    }
  }
}
