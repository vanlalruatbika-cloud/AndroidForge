package com.example.filemanager

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import androidx.core.content.FileProvider
import com.example.data.FileItem
import com.example.data.OperationProgress
import com.example.data.SearchFilter
import com.example.data.SortDirection
import com.example.data.SortField
import com.example.utils.FileCategory
import com.example.utils.FormatUtils
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

sealed interface DirectoryListingResult {
  data class Success(val items: List<FileItem>) : DirectoryListingResult
  data class ProtectedSystemFolder(val path: String, val reason: String) : DirectoryListingResult
  data class Error(val message: String) : DirectoryListingResult
}

data class FileOperationResult(
  val successCount: Int,
  val failedItems: List<String>,
  val message: String,
) {
  val isFullSuccess: Boolean get() = failedItems.isEmpty() && successCount > 0
}

class FileOperationsRepository(private val context: Context) {

  fun isProtectedAndroidFolder(path: String): Boolean {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R) return false
    val normalized = path.replace('\\', '/').trimEnd('/')
    val primaryRoot = Environment.getExternalStorageDirectory().absolutePath.replace('\\', '/').trimEnd('/')
    return normalized == "$primaryRoot/Android/data" ||
      normalized.startsWith("$primaryRoot/Android/data/") ||
      normalized == "$primaryRoot/Android/obb" ||
      normalized.startsWith("$primaryRoot/Android/obb/")
  }

  suspend fun listDirectory(
    path: String,
    showHidden: Boolean,
    sortField: SortField,
    sortDirection: SortDirection,
  ): DirectoryListingResult = withContext(Dispatchers.IO) {
    val dir = File(path)
    if (!dir.exists()) {
      return@withContext DirectoryListingResult.Error("Directory does not exist: $path")
    }
    if (!dir.isDirectory) {
      return@withContext DirectoryListingResult.Error("Path is not a folder: ${dir.name}")
    }
    if (isProtectedAndroidFolder(path)) {
      val raw = dir.listFiles()
      if (raw == null || raw.isEmpty()) {
        return@withContext DirectoryListingResult.ProtectedSystemFolder(
          path = path,
          reason = "Android 11+ restricts direct access to Android/data and Android/obb to protect app sandboxes.",
        )
      }
    }

    val rawFiles = dir.listFiles()
      ?: return@withContext DirectoryListingResult.Error(
        "Unable to read this folder. Check storage permission or system restrictions.",
      )

    val mapped = rawFiles
      .filter { file -> showHidden || (!file.name.startsWith(".") && !file.isHidden) }
      .map { file ->
        val childCount = if (file.isDirectory) {
          file.list()?.count { showHidden || !it.startsWith(".") } ?: 0
        } else {
          0
        }
        FileItem(
          path = file.absolutePath,
          name = file.name,
          isDirectory = file.isDirectory,
          sizeBytes = if (file.isDirectory) 0L else file.length(),
          lastModified = file.lastModified(),
          category = FormatUtils.classifyFile(file),
          extension = if (file.isDirectory) "" else FormatUtils.getExtension(file.name),
          childCount = childCount,
          isHidden = file.isHidden || file.name.startsWith("."),
          canRead = file.canRead(),
          canWrite = file.canWrite(),
        )
      }

    DirectoryListingResult.Success(sortItems(mapped, sortField, sortDirection))
  }

  fun sortItems(
    items: List<FileItem>,
    sortField: SortField,
    sortDirection: SortDirection,
  ): List<FileItem> {
    val comparator = when (sortField) {
      SortField.NAME -> compareBy<FileItem> { it.name.lowercase() }
      SortField.SIZE -> compareBy<FileItem> { it.sizeBytes }.thenBy { it.name.lowercase() }
      SortField.DATE -> compareBy<FileItem> { it.lastModified }.thenBy { it.name.lowercase() }
      SortField.TYPE -> compareBy<FileItem> { it.extension.lowercase() }.thenBy { it.name.lowercase() }
    }
    val directed = if (sortDirection == SortDirection.DESCENDING) comparator.reversed() else comparator
    return items.sortedWith(compareByDescending<FileItem> { it.isDirectory }.then(directed))
  }

  suspend fun createFolder(parentPath: String, folderName: String): Result<File> =
    withContext(Dispatchers.IO) {
      runCatching {
        val clean = folderName.trim()
        require(clean.isNotEmpty() && !clean.contains('/') && !clean.contains('\\')) {
          "Invalid folder name."
        }
        val target = File(parentPath, clean)
        if (target.exists()) error("A file or folder named \"$clean\" already exists.")
        if (!target.mkdirs()) error("Could not create folder. Check write permissions.")
        target
      }
    }

  suspend fun createTextFile(parentPath: String, fileName: String, content: String): Result<File> =
    withContext(Dispatchers.IO) {
      runCatching {
        val clean = fileName.trim()
        require(clean.isNotEmpty() && !clean.contains('/') && !clean.contains('\\')) {
          "Invalid file name."
        }
        val target = File(parentPath, clean)
        if (target.exists()) error("A file named \"$clean\" already exists.")
        target.writeText(content)
        target
      }
    }

  suspend fun renameFile(item: FileItem, newName: String): Result<File> =
    withContext(Dispatchers.IO) {
      runCatching {
        val clean = newName.trim()
        require(clean.isNotEmpty() && !clean.contains('/') && !clean.contains('\\')) {
          "Invalid name."
        }
        val source = item.file
        if (!source.exists()) error("File no longer exists.")
        val parent = source.parentFile ?: error("Cannot determine parent folder.")
        val dest = File(parent, clean)
        if (dest.exists() && dest.absolutePath != source.absolutePath) {
          error("\"$clean\" already exists.")
        }
        if (!source.renameTo(dest)) error("Failed to rename \"${item.name}\".")
        dest
      }
    }

  suspend fun deleteFiles(
    items: List<FileItem>,
    onProgress: suspend (OperationProgress) -> Unit = {},
  ): FileOperationResult = withContext(Dispatchers.IO) {
    var deleted = 0
    val failed = mutableListOf<String>()
    val total = items.size.coerceAtLeast(1)

    items.forEachIndexed { index, item ->
      currentCoroutineContext().ensureActive()
      onProgress(
        OperationProgress(
          title = "Deleting items",
          currentItem = item.name,
          completedCount = index,
          totalCount = total,
          fraction = index.toFloat() / total.toFloat(),
        ),
      )
      val file = item.file
      if (!file.exists()) {
        failed.add("${item.name} (not found)")
      } else if (deleteRecursivelySafe(file)) {
        deleted++
      } else {
        failed.add(item.name)
      }
    }

    onProgress(OperationProgress("Deleting items", "Done", total, total, 1f))
    val msg = when {
      failed.isEmpty() -> "Deleted $deleted item${if (deleted == 1) "" else "s"}."
      deleted == 0 -> "Failed to delete ${failed.joinToString(", ")}."
      else -> "Deleted $deleted item(s), failed on ${failed.size}: ${failed.joinToString(", ")}."
    }
    FileOperationResult(deleted, failed, msg)
  }

  private fun deleteRecursivelySafe(file: File): Boolean {
    if (file.isDirectory) {
      val children = file.listFiles() ?: return false
      for (child in children) {
        if (!deleteRecursivelySafe(child)) return false
      }
    }
    return file.delete()
  }

  suspend fun copyOrMove(
    sources: List<FileItem>,
    destinationDirPath: String,
    isMove: Boolean,
    overwrite: Boolean,
    onProgress: suspend (OperationProgress) -> Unit = {},
  ): FileOperationResult = withContext(Dispatchers.IO) {
    val destDir = File(destinationDirPath)
    if (!destDir.exists() || !destDir.isDirectory || !destDir.canWrite()) {
      return@withContext FileOperationResult(
        successCount = 0,
        failedItems = sources.map { it.name },
        message = "Destination folder is not writable.",
      )
    }

    var succeeded = 0
    val failed = mutableListOf<String>()
    val total = sources.size.coerceAtLeast(1)

    sources.forEachIndexed { index, item ->
      currentCoroutineContext().ensureActive()
      onProgress(
        OperationProgress(
          title = if (isMove) "Moving files" else "Copying files",
          currentItem = item.name,
          completedCount = index,
          totalCount = total,
          fraction = index.toFloat() / total.toFloat(),
        ),
      )

      val src = item.file
      if (!src.exists()) {
        failed.add("${item.name} (missing)")
        return@forEachIndexed
      }

      val srcCanon = runCatching { src.canonicalPath }.getOrDefault(src.absolutePath)
      val destCanon = runCatching { destDir.canonicalPath }.getOrDefault(destDir.absolutePath)
      if (src.isDirectory && (destCanon == srcCanon || destCanon.startsWith("$srcCanon/"))) {
        failed.add("${item.name} (cannot copy into itself)")
        return@forEachIndexed
      }

      val target = resolveDestinationFile(destDir, src.name, overwrite)
      if (target == null) {
        failed.add("${item.name} (already exists)")
        return@forEachIndexed
      }

      try {
        if (isMove) {
          if (src.absolutePath == target.absolutePath) {
            succeeded++
            return@forEachIndexed
          }
          if (target.exists() && overwrite) {
            deleteRecursivelySafe(target)
          }
          if (src.renameTo(target)) {
            succeeded++
          } else {
            copyRecursively(src, target, overwrite)
            if (!deleteRecursivelySafe(src)) {
              failed.add("${item.name} (copied but source could not be removed)")
            } else {
              succeeded++
            }
          }
        } else {
          copyRecursively(src, target, overwrite)
          succeeded++
        }
      } catch (ce: CancellationException) {
        throw ce
      } catch (e: Exception) {
        failed.add("${item.name} (${e.message ?: "error"})")
      }
    }

    onProgress(
      OperationProgress(
        title = if (isMove) "Moving files" else "Copying files",
        currentItem = "Complete",
        completedCount = total,
        totalCount = total,
        fraction = 1f,
      ),
    )

    val verb = if (isMove) "Moved" else "Copied"
    val msg = when {
      failed.isEmpty() -> "$verb $succeeded item${if (succeeded == 1) "" else "s"}."
      succeeded == 0 -> "${if (isMove) "Move" else "Copy"} failed: ${failed.joinToString(", ")}."
      else -> "$verb $succeeded item(s), failed on ${failed.size}: ${failed.joinToString(", ")}."
    }
    FileOperationResult(succeeded, failed, msg)
  }

  private fun resolveDestinationFile(destDir: File, originalName: String, overwrite: Boolean): File? {
    val candidate = File(destDir, originalName)
    if (!candidate.exists() || overwrite) return candidate

    val dot = originalName.lastIndexOf('.')
    val base = if (dot > 0) originalName.substring(0, dot) else originalName
    val ext = if (dot > 0) originalName.substring(dot) else ""
    for (i in 1..999) {
      val next = File(destDir, "$base ($i)$ext")
      if (!next.exists()) return next
    }
    return null
  }

  private fun copyRecursively(source: File, target: File, overwrite: Boolean) {
    if (source.isDirectory) {
      if (!target.exists() && !target.mkdirs()) {
        throw IllegalStateException("Cannot create directory ${target.name}")
      }
      val children = source.listFiles() ?: throw IllegalStateException("Cannot read ${source.name}")
      for (child in children) {
        copyRecursively(child, File(target, child.name), overwrite)
      }
    } else {
      if (target.exists() && !overwrite) {
        throw IllegalStateException("Target already exists")
      }
      target.parentFile?.mkdirs()
      val buffer = ByteArray(64 * 1024)
      FileInputStream(source).use { input ->
        FileOutputStream(target).use { output ->
          var read: Int
          while (input.read(buffer).also { read = it } != -1) {
            output.write(buffer, 0, read)
          }
          output.flush()
        }
      }
      target.setLastModified(source.lastModified())
    }
  }

  fun searchFiles(
    roots: List<String>,
    query: String,
    filter: SearchFilter,
    showHidden: Boolean,
  ): Flow<List<FileItem>> = flow {
    val cleanQuery = query.trim().lowercase()
    if (cleanQuery.isEmpty() && filter == SearchFilter.ALL) {
      emit(emptyList())
      return@flow
    }

    val results = ArrayList<FileItem>(64)
    val stack = ArrayDeque<Pair<File, Int>>()
    roots.forEach { path ->
      val f = File(path)
      if (f.exists() && f.canRead()) stack.add(f to 0)
    }

    var visited = 0
    val maxNodes = 12_000
    while (stack.isNotEmpty() && visited < maxNodes) {
      currentCoroutineContext().ensureActive()
      val (dir, depth) = stack.removeLast()
      val children = dir.listFiles() ?: continue

      for (child in children) {
        visited++
        if (!showHidden && (child.name.startsWith(".") || child.isHidden)) continue

        val isDir = child.isDirectory
        val normalized = child.absolutePath.replace('\\', '/')
        if (isDir && (normalized.endsWith("/Android/data") || normalized.endsWith("/Android/obb"))) {
          continue
        }

        val category = FormatUtils.classifyFile(child)
        val matchesFilter = when (filter) {
          SearchFilter.ALL -> true
          SearchFilter.FOLDERS -> isDir
          SearchFilter.IMAGES -> category == FileCategory.IMAGE
          SearchFilter.VIDEOS -> category == FileCategory.VIDEO
          SearchFilter.AUDIO -> category == FileCategory.AUDIO
          SearchFilter.DOCUMENTS -> category in setOf(FileCategory.PDF, FileCategory.TEXT, FileCategory.DOCUMENT)
          SearchFilter.ARCHIVES -> category == FileCategory.ARCHIVE
          SearchFilter.APKS -> category == FileCategory.APK
        }

        val ext = if (isDir) "" else FormatUtils.getExtension(child.name)
        val matchesQuery = cleanQuery.isEmpty() ||
          child.name.lowercase().contains(cleanQuery) ||
          ext.contains(cleanQuery.removePrefix(".")) ||
          category.label.lowercase().contains(cleanQuery)

        if (matchesFilter && matchesQuery) {
          results.add(
            FileItem(
              path = child.absolutePath,
              name = child.name,
              isDirectory = isDir,
              sizeBytes = if (isDir) 0L else child.length(),
              lastModified = child.lastModified(),
              category = category,
              extension = ext,
              isHidden = child.isHidden || child.name.startsWith("."),
              canRead = child.canRead(),
              canWrite = child.canWrite(),
            ),
          )
          if (results.size % 20 == 0) {
            emit(results.toList())
          }
          if (results.size >= 300) {
            emit(results.toList())
            return@flow
          }
        }

        if (isDir && depth < 7) {
          stack.add(child to depth + 1)
        }
      }
    }

    emit(results.toList())
  }.flowOn(Dispatchers.IO)

  fun shareFiles(items: List<FileItem>): Result<Unit> = runCatching {
    val realFiles = items.filter { !it.isDirectory && it.file.exists() }
    require(realFiles.isNotEmpty()) { "Select at least one existing file to share." }
    val authority = "${context.packageName}.fileprovider"

    val intent = if (realFiles.size == 1) {
      val file = realFiles.first().file
      val uri = FileProvider.getUriForFile(context, authority, file)
      Intent(Intent.ACTION_SEND).apply {
        type = FormatUtils.getMimeType(file)
        putExtra(Intent.EXTRA_STREAM, uri)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
    } else {
      val uris = ArrayList(realFiles.map { FileProvider.getUriForFile(context, authority, it.file) })
      Intent(Intent.ACTION_SEND_MULTIPLE).apply {
        type = "*/*"
        putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
      }
    }

    val chooser = Intent.createChooser(intent, "Share via Hz File Manager").apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    context.startActivity(chooser)
  }

  fun openWithExternalApp(item: FileItem): Result<Unit> = runCatching {
    val file = item.file
    require(file.exists() && !file.isDirectory) { "Cannot open this item externally." }
    val authority = "${context.packageName}.fileprovider"
    val uri = FileProvider.getUriForFile(context, authority, file)
    val mime = FormatUtils.getMimeType(file)
    val intent = Intent(Intent.ACTION_VIEW).apply {
      setDataAndType(uri, mime)
      addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    val chooser = Intent.createChooser(intent, "Open ${item.name} with...").apply {
      addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }
    context.startActivity(chooser)
  }
}
