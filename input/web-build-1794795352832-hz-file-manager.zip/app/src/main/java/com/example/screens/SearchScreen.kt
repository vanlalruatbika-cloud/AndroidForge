package com.example.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.components.ConfirmDeleteDialog
import com.example.components.FileContextMenuDialog
import com.example.components.FileItemThumbnail
import com.example.components.FilePropertiesDialog
import com.example.components.InputNameDialog
import com.example.components.LiquidGlassBackground
import com.example.components.LiquidGlassCard
import com.example.data.ClipboardMode
import com.example.data.FileItem
import com.example.data.SearchFilter
import com.example.ui.theme.LocalLiquidGlassPalette
import com.example.utils.FormatUtils
import kotlinx.coroutines.delay

@Composable
fun SearchScreen(
  sharedVm: MainAppViewModel,
  initialFilter: SearchFilter = SearchFilter.ALL,
  onBack: () -> Unit,
  onOpenFolder: (String) -> Unit,
  onOpenFile: (FileItem) -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  val settings by sharedVm.settings.collectAsStateWithLifecycle()
  val overview by sharedVm.storageOverview.collectAsStateWithLifecycle()

  var query by remember { mutableStateOf("") }
  var selectedFilter by remember { mutableStateOf(initialFilter) }
  var results by remember { mutableStateOf<List<FileItem>>(emptyList()) }
  var isSearching by remember { mutableStateOf(false) }

  var contextTarget by remember { mutableStateOf<FileItem?>(null) }
  var renameTarget by remember { mutableStateOf<FileItem?>(null) }
  var deleteTarget by remember { mutableStateOf<FileItem?>(null) }
  var propertiesTarget by remember { mutableStateOf<FileItem?>(null) }

  val roots = remember(overview.volumes) {
    overview.volumes.map { it.rootPath }.ifEmpty {
      listOf(sharedVm.storageRepository.getPrimaryRootPath())
    }
  }

  LaunchedEffect(query, selectedFilter, settings.showHiddenFiles, roots) {
    if (query.isBlank() && selectedFilter == SearchFilter.ALL) {
      results = emptyList()
      isSearching = false
      return@LaunchedEffect
    }
    delay(220)
    isSearching = true
    if (query.trim().length >= 2) {
      sharedVm.addRecentSearch(query.trim())
    }
    sharedVm.fileOpsRepository.searchFiles(
      roots = roots,
      query = query,
      filter = selectedFilter,
      showHidden = settings.showHiddenFiles,
    ).collect { batch ->
      results = batch
    }
    isSearching = false
  }

  contextTarget?.let { item ->
    FileContextMenuDialog(
      item = item,
      onDismiss = { contextTarget = null },
      onOpen = {
        if (item.isDirectory) onOpenFolder(item.path) else onOpenFile(item)
      },
      onOpenWith = { sharedVm.openWithExternal(item) },
      onShare = { sharedVm.shareItems(listOf(item)) },
      onCopy = { sharedVm.setClipboard(listOf(item), ClipboardMode.COPY) },
      onMove = { sharedVm.setClipboard(listOf(item), ClipboardMode.MOVE) },
      onRename = { renameTarget = item },
      onDelete = {
        if (settings.confirmBeforeDelete) {
          deleteTarget = item
        } else {
          sharedVm.deleteItems(listOf(item)) {
            results = results.filterNot { it.path == item.path }
          }
        }
      },
      onCompress = {
        val out = sharedVm.defaultArchiveOutputPath(listOf(item), "zip")
        sharedVm.compressToArchive(listOf(item), out, "ZIP")
      },
      onProperties = { propertiesTarget = item },
    )
  }

  renameTarget?.let { item ->
    InputNameDialog(
      title = "Rename",
      initialValue = item.name,
      placeholder = "New name",
      confirmLabel = "Rename",
      onDismiss = { renameTarget = null },
      onConfirm = { newName, _ ->
        renameTarget = null
        sharedVm.renameItem(item, newName)
      },
    )
  }

  deleteTarget?.let { item ->
    ConfirmDeleteDialog(
      items = listOf(item),
      onDismiss = { deleteTarget = null },
      onConfirm = {
        sharedVm.deleteItems(listOf(item)) {
          results = results.filterNot { it.path == item.path }
        }
      },
    )
  }

  propertiesTarget?.let { item ->
    FilePropertiesDialog(item = item, onDismiss = { propertiesTarget = null })
  }

  LiquidGlassBackground {
    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
      Column(
        modifier = Modifier
          .widthIn(max = 640.dp)
          .fillMaxSize()
          .statusBarsPadding()
          .navigationBarsPadding()
          .padding(horizontal = 16.dp, vertical = 10.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          IconButton(onClick = onBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = palette.textPrimary)
          }
          OutlinedTextField(
            value = query,
            onValueChange = { query = it },
            singleLine = true,
            placeholder = { Text("Search name, extension, or type...") },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null, tint = palette.accent.primary) },
            trailingIcon = {
              if (query.isNotEmpty()) {
                IconButton(onClick = { query = "" }) {
                  Icon(Icons.Filled.Clear, contentDescription = "Clear search")
                }
              }
            },
            shape = RoundedCornerShape(20.dp),
            modifier = Modifier
              .weight(1f)
              .testTag("search_input"),
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Type Filter Chips
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          SearchFilter.entries.forEach { filter ->
            val selected = filter == selectedFilter
            FilterChip(
              selected = selected,
              onClick = { selectedFilter = filter },
              label = { Text(filter.label) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = palette.accent.primary,
                selectedLabelColor = Color.White,
              ),
            )
          }
        }

        if (isSearching) {
          Spacer(modifier = Modifier.height(6.dp))
          LinearProgressIndicator(
            color = palette.accent.primary,
            trackColor = palette.accent.softTint,
            modifier = Modifier.fillMaxWidth(),
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (query.isBlank() && selectedFilter == SearchFilter.ALL) {
          // Suggestions & Recent Searches
          val suggestions = listOf(".pdf", ".zip", ".apk", ".mp4", ".jpg", "Download")
          Text(
            text = "Quick Suggestions",
            style = MaterialTheme.typography.titleSmall,
            color = palette.textSecondary,
          )
          Spacer(modifier = Modifier.height(8.dp))
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
          ) {
            suggestions.forEach { term ->
              LiquidGlassCard(
                shape = RoundedCornerShape(16.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                onClick = { query = term },
              ) {
                Text(term, style = MaterialTheme.typography.labelLarge, color = palette.accent.primary)
              }
            }
          }

          if (settings.recentSearches.isNotEmpty()) {
            Spacer(modifier = Modifier.height(18.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text("Recent Searches", style = MaterialTheme.typography.titleSmall, color = palette.textSecondary)
              TextButton(onClick = { sharedVm.clearRecentSearches() }) {
                Text("Clear", color = palette.accent.primary)
              }
            }
            settings.recentSearches.forEach { term ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(14.dp))
                  .clickable { query = term }
                  .padding(horizontal = 8.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Icon(Icons.Filled.History, null, tint = palette.textMuted, modifier = Modifier.size(19.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Text(term, style = MaterialTheme.typography.bodyMedium, color = palette.textPrimary)
              }
            }
          }
        } else if (results.isEmpty() && !isSearching) {
          Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(
              text = "No matching files found.",
              style = MaterialTheme.typography.bodyLarge,
              color = palette.textSecondary,
            )
          }
        } else {
          LazyColumn(
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 16.dp),
            modifier = Modifier.fillMaxSize(),
          ) {
            items(results, key = { it.path }) { item ->
              LiquidGlassCard(
                shape = RoundedCornerShape(18.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                onClick = {
                  if (item.isDirectory) onOpenFolder(item.path) else onOpenFile(item)
                },
                modifier = Modifier.fillMaxWidth(),
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  FileItemThumbnail(item = item, size = 42.dp)
                  Spacer(modifier = Modifier.width(12.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = item.name,
                      style = MaterialTheme.typography.titleSmall,
                      color = palette.textPrimary,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                      text = "${if (item.isDirectory) "Folder" else FormatUtils.formatFileSize(item.sizeBytes)} • ${item.file.parentFile?.name ?: ""}",
                      style = MaterialTheme.typography.bodySmall,
                      color = palette.textSecondary,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                  }
                  IconButton(onClick = { contextTarget = item }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "More", tint = palette.textSecondary)
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}
