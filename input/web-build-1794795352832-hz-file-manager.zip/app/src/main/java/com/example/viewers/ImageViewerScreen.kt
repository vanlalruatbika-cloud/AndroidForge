package com.example.viewers

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.RotateRight
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.components.ConfirmDeleteDialog
import com.example.components.FilePropertiesDialog
import com.example.data.FileItem
import com.example.utils.FileCategory
import com.example.utils.FormatUtils
import java.io.File

@Composable
fun ImageViewerScreen(
  filePath: String,
  onBack: () -> Unit,
  onShare: (FileItem) -> Unit,
  onDelete: (FileItem, onDeleted: () -> Unit) -> Unit,
) {
  val context = LocalContext.current
  val siblingImages = remember(filePath) {
    val current = File(filePath)
    val parent = current.parentFile
    val list = parent?.listFiles()
      ?.filter { !it.isDirectory && FormatUtils.classifyFile(it) == FileCategory.IMAGE }
      ?.sortedBy { it.name.lowercase() }
      ?: listOf(current)
    if (list.any { it.absolutePath == filePath }) list else listOf(current)
  }

  var currentIndex by remember(filePath) {
    mutableIntStateOf(siblingImages.indexOfFirst { it.absolutePath == filePath }.coerceAtLeast(0))
  }
  val currentFile = siblingImages.getOrElse(currentIndex) { File(filePath) }
  val currentItem = remember(currentFile.absolutePath) {
    FileItem(
      path = currentFile.absolutePath,
      name = currentFile.name,
      isDirectory = false,
      sizeBytes = currentFile.length(),
      lastModified = currentFile.lastModified(),
      category = FileCategory.IMAGE,
      extension = FormatUtils.getExtension(currentFile.name),
    )
  }

  var scale by remember(currentIndex) { mutableFloatStateOf(1f) }
  var offset by remember(currentIndex) { mutableStateOf(Offset.Zero) }
  var rotationTarget by remember(currentIndex) { mutableFloatStateOf(0f) }
  val animatedRotation by animateFloatAsState(targetValue = rotationTarget, label = "imgRotation")

  var showDeleteDialog by remember { mutableStateOf(false) }
  var showPropertiesDialog by remember { mutableStateOf(false) }

  if (showDeleteDialog) {
    ConfirmDeleteDialog(
      items = listOf(currentItem),
      onDismiss = { showDeleteDialog = false },
      onConfirm = {
        onDelete(currentItem) {
          onBack()
        }
      },
    )
  }

  if (showPropertiesDialog) {
    FilePropertiesDialog(
      item = currentItem,
      onDismiss = { showPropertiesDialog = false },
    )
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color(0xFF0E0D16)),
  ) {
    // Zoomable, Pannable, Rotatable Image
    Box(
      modifier = Modifier
        .fillMaxSize()
        .pointerInput(currentIndex) {
          detectTapGestures(
            onDoubleTap = {
              if (scale > 1.2f) {
                scale = 1f
                offset = Offset.Zero
              } else {
                scale = 2.5f
              }
            },
          )
        }
        .pointerInput(currentIndex) {
          detectTransformGestures { _, pan, zoom, _ ->
            val newScale = (scale * zoom).coerceIn(1f, 5f)
            scale = newScale
            offset = if (newScale > 1f) {
              offset + pan
            } else {
              Offset.Zero
            }
          }
        },
      contentAlignment = Alignment.Center,
    ) {
      AsyncImage(
        model = ImageRequest.Builder(context)
          .data(currentFile)
          .crossfade(true)
          .build(),
        contentDescription = currentFile.name,
        contentScale = ContentScale.Fit,
        modifier = Modifier
          .fillMaxSize()
          .graphicsLayer {
            scaleX = scale
            scaleY = scale
            translationX = offset.x
            translationY = offset.y
            rotationZ = animatedRotation
          },
      )
    }

    // Top translucent bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .align(Alignment.TopCenter)
        .background(Color.Black.copy(alpha = 0.45f))
        .statusBarsPadding()
        .padding(horizontal = 8.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      IconButton(onClick = onBack) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowBack,
          contentDescription = "Back",
          tint = Color.White,
        )
      }
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = "${currentIndex + 1} / ${siblingImages.size}",
          style = MaterialTheme.typography.titleMedium,
          color = Color.White,
        )
        Text(
          text = currentFile.name,
          style = MaterialTheme.typography.bodySmall,
          color = Color.White.copy(alpha = 0.72f),
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
      IconButton(onClick = { rotationTarget += 90f }) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.RotateRight,
          contentDescription = "Rotate 90 degrees",
          tint = Color.White,
        )
      }
      IconButton(onClick = { showPropertiesDialog = true }) {
        Icon(
          imageVector = Icons.Filled.Info,
          contentDescription = "Image info",
          tint = Color.White,
        )
      }
    }

    // Previous / Next image pills when multiple images exist
    if (siblingImages.size > 1) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .align(Alignment.Center)
          .padding(horizontal = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        if (currentIndex > 0) {
          IconButton(
            onClick = { currentIndex-- },
            modifier = Modifier
              .size(44.dp)
              .clip(CircleShape)
              .background(Color.Black.copy(alpha = 0.48f)),
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
              contentDescription = "Previous image",
              tint = Color.White,
            )
          }
        } else {
          Spacer(modifier = Modifier.size(44.dp))
        }

        if (currentIndex < siblingImages.lastIndex) {
          IconButton(
            onClick = { currentIndex++ },
            modifier = Modifier
              .size(44.dp)
              .clip(CircleShape)
              .background(Color.Black.copy(alpha = 0.48f)),
          ) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
              contentDescription = "Next image",
              tint = Color.White,
            )
          }
        }
      }
    }

    // Bottom glass action bar matching reference panel 6
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .align(Alignment.BottomCenter)
        .navigationBarsPadding()
        .padding(horizontal = 16.dp, vertical = 12.dp)
        .clip(RoundedCornerShape(24.dp))
        .background(Color(0xCC1C1B28))
        .padding(horizontal = 12.dp, vertical = 10.dp),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      ViewerActionPill(Icons.Filled.Share, "Share") { onShare(currentItem) }
      ViewerActionPill(Icons.AutoMirrored.Filled.RotateRight, "Rotate") { rotationTarget += 90f }
      ViewerActionPill(Icons.Filled.DeleteOutline, "Delete") { showDeleteDialog = true }
      ViewerActionPill(Icons.Filled.Info, "Info") { showPropertiesDialog = true }
    }
  }
}

@Composable
private fun ViewerActionPill(
  icon: ImageVector,
  label: String,
  onClick: () -> Unit,
) {
  Column(
    modifier = Modifier
      .clip(RoundedCornerShape(14.dp))
      .clickable(onClick = onClick)
      .padding(horizontal = 14.dp, vertical = 6.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Icon(
      imageVector = icon,
      contentDescription = label,
      tint = Color.White,
      modifier = Modifier.size(22.dp),
    )
    Spacer(modifier = Modifier.height(3.dp))
    Text(
      text = label,
      style = MaterialTheme.typography.labelMedium,
      color = Color.White.copy(alpha = 0.9f),
    )
  }
}
