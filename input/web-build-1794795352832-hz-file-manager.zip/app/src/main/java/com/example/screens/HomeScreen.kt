package com.example.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.components.ConfirmDeleteDialog
import com.example.components.FileContextMenuDialog
import com.example.components.FileItemThumbnail
import com.example.components.FilePropertiesDialog
import com.example.components.GlossyAccentButton
import com.example.components.HuzuniMascotAvatar
import com.example.components.HzGlossyBadge
import com.example.components.InputNameDialog
import com.example.components.LiquidGlassCard
import com.example.data.ClipboardMode
import com.example.data.FileItem
import com.example.data.SearchFilter
import com.example.data.StorageVolumeInfo
import com.example.ui.theme.CategoryApkTint
import com.example.ui.theme.CategoryArchiveTint
import com.example.ui.theme.CategoryAudioTint
import com.example.ui.theme.CategoryDocTint
import com.example.ui.theme.CategoryImageTint
import com.example.ui.theme.CategoryVideoTint
import com.example.ui.theme.DangerRed
import com.example.ui.theme.FolderGold
import com.example.ui.theme.LocalLiquidGlassPalette
import com.example.utils.FormatUtils

@Composable
fun HomeScreen(
  sharedVm: MainAppViewModel,
  onOpenFilesPath: (String) -> Unit,
  onOpenQuickCategory: (SearchFilter) -> Unit,
  onOpenArchives: () -> Unit,
  onOpenSearch: () -> Unit,
  onOpenSettings: () -> Unit,
  onOpenFile: (FileItem) -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  val overview by sharedVm.storageOverview.collectAsStateWithLifecycle()
  val hasAccess by sharedVm.hasAllFilesAccess.collectAsStateWithLifecycle()
  val settings by sharedVm.settings.collectAsStateWithLifecycle()

  var showCategoryBreakdown by remember { mutableStateOf(false) }
  var contextTarget by remember { mutableStateOf<FileItem?>(null) }
  var renameTarget by remember { mutableStateOf<FileItem?>(null) }
  var deleteTarget by remember { mutableStateOf<FileItem?>(null) }
  var propertiesTarget by remember { mutableStateOf<FileItem?>(null) }

  contextTarget?.let { item ->
    FileContextMenuDialog(
      item = item,
      onDismiss = { contextTarget = null },
      onOpen = { onOpenFile(item) },
      onOpenWith = { sharedVm.openWithExternal(item) },
      onShare = { sharedVm.shareItems(listOf(item)) },
      onCopy = { sharedVm.setClipboard(listOf(item), ClipboardMode.COPY) },
      onMove = { sharedVm.setClipboard(listOf(item), ClipboardMode.MOVE) },
      onRename = { renameTarget = item },
      onDelete = {
        if (settings.confirmBeforeDelete) {
          deleteTarget = item
        } else {
          sharedVm.deleteItems(listOf(item))
        }
      },
      onCompress = {
        val out = sharedVm.defaultArchiveOutputPath(listOf(item), "zip")
        sharedVm.compressToArchive(listOf(item), out, "ZIP")
      },
      onProperties = { propertiesTarget = item },
    )
  }

  renameTarget?.let { item ->
    InputNameDialog(
      title = "Rename",
      initialValue = item.name,
      placeholder = "New name",
      confirmLabel = "Rename",
      onDismiss = { renameTarget = null },
      onConfirm = { newName, _ ->
        renameTarget = null
        sharedVm.renameItem(item, newName)
      },
    )
  }

  deleteTarget?.let { item ->
    ConfirmDeleteDialog(
      items = listOf(item),
      onDismiss = { deleteTarget = null },
      onConfirm = { sharedVm.deleteItems(listOf(item)) },
    )
  }

  propertiesTarget?.let { item ->
    FilePropertiesDialog(item = item, onDismiss = { propertiesTarget = null })
  }

  Box(
    modifier = Modifier.fillMaxSize(),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier
        .widthIn(max = 640.dp)
        .fillMaxSize()
        .statusBarsPadding(),
      contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 108.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
      // Header Bar matching reference panel 2
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          HzGlossyBadge(size = 46.dp)
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "File Manager",
              style = MaterialTheme.typography.headlineMedium,
              color = palette.textPrimary,
            )
            Text(
              text = "Powered by Huzuni ♡",
              style = MaterialTheme.typography.bodySmall,
              color = palette.textSecondary,
            )
          }
          IconButton(onClick = { sharedVm.refreshAll() }) {
            Icon(
              imageVector = Icons.Filled.Refresh,
              contentDescription = "Refresh storage",
              tint = palette.textSecondary,
            )
          }
          Spacer(modifier = Modifier.width(4.dp))
          HuzuniMascotAvatar(
            size = 48.dp,
            onClick = onOpenSettings,
            modifier = Modifier.testTag("home_profile_avatar"),
          )
        }
      }

      // Search Pill Bar
      item {
        LiquidGlassCard(
          shape = RoundedCornerShape(22.dp),
          contentPadding = PaddingValues(horizontal = 16.dp, vertical = 13.dp),
          onClick = onOpenSearch,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("home_search_bar"),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(
              imageVector = Icons.Filled.Search,
              contentDescription = "Search files",
              tint = palette.accent.primary,
              modifier = Modifier.size(21.dp),
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
              text = "Search files, folders, APKs, archives...",
              style = MaterialTheme.typography.bodyMedium,
              color = palette.textMuted,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
      }

      // Permission status banner when All Files Access is not granted
      if (!hasAccess) {
        item {
          LiquidGlassCard(
            elevated = true,
            shape = RoundedCornerShape(22.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Box(
                modifier = Modifier
                  .size(44.dp)
                  .clip(CircleShape)
                  .background(DangerRed.copy(alpha = 0.12f)),
                contentAlignment = Alignment.Center,
              ) {
                Icon(
                  imageVector = Icons.Filled.Security,
                  contentDescription = null,
                  tint = DangerRed,
                )
              }
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = "All Files Access Needed",
                  style = MaterialTheme.typography.titleSmall,
                  color = palette.textPrimary,
                )
                Text(
                  text = "Grant access to manage all internal storage folders.",
                  style = MaterialTheme.typography.bodySmall,
                  color = palette.textSecondary,
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
              GlossyAccentButton(
                text = "Allow",
                onClick = { sharedVm.openPermissionDialog() },
                modifier = Modifier.testTag("home_allow_access_button"),
              )
            }
          }
        }
      }

      // Storage Overview Card (Real StatFs Data)
      item {
        val primary = overview.primaryVolume
        StorageOverviewCard(
          volume = primary,
          isLoading = overview.isLoading,
          showBreakdown = showCategoryBreakdown,
          onToggleBreakdown = { showCategoryBreakdown = !showCategoryBreakdown },
          onBrowseRoot = {
            onOpenFilesPath(primary?.rootPath ?: sharedVm.storageRepository.getPrimaryRootPath())
          },
        )
      }

      // Expandable Storage Category Breakdown
      item {
        AnimatedVisibility(visible = showCategoryBreakdown) {
          LiquidGlassCard(
            shape = RoundedCornerShape(24.dp),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
              Text(
                text = "Storage Breakdown",
                style = MaterialTheme.typography.titleMedium,
                color = palette.textPrimary,
              )
              val totalScanned = overview.categories.sumOf { it.bytes }.coerceAtLeast(1L)
              overview.categories.forEach { slice ->
                val color = when (slice.label) {
                  "Images" -> CategoryImageTint
                  "Videos" -> CategoryVideoTint
                  "Audio" -> CategoryAudioTint
                  "Documents" -> CategoryDocTint
                  "Archives" -> CategoryArchiveTint
                  "APKs" -> CategoryApkTint
                  else -> palette.textMuted
                }
                Column(modifier = Modifier.fillMaxWidth()) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                  ) {
                    Text(
                      text = "${slice.label} (${slice.count})",
                      style = MaterialTheme.typography.bodySmall,
                      fontWeight = FontWeight.Medium,
                      color = palette.textPrimary,
                    )
                    Text(
                      text = FormatUtils.formatFileSize(slice.bytes),
                      style = MaterialTheme.typography.labelSmall,
                      color = palette.textSecondary,
                    )
                  }
                  Spacer(modifier = Modifier.height(4.dp))
                  LinearProgressIndicator(
                    progress = { (slice.bytes.toFloat() / totalScanned.toFloat()).coerceIn(0.02f, 1f) },
                    color = color,
                    trackColor = palette.accent.softTint.copy(alpha = 0.55f),
                    modifier = Modifier
                      .fillMaxWidth()
                      .height(6.dp)
                      .clip(CircleShape),
                  )
                }
              }
            }
          }
        }
      }

      // Storage Volumes Shortcuts (Internal + External SD if present)
      if (overview.volumes.size > 1) {
        item {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            overview.volumes.forEach { vol ->
              LiquidGlassCard(
                shape = RoundedCornerShape(18.dp),
                contentPadding = PaddingValues(12.dp),
                onClick = { onOpenFilesPath(vol.rootPath) },
                modifier = Modifier.weight(1f),
              ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                  Icon(
                    imageVector = Icons.Filled.Storage,
                    contentDescription = null,
                    tint = palette.accent.primary,
                    modifier = Modifier.size(20.dp),
                  )
                  Spacer(modifier = Modifier.width(8.dp))
                  Column {
                    Text(
                      text = vol.name,
                      style = MaterialTheme.typography.labelLarge,
                      color = palette.textPrimary,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                      text = "${FormatUtils.formatFileSize(vol.availableBytes)} free",
                      style = MaterialTheme.typography.bodySmall,
                      color = palette.textSecondary,
                    )
                  }
                }
              }
            }
          }
        }
      }

      // Quick Access Grid (All 7 requested categories + Internal Storage)
      item {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = "Quick Access",
              style = MaterialTheme.typography.titleLarge,
              color = palette.textPrimary,
            )
            Text(
              text = "Browse All >",
              style = MaterialTheme.typography.labelLarge,
              color = palette.accent.primary,
              modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .clickable { onOpenFilesPath(sharedVm.storageRepository.getPrimaryRootPath()) }
                .padding(horizontal = 6.dp, vertical = 4.dp),
            )
          }

          val quickItems = listOf(
            QuickAccessSpec("Downloads", Icons.Filled.Download, palette.accent.primary) {
              onOpenFilesPath(sharedVm.storageRepository.getQuickAccessFolder("downloads").absolutePath)
            },
            QuickAccessSpec("Documents", Icons.Filled.Description, CategoryDocTint) {
              onOpenQuickCategory(SearchFilter.DOCUMENTS)
            },
            QuickAccessSpec("Pictures", Icons.Filled.Image, CategoryImageTint) {
              onOpenQuickCategory(SearchFilter.IMAGES)
            },
            QuickAccessSpec("Videos", Icons.Filled.VideoLibrary, CategoryVideoTint) {
              onOpenQuickCategory(SearchFilter.VIDEOS)
            },
            QuickAccessSpec("Music", Icons.Filled.AudioFile, CategoryAudioTint) {
              onOpenQuickCategory(SearchFilter.AUDIO)
            },
            QuickAccessSpec("APK Files", Icons.Filled.Android, CategoryApkTint) {
              onOpenQuickCategory(SearchFilter.APKS)
            },
            QuickAccessSpec("Archives", Icons.Filled.Archive, CategoryArchiveTint) {
              onOpenArchives()
            },
            QuickAccessSpec("Internal", Icons.Filled.Folder, FolderGold) {
              onOpenFilesPath(sharedVm.storageRepository.getPrimaryRootPath())
            },
          )

          quickItems.chunked(4).forEach { rowItems ->
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              rowItems.forEach { spec ->
                QuickAccessTile(
                  spec = spec,
                  modifier = Modifier.weight(1f),
                )
              }
            }
          }
        }
      }

      // Recent Files Header
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "Recent Files",
            style = MaterialTheme.typography.titleLarge,
            color = palette.textPrimary,
          )
          Text(
            text = "${overview.recentFiles.size} found",
            style = MaterialTheme.typography.labelMedium,
            color = palette.textSecondary,
          )
        }
      }

      if (overview.isLoading && overview.recentFiles.isEmpty()) {
        item {
          LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
            Box(
              modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp),
              contentAlignment = Alignment.Center,
            ) {
              CircularProgressIndicator(color = palette.accent.primary)
            }
          }
        }
      } else if (overview.recentFiles.isEmpty()) {
        item {
          LiquidGlassCard(modifier = Modifier.fillMaxWidth()) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
            ) {
              Text(
                text = "No accessible recent files yet",
                style = MaterialTheme.typography.titleSmall,
                color = palette.textPrimary,
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = if (hasAccess) "Create or download files to see them here." else "Grant All Files Access to index recent device files.",
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary,
              )
            }
          }
        }
      } else {
        items(overview.recentFiles.take(12), key = { it.path }) { item ->
          LiquidGlassCard(
            shape = RoundedCornerShape(20.dp),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
            onClick = { onOpenFile(item) },
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              FileItemThumbnail(item = item, size = 44.dp)
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = item.name,
                  style = MaterialTheme.typography.titleSmall,
                  color = palette.textPrimary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = "${FormatUtils.formatFileSize(item.sizeBytes)} • ${item.category.label} • ${FormatUtils.formatRelativeTime(item.lastModified)}",
                  style = MaterialTheme.typography.bodySmall,
                  color = palette.textSecondary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }
              IconButton(onClick = { contextTarget = item }) {
                Icon(
                  imageVector = Icons.Filled.MoreVert,
                  contentDescription = "File options",
                  tint = palette.textSecondary,
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun StorageOverviewCard(
  volume: StorageVolumeInfo?,
  isLoading: Boolean,
  showBreakdown: Boolean,
  onToggleBreakdown: () -> Unit,
  onBrowseRoot: () -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  val rawPercent = volume?.usedPercent ?: 0f
  val animatedPercent by animateFloatAsState(
    targetValue = rawPercent,
    animationSpec = tween(durationMillis = 700),
    label = "storageArc",
  )

  LiquidGlassCard(
    elevated = true,
    shape = RoundedCornerShape(28.dp),
    onClick = onToggleBreakdown,
    modifier = Modifier.fillMaxWidth(),
  ) {
    Column(modifier = Modifier.fillMaxWidth()) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        // Circular Storage Ring matching reference panel 2
        Box(
          modifier = Modifier.size(92.dp),
          contentAlignment = Alignment.Center,
        ) {
          val trackColor = palette.accent.softTint
          val arcPrimary = palette.accent.primary
          val arcSecondary = palette.accent.secondary
          Canvas(modifier = Modifier.fillMaxSize().padding(6.dp)) {
            drawArc(
              color = trackColor,
              startAngle = -90f,
              sweepAngle = 360f,
              useCenter = false,
              style = Stroke(width = 11.dp.toPx(), cap = StrokeCap.Round),
            )
            drawArc(
              brush = Brush.sweepGradient(
                colors = listOf(arcSecondary, arcPrimary, arcSecondary),
              ),
              startAngle = -90f,
              sweepAngle = 360f * animatedPercent,
              useCenter = false,
              style = Stroke(width = 11.dp.toPx(), cap = StrokeCap.Round),
            )
          }
          Text(
            text = "${(animatedPercent * 100).toInt()}%",
            style = MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = palette.textPrimary,
          )
        }

        Spacer(modifier = Modifier.width(16.dp))

        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = volume?.name ?: "Internal Storage",
            style = MaterialTheme.typography.titleLarge,
            color = palette.textPrimary,
          )
          Spacer(modifier = Modifier.height(4.dp))
          if (volume != null) {
            Text(
              text = "${FormatUtils.formatFileSize(volume.usedBytes)} / ${FormatUtils.formatFileSize(volume.totalBytes)}",
              style = MaterialTheme.typography.bodyMedium,
              fontWeight = FontWeight.SemiBold,
              color = palette.textPrimary,
            )
            Text(
              text = "${FormatUtils.formatFileSize(volume.availableBytes)} available",
              style = MaterialTheme.typography.bodySmall,
              color = palette.textSecondary,
            )
          } else if (isLoading) {
            Text(
              text = "Reading device storage...",
              style = MaterialTheme.typography.bodySmall,
              color = palette.textSecondary,
            )
          }
          Spacer(modifier = Modifier.height(8.dp))
          LinearProgressIndicator(
            progress = { animatedPercent },
            color = palette.accent.primary,
            trackColor = palette.accent.softTint,
            modifier = Modifier
              .fillMaxWidth()
              .height(7.dp)
              .clip(CircleShape),
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Text(
          text = if (showBreakdown) "Hide category breakdown ▲" else "Tap for category breakdown ▼",
          style = MaterialTheme.typography.labelMedium,
          color = palette.accent.primary,
        )
        Text(
          text = "Open Storage >",
          style = MaterialTheme.typography.labelLarge,
          color = palette.accent.primary,
          modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onBrowseRoot)
            .padding(horizontal = 8.dp, vertical = 4.dp),
        )
      }
    }
  }
}

private data class QuickAccessSpec(
  val title: String,
  val icon: ImageVector,
  val tint: Color,
  val onClick: () -> Unit,
)

@Composable
private fun QuickAccessTile(
  spec: QuickAccessSpec,
  modifier: Modifier = Modifier,
) {
  val palette = LocalLiquidGlassPalette.current
  LiquidGlassCard(
    shape = RoundedCornerShape(20.dp),
    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 12.dp),
    onClick = spec.onClick,
    modifier = modifier,
  ) {
    Column(
      modifier = Modifier.fillMaxWidth(),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Box(
        modifier = Modifier
          .size(42.dp)
          .clip(CircleShape)
          .background(spec.tint.copy(alpha = 0.14f))
          .border(1.dp, spec.tint.copy(alpha = 0.25f), CircleShape),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = spec.icon,
          contentDescription = spec.title,
          tint = spec.tint,
          modifier = Modifier.size(21.dp),
        )
      }
      Spacer(modifier = Modifier.height(7.dp))
      Text(
        text = spec.title,
        style = MaterialTheme.typography.labelMedium,
        color = palette.textPrimary,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}
