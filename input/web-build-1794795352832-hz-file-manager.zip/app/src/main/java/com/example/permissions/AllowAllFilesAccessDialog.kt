package com.example.permissions

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderShared
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.components.GlossyAccentButton
import com.example.components.LiquidGlassCard
import com.example.ui.theme.LocalLiquidGlassPalette

@Composable
fun AllowAllFilesAccessDialog(
  onAllowAccess: () -> Unit,
  onDismiss: () -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
  ) {
    LiquidGlassCard(
      elevated = true,
      shape = RoundedCornerShape(32.dp),
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 24.dp),
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 8.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        // Glossy glass folder + lock emblem matching reference panel 8
        Box(
          modifier = Modifier
            .size(86.dp)
            .shadow(14.dp, CircleShape, ambientColor = palette.shadowColor)
            .clip(CircleShape)
            .background(
              Brush.linearGradient(
                colors = listOf(
                  Color.White.copy(alpha = 0.95f),
                  palette.accent.softTint,
                ),
              ),
            )
            .border(
              1.5.dp,
              Brush.linearGradient(listOf(Color.White, palette.accent.primary.copy(alpha = 0.45f))),
              CircleShape,
            ),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Filled.FolderShared,
            contentDescription = "All Files Access",
            tint = palette.accent.primary,
            modifier = Modifier.size(42.dp),
          )
        }

        Spacer(modifier = Modifier.height(18.dp))

        Text(
          text = "Allow All Files Access",
          style = MaterialTheme.typography.headlineMedium,
          color = palette.textPrimary,
          textAlign = TextAlign.Center,
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text = "To browse, organize, and manage archives and files across internal storage like ZArchiver, please allow Hz File Manager to access all files on your device.",
          style = MaterialTheme.typography.bodyMedium,
          color = palette.textSecondary,
          textAlign = TextAlign.Center,
        )

        Spacer(modifier = Modifier.height(22.dp))

        GlossyAccentButton(
          text = "Go to Settings",
          icon = Icons.Filled.Settings,
          onClick = onAllowAccess,
          modifier = Modifier
            .fillMaxWidth()
            .testTag("allow_all_files_button"),
        )

        Spacer(modifier = Modifier.height(10.dp))

        GlossyAccentButton(
          text = "Cancel",
          icon = Icons.Filled.LockOpen,
          isSecondary = true,
          onClick = onDismiss,
          modifier = Modifier.fillMaxWidth(),
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.Center,
        ) {
          Icon(
            imageVector = Icons.Filled.Info,
            contentDescription = null,
            tint = palette.textMuted,
            modifier = Modifier.size(16.dp),
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = "All operations stay offline on your device.",
            style = MaterialTheme.typography.bodySmall,
            color = palette.textMuted,
          )
        }
      }
    }
  }
}
