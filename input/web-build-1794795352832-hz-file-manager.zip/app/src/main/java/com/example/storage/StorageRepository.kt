package com.example.storage

import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import com.example.data.FileItem
import com.example.data.StorageCategorySlice
import com.example.data.StorageOverviewState
import com.example.data.StorageVolumeInfo
import com.example.utils.FileCategory
import com.example.utils.FormatUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class StorageRepository(private val context: Context) {

  fun getPrimaryRootPath(): String = Environment.getExternalStorageDirectory().absolutePath

  suspend fun loadStorageOverview(showHidden: Boolean = false): StorageOverviewState =
    withContext(Dispatchers.IO) {
      val volumes = discoverStorageVolumes()
      val primary = volumes.firstOrNull { it.isPrimary } ?: volumes.firstOrNull()

      var imageBytes = 0L
      var imageCount = 0
      var videoBytes = 0L
      var videoCount = 0
      var audioBytes = 0L
      var audioCount = 0
      var docBytes = 0L
      var docCount = 0
      var archiveBytes = 0L
      var archiveCount = 0
      var apkBytes = 0L
      var apkCount = 0
      var otherBytes = 0L
      var otherCount = 0

      val recentCandidates = ArrayList<File>(120)
      val rootDir = primary?.let { File(it.rootPath) } ?: Environment.getExternalStorageDirectory()

      if (rootDir.exists() && rootDir.canRead()) {
        val stack = ArrayDeque<Pair<File, Int>>()
        stack.add(rootDir to 0)
        var visitedDirs = 0
        val maxDirsToScan = 1800

        while (stack.isNotEmpty() && visitedDirs < maxDirsToScan) {
          val (dir, depth) = stack.removeLast()
          visitedDirs++
          val children = dir.listFiles() ?: continue

          for (child in children) {
            if (!showHidden && child.name.startsWith(".")) continue
            if (child.isDirectory) {
              val normalized = child.absolutePath.replace('\\', '/')
              if (normalized.endsWith("/Android/data") || normalized.endsWith("/Android/obb")) {
                continue
              }
              if (depth < 6) {
                stack.add(child to depth + 1)
              }
            } else {
              val len = child.length().coerceAtLeast(0L)
              when (FormatUtils.classifyFile(child)) {
                FileCategory.IMAGE -> {
                  imageBytes += len
                  imageCount++
                }
                FileCategory.VIDEO -> {
                  videoBytes += len
                  videoCount++
                }
                FileCategory.AUDIO -> {
                  audioBytes += len
                  audioCount++
                }
                FileCategory.PDF, FileCategory.TEXT, FileCategory.DOCUMENT -> {
                  docBytes += len
                  docCount++
                }
                FileCategory.ARCHIVE -> {
                  archiveBytes += len
                  archiveCount++
                }
                FileCategory.APK -> {
                  apkBytes += len
                  apkCount++
                }
                else -> {
                  otherBytes += len
                  otherCount++
                }
              }
              recentCandidates.add(child)
            }
          }
        }
      }

      val recentFiles = recentCandidates
        .sortedByDescending { it.lastModified() }
        .take(25)
        .map { file ->
          FileItem(
            path = file.absolutePath,
            name = file.name,
            isDirectory = false,
            sizeBytes = file.length(),
            lastModified = file.lastModified(),
            category = FormatUtils.classifyFile(file),
            extension = FormatUtils.getExtension(file.name),
            isHidden = file.isHidden || file.name.startsWith("."),
            canRead = file.canRead(),
            canWrite = file.canWrite(),
          )
        }

      val categories = listOf(
        StorageCategorySlice("Images", imageBytes, imageCount),
        StorageCategorySlice("Videos", videoBytes, videoCount),
        StorageCategorySlice("Audio", audioBytes, audioCount),
        StorageCategorySlice("Documents", docBytes, docCount),
        StorageCategorySlice("Archives", archiveBytes, archiveCount),
        StorageCategorySlice("APKs", apkBytes, apkCount),
        StorageCategorySlice("Others", otherBytes, otherCount),
      )

      StorageOverviewState(
        volumes = volumes,
        primaryVolume = primary,
        categories = categories,
        recentFiles = recentFiles,
        isLoading = false,
      )
    }

  suspend fun discoverStorageVolumes(): List<StorageVolumeInfo> = withContext(Dispatchers.IO) {
    val result = mutableListOf<StorageVolumeInfo>()
    val seenPaths = mutableSetOf<String>()

    val primaryFile = Environment.getExternalStorageDirectory()
    if (primaryFile.exists()) {
      readStatFsVolume(
        id = "primary",
        name = "Internal Storage",
        root = primaryFile,
        isPrimary = true,
        isRemovable = false,
      )?.let {
        result.add(it)
        seenPaths.add(primaryFile.absolutePath)
      }
    }

    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
      val sm = context.getSystemService(Context.STORAGE_SERVICE) as? StorageManager
      sm?.storageVolumes?.forEachIndexed { idx, vol ->
        val dir = vol.directory
        if (dir != null && dir.exists() && seenPaths.add(dir.absolutePath)) {
          val label = vol.getDescription(context)?.takeIf { it.isNotBlank() }
            ?: if (vol.isRemovable) "External Storage ${idx}" else "Storage Volume ${idx}"
          readStatFsVolume(
            id = vol.uuid ?: "vol_$idx",
            name = label,
            root = dir,
            isPrimary = vol.isPrimary,
            isRemovable = vol.isRemovable,
          )?.let { result.add(it) }
        }
      }
    } else {
      context.getExternalFilesDirs(null).forEachIndexed { idx, appDir ->
        if (appDir != null) {
          val marker = "/Android/data/"
          val abs = appDir.absolutePath
          val cut = abs.indexOf(marker)
          if (cut > 0) {
            val root = File(abs.substring(0, cut))
            if (root.exists() && root.canRead() && seenPaths.add(root.absolutePath)) {
              readStatFsVolume(
                id = "ext_$idx",
                name = if (idx == 0) "Internal Storage" else "SD Card $idx",
                root = root,
                isPrimary = idx == 0,
                isRemovable = idx > 0,
              )?.let { result.add(it) }
            }
          }
        }
      }
    }

    result
  }

  private fun readStatFsVolume(
    id: String,
    name: String,
    root: File,
    isPrimary: Boolean,
    isRemovable: Boolean,
  ): StorageVolumeInfo? {
    return try {
      val stat = StatFs(root.absolutePath)
      val total = stat.totalBytes
      val available = stat.availableBytes
      val used = (total - available).coerceAtLeast(0L)
      StorageVolumeInfo(
        id = id,
        name = name,
        rootPath = root.absolutePath,
        totalBytes = total,
        availableBytes = available,
        usedBytes = used,
        isPrimary = isPrimary,
        isRemovable = isRemovable,
      )
    } catch (_: Exception) {
      null
    }
  }

  fun getQuickAccessFolder(key: String): File {
    val root = Environment.getExternalStorageDirectory()
    val candidate = when (key) {
      "downloads" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
      "documents" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
      "pictures" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
      "videos" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES)
      "music" -> Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC)
      else -> root
    }
    return if (candidate.exists()) candidate else root
  }

  suspend fun scanByCategory(
    categoryKeys: Set<FileCategory>,
    showHidden: Boolean = false,
  ): List<FileItem> = withContext(Dispatchers.IO) {
    val results = mutableListOf<FileItem>()
    val root = Environment.getExternalStorageDirectory()
    if (!root.exists() || !root.canRead()) return@withContext emptyList()

    val stack = ArrayDeque<Pair<File, Int>>()
    stack.add(root to 0)
    var dirsVisited = 0

    while (stack.isNotEmpty() && dirsVisited < 2000) {
      val (dir, depth) = stack.removeLast()
      dirsVisited++
      val children = dir.listFiles() ?: continue
      for (child in children) {
        if (!showHidden && child.name.startsWith(".")) continue
        if (child.isDirectory) {
          val normalized = child.absolutePath.replace('\\', '/')
          if (normalized.endsWith("/Android/data") || normalized.endsWith("/Android/obb")) continue
          if (depth < 7) stack.add(child to depth + 1)
        } else {
          val cat = FormatUtils.classifyFile(child)
          if (cat in categoryKeys) {
            results.add(
              FileItem(
                path = child.absolutePath,
                name = child.name,
                isDirectory = false,
                sizeBytes = child.length(),
                lastModified = child.lastModified(),
                category = cat,
                extension = FormatUtils.getExtension(child.name),
                isHidden = child.isHidden || child.name.startsWith("."),
                canRead = child.canRead(),
                canWrite = child.canWrite(),
              ),
            )
          }
        }
      }
    }

    results.sortedByDescending { it.lastModified }
  }
}
