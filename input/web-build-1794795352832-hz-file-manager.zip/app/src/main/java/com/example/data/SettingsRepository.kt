package com.example.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.ui.theme.AccentPalette
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "hz_settings")

data class UserSettings(
  val themeMode: ThemeMode = ThemeMode.LIQUID_GLASS,
  val accentPalette: AccentPalette = AccentPalette.LAVENDER,
  val defaultViewMode: ViewMode = ViewMode.LIST,
  val sortField: SortField = SortField.NAME,
  val sortDirection: SortDirection = SortDirection.ASCENDING,
  val showHiddenFiles: Boolean = false,
  val confirmBeforeDelete: Boolean = true,
  val confirmOverwrite: Boolean = true,
  val recentSearches: List<String> = emptyList(),
)

class SettingsRepository(private val context: Context) {

  private object Keys {
    val THEME_MODE = stringPreferencesKey("theme_mode")
    val ACCENT_PALETTE = stringPreferencesKey("accent_palette")
    val DEFAULT_VIEW_MODE = stringPreferencesKey("default_view_mode")
    val SORT_FIELD = stringPreferencesKey("sort_field")
    val SORT_DIRECTION = stringPreferencesKey("sort_direction")
    val SHOW_HIDDEN = booleanPreferencesKey("show_hidden")
    val CONFIRM_DELETE = booleanPreferencesKey("confirm_delete")
    val CONFIRM_OVERWRITE = booleanPreferencesKey("confirm_overwrite")
    val RECENT_SEARCHES = stringPreferencesKey("recent_searches")
  }

  val settingsFlow: Flow<UserSettings> = context.dataStore.data.map { prefs ->
    val searches = prefs[Keys.RECENT_SEARCHES]?.let { raw ->
      runCatching { Json.decodeFromString<List<String>>(raw) }.getOrDefault(emptyList())
    } ?: emptyList()

    UserSettings(
      themeMode = prefs[Keys.THEME_MODE]?.let { runCatching { ThemeMode.valueOf(it) }.getOrNull() }
        ?: ThemeMode.LIQUID_GLASS,
      accentPalette = prefs[Keys.ACCENT_PALETTE]?.let { runCatching { AccentPalette.valueOf(it) }.getOrNull() }
        ?: AccentPalette.LAVENDER,
      defaultViewMode = prefs[Keys.DEFAULT_VIEW_MODE]?.let { runCatching { ViewMode.valueOf(it) }.getOrNull() }
        ?: ViewMode.LIST,
      sortField = prefs[Keys.SORT_FIELD]?.let { runCatching { SortField.valueOf(it) }.getOrNull() }
        ?: SortField.NAME,
      sortDirection = prefs[Keys.SORT_DIRECTION]?.let { runCatching { SortDirection.valueOf(it) }.getOrNull() }
        ?: SortDirection.ASCENDING,
      showHiddenFiles = prefs[Keys.SHOW_HIDDEN] ?: false,
      confirmBeforeDelete = prefs[Keys.CONFIRM_DELETE] ?: true,
      confirmOverwrite = prefs[Keys.CONFIRM_OVERWRITE] ?: true,
      recentSearches = searches,
    )
  }

  suspend fun setThemeMode(mode: ThemeMode) {
    context.dataStore.edit { it[Keys.THEME_MODE] = mode.name }
  }

  suspend fun setAccentPalette(palette: AccentPalette) {
    context.dataStore.edit { it[Keys.ACCENT_PALETTE] = palette.name }
  }

  suspend fun setDefaultViewMode(mode: ViewMode) {
    context.dataStore.edit { it[Keys.DEFAULT_VIEW_MODE] = mode.name }
  }

  suspend fun setSort(field: SortField, direction: SortDirection) {
    context.dataStore.edit {
      it[Keys.SORT_FIELD] = field.name
      it[Keys.SORT_DIRECTION] = direction.name
    }
  }

  suspend fun setShowHiddenFiles(show: Boolean) {
    context.dataStore.edit { it[Keys.SHOW_HIDDEN] = show }
  }

  suspend fun setConfirmBeforeDelete(confirm: Boolean) {
    context.dataStore.edit { it[Keys.CONFIRM_DELETE] = confirm }
  }

  suspend fun setConfirmOverwrite(confirm: Boolean) {
    context.dataStore.edit { it[Keys.CONFIRM_OVERWRITE] = confirm }
  }

  suspend fun addRecentSearch(query: String) {
    val clean = query.trim()
    if (clean.isEmpty()) return
    context.dataStore.edit { prefs ->
      val current = prefs[Keys.RECENT_SEARCHES]?.let { raw ->
        runCatching { Json.decodeFromString<List<String>>(raw) }.getOrDefault(emptyList())
      } ?: emptyList()
      val updated = (listOf(clean) + current.filterNot { it.equals(clean, ignoreCase = true) }).take(10)
      prefs[Keys.RECENT_SEARCHES] = Json.encodeToString(updated)
    }
  }

  suspend fun clearRecentSearches() {
    context.dataStore.edit { it.remove(Keys.RECENT_SEARCHES) }
  }
}
