package com.example.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.OpenInNew
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.FileItem
import com.example.data.OperationProgress
import com.example.ui.theme.DangerRed
import com.example.ui.theme.FolderGold
import com.example.ui.theme.LocalLiquidGlassPalette
import com.example.utils.FormatUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun FileContextMenuDialog(
  item: FileItem,
  onDismiss: () -> Unit,
  onOpen: () -> Unit,
  onOpenWith: () -> Unit,
  onShare: () -> Unit,
  onCopy: () -> Unit,
  onMove: () -> Unit,
  onRename: () -> Unit,
  onDelete: () -> Unit,
  onCompress: () -> Unit,
  onProperties: () -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 20.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
      LiquidGlassCard(
        elevated = true,
        shape = RoundedCornerShape(28.dp),
        contentPadding = PaddingValues(vertical = 14.dp, horizontal = 16.dp),
      ) {
        Column(modifier = Modifier.fillMaxWidth()) {
          // Preview header
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
              .fillMaxWidth()
              .padding(bottom = 10.dp),
          ) {
            FileItemThumbnail(item = item, size = 48.dp)
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = item.name,
                style = MaterialTheme.typography.titleMedium,
                color = palette.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Spacer(modifier = Modifier.height(2.dp))
              val sub = if (item.isDirectory) {
                "${item.childCount} items • Folder"
              } else {
                "${FormatUtils.formatFileSize(item.sizeBytes)} • ${item.extension.uppercase().ifEmpty { item.category.label }}"
              }
              Text(
                text = sub,
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary,
              )
            }
          }

          HorizontalDivider(color = palette.divider)
          Spacer(modifier = Modifier.height(6.dp))

          ContextMenuActionRow(Icons.Filled.FolderOpen, "Open", onClick = { onDismiss(); onOpen() })
          if (!item.isDirectory) {
            ContextMenuActionRow(Icons.AutoMirrored.Filled.OpenInNew, "Open with...", onClick = { onDismiss(); onOpenWith() })
            ContextMenuActionRow(Icons.Filled.Share, "Share", onClick = { onDismiss(); onShare() })
          }
          ContextMenuActionRow(Icons.Filled.ContentCopy, "Copy", onClick = { onDismiss(); onCopy() })
          ContextMenuActionRow(Icons.Filled.DriveFileMove, "Move", onClick = { onDismiss(); onMove() })
          ContextMenuActionRow(Icons.Filled.Edit, "Rename", onClick = { onDismiss(); onRename() })
          ContextMenuActionRow(
            Icons.Filled.DeleteOutline,
            "Delete",
            tint = DangerRed,
            onClick = { onDismiss(); onDelete() },
          )
          ContextMenuActionRow(Icons.Filled.Compress, "Compress to ZIP / 7Z", onClick = { onDismiss(); onCompress() })
          ContextMenuActionRow(Icons.Filled.Info, "Properties", onClick = { onDismiss(); onProperties() })
        }
      }

      LiquidGlassCard(
        elevated = true,
        shape = RoundedCornerShape(22.dp),
        contentPadding = PaddingValues(vertical = 4.dp),
        onClick = onDismiss,
      ) {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .height(44.dp),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = "Cancel",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.SemiBold,
            color = palette.textPrimary,
          )
        }
      }
    }
  }
}

@Composable
private fun ContextMenuActionRow(
  icon: ImageVector,
  label: String,
  tint: Color? = null,
  onClick: () -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  val effectiveTint = tint ?: palette.textPrimary
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .clickable(onClick = onClick)
      .padding(horizontal = 10.dp, vertical = 11.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Icon(
      imageVector = icon,
      contentDescription = label,
      tint = effectiveTint,
      modifier = Modifier.size(20.dp),
    )
    Spacer(modifier = Modifier.width(14.dp))
    Text(
      text = label,
      style = MaterialTheme.typography.bodyLarge,
      fontWeight = FontWeight.Medium,
      color = effectiveTint,
    )
  }
}

@Composable
fun InputNameDialog(
  title: String,
  initialValue: String,
  placeholder: String,
  confirmLabel: String,
  extraContentLabel: String? = null,
  onDismiss: () -> Unit,
  onConfirm: (name: String, extraText: String) -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  var text by remember { mutableStateOf(initialValue) }
  var extraText by remember { mutableStateOf("") }

  Dialog(onDismissRequest = onDismiss) {
    LiquidGlassCard(elevated = true, shape = RoundedCornerShape(26.dp)) {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text(
          text = title,
          style = MaterialTheme.typography.titleLarge,
          color = palette.textPrimary,
        )
        Spacer(modifier = Modifier.height(14.dp))
        OutlinedTextField(
          value = text,
          onValueChange = { text = it },
          singleLine = true,
          label = { Text(placeholder) },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("dialog_name_input"),
        )
        if (extraContentLabel != null) {
          Spacer(modifier = Modifier.height(10.dp))
          OutlinedTextField(
            value = extraText,
            onValueChange = { extraText = it },
            minLines = 3,
            maxLines = 6,
            label = { Text(extraContentLabel) },
            modifier = Modifier.fillMaxWidth(),
          )
        }
        Spacer(modifier = Modifier.height(18.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.End,
        ) {
          TextButton(onClick = onDismiss) {
            Text("Cancel", color = palette.textSecondary)
          }
          Spacer(modifier = Modifier.width(8.dp))
          GlossyAccentButton(
            text = confirmLabel,
            enabled = text.trim().isNotEmpty(),
            onClick = { onConfirm(text.trim(), extraText) },
            modifier = Modifier.testTag("dialog_confirm_button"),
          )
        }
      }
    }
  }
}

@Composable
fun ConfirmDeleteDialog(
  items: List<FileItem>,
  onDismiss: () -> Unit,
  onConfirm: () -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  Dialog(onDismissRequest = onDismiss) {
    LiquidGlassCard(elevated = true, shape = RoundedCornerShape(28.dp)) {
      Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        Box(
          modifier = Modifier
            .size(56.dp)
            .clip(CircleShape)
            .background(DangerRed.copy(alpha = 0.14f)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Filled.WarningAmber,
            contentDescription = "Confirm Delete",
            tint = DangerRed,
            modifier = Modifier.size(30.dp),
          )
        }
        Spacer(modifier = Modifier.height(12.dp))
        Text(
          text = "Delete ${if (items.size == 1) "\"${items.first().name}\"" else "${items.size} items"}?",
          style = MaterialTheme.typography.titleLarge,
          color = palette.textPrimary,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "This permanently removes the selected files from storage and cannot be undone.",
          style = MaterialTheme.typography.bodyMedium,
          color = palette.textSecondary,
        )
        Spacer(modifier = Modifier.height(18.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          GlossyAccentButton(
            text = "Cancel",
            isSecondary = true,
            onClick = onDismiss,
            modifier = Modifier.weight(1f),
          )
          GlossyAccentButton(
            text = "Delete",
            onClick = { onDismiss(); onConfirm() },
            modifier = Modifier
              .weight(1f)
              .testTag("confirm_delete_button"),
          )
        }
      }
    }
  }
}

@Composable
fun FilePropertiesDialog(
  item: FileItem,
  onDismiss: () -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  var md5 by remember { mutableStateOf<String?>(null) }
  var sha256 by remember { mutableStateOf<String?>(null) }
  var folderStats by remember { mutableStateOf<Pair<Int, Long>?>(null) }

  LaunchedEffect(item.path) {
    withContext(Dispatchers.IO) {
      if (item.isDirectory) {
        var count = 0
        var total = 0L
        val stack = ArrayDeque<File>()
        stack.add(item.file)
        var guard = 0
        while (stack.isNotEmpty() && guard < 1500) {
          val dir = stack.removeLast()
          guard++
          dir.listFiles()?.forEach { child ->
            count++
            if (child.isDirectory) stack.add(child) else total += child.length()
          }
        }
        folderStats = count to total
      } else if (item.sizeBytes <= 64L * 1024 * 1024) {
        md5 = FormatUtils.computeDigest(item.file, "MD5")
        sha256 = FormatUtils.computeDigest(item.file, "SHA-256")
      } else {
        md5 = "Skipped (>64 MB)"
        sha256 = "Skipped (>64 MB)"
      }
    }
  }

  Dialog(onDismissRequest = onDismiss) {
    LiquidGlassCard(elevated = true, shape = RoundedCornerShape(28.dp)) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          FileItemThumbnail(item = item, size = 48.dp)
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = "Properties",
              style = MaterialTheme.typography.titleLarge,
              color = palette.textPrimary,
            )
            Text(
              text = item.name,
              style = MaterialTheme.typography.bodySmall,
              color = palette.textSecondary,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
          }
        }
        Spacer(modifier = Modifier.height(14.dp))
        HorizontalDivider(color = palette.divider)
        Spacer(modifier = Modifier.height(10.dp))

        PropRow("Path", item.path)
        PropRow("Type", if (item.isDirectory) "Directory" else "${item.category.label} (${item.extension.uppercase().ifEmpty { "None" }})")
        if (item.isDirectory) {
          PropRow("Contains", folderStats?.let { "${it.first} items (${FormatUtils.formatFileSize(it.second)})" } ?: "Calculating...")
        } else {
          PropRow("Size", "${FormatUtils.formatFileSize(item.sizeBytes)} (${item.sizeBytes} bytes)")
        }
        PropRow("Modified", FormatUtils.formatDateTime(item.lastModified))
        PropRow(
          "Permissions",
          buildString {
            append(if (item.canRead) "Readable" else "Locked")
            append(" • ")
            append(if (item.canWrite) "Writable" else "Read-only")
          },
        )
        if (!item.isDirectory) {
          PropRow("MD5", md5 ?: "Computing...")
          PropRow("SHA-256", sha256 ?: "Computing...")
        }

        Spacer(modifier = Modifier.height(14.dp))
        GlossyAccentButton(
          text = "Close",
          onClick = onDismiss,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    }
  }
}

@Composable
private fun PropRow(label: String, value: String) {
  val palette = LocalLiquidGlassPalette.current
  Column(modifier = Modifier.padding(vertical = 5.dp)) {
    Text(
      text = label,
      style = MaterialTheme.typography.labelMedium,
      color = palette.accent.primary,
    )
    Text(
      text = value,
      style = MaterialTheme.typography.bodyMedium,
      color = palette.textPrimary,
    )
  }
}

@Composable
fun OperationProgressOverlay(
  progress: OperationProgress,
  onCancel: () -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  Dialog(
    onDismissRequest = {},
    properties = DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
  ) {
    LiquidGlassCard(elevated = true, shape = RoundedCornerShape(26.dp)) {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text(
          text = progress.title,
          style = MaterialTheme.typography.titleLarge,
          color = palette.textPrimary,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = progress.currentItem,
          style = MaterialTheme.typography.bodySmall,
          color = palette.textSecondary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Spacer(modifier = Modifier.height(14.dp))
        LinearProgressIndicator(
          progress = { progress.fraction.coerceIn(0f, 1f) },
          color = palette.accent.primary,
          trackColor = palette.accent.softTint,
          modifier = Modifier
            .fillMaxWidth()
            .height(8.dp)
            .clip(CircleShape),
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "${progress.completedCount} / ${progress.totalCount}",
            style = MaterialTheme.typography.labelSmall,
            color = palette.textSecondary,
          )
          TextButton(onClick = onCancel) {
            Text("Cancel", color = DangerRed)
          }
        }
      }
    }
  }
}

@Composable
fun FolderPickerDialog(
  title: String,
  initialPath: String,
  onDismiss: () -> Unit,
  onSelectFolder: (String) -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  var currentPath by remember { mutableStateOf(initialPath) }
  var showCreateFolder by remember { mutableStateOf(false) }

  val subfolders = remember(currentPath) {
    val dir = File(currentPath)
    dir.listFiles()
      ?.filter { it.isDirectory && !it.name.startsWith(".") }
      ?.sortedBy { it.name.lowercase() }
      ?: emptyList()
  }

  if (showCreateFolder) {
    InputNameDialog(
      title = "New Destination Folder",
      initialValue = "",
      placeholder = "Folder name",
      confirmLabel = "Create",
      onDismiss = { showCreateFolder = false },
      onConfirm = { name, _ ->
        val created = File(currentPath, name)
        if (created.mkdirs()) {
          currentPath = created.absolutePath
        }
        showCreateFolder = false
      },
    )
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
  ) {
    LiquidGlassCard(
      elevated = true,
      shape = RoundedCornerShape(28.dp),
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 18.dp),
    ) {
      Column(modifier = Modifier.fillMaxWidth()) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = title,
            style = MaterialTheme.typography.titleLarge,
            color = palette.textPrimary,
          )
          Box(
            modifier = Modifier
              .size(40.dp)
              .clip(CircleShape)
              .background(palette.accent.softTint)
              .clickable { showCreateFolder = true },
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Filled.CreateNewFolder,
              contentDescription = "New Folder",
              tint = palette.accent.primary,
              modifier = Modifier.size(20.dp),
            )
          }
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = currentPath,
          style = MaterialTheme.typography.labelSmall,
          color = palette.textSecondary,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
        )
        Spacer(modifier = Modifier.height(10.dp))

        val parentFile = File(currentPath).parentFile
        if (parentFile != null && parentFile.canRead()) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .clickable { currentPath = parentFile.absolutePath }
              .padding(horizontal = 8.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(
              imageVector = Icons.Filled.ArrowUpward,
              contentDescription = "Parent folder",
              tint = palette.accent.primary,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(".. (Parent folder)", style = MaterialTheme.typography.bodyMedium, color = palette.accent.primary)
          }
        }

        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 180.dp, max = 300.dp)
            .border(1.dp, palette.divider, RoundedCornerShape(14.dp))
            .padding(4.dp),
        ) {
          if (subfolders.isEmpty()) {
            item {
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .padding(24.dp),
                contentAlignment = Alignment.Center,
              ) {
                Text(
                  text = "No subfolders here",
                  style = MaterialTheme.typography.bodySmall,
                  color = palette.textMuted,
                )
              }
            }
          } else {
            items(subfolders, key = { it.absolutePath }) { folder ->
              Row(
                modifier = Modifier
                  .fillMaxWidth()
                  .clip(RoundedCornerShape(12.dp))
                  .clickable { currentPath = folder.absolutePath }
                  .padding(horizontal = 10.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Icon(
                  imageVector = Icons.Filled.Folder,
                  contentDescription = null,
                  tint = FolderGold,
                  modifier = Modifier.size(22.dp),
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                  text = folder.name,
                  style = MaterialTheme.typography.bodyMedium,
                  color = palette.textPrimary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(14.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          GlossyAccentButton(
            text = "Cancel",
            isSecondary = true,
            onClick = onDismiss,
            modifier = Modifier.weight(1f),
          )
          GlossyAccentButton(
            text = "Select Folder",
            onClick = { onSelectFolder(currentPath) },
            modifier = Modifier.weight(1f),
          )
        }
      }
    }
  }
}
