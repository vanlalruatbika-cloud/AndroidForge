package com.example.utils

import android.webkit.MimeTypeMap
import java.io.File
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.log10
import kotlin.math.pow

enum class FileCategory(val label: String) {
  FOLDER("Folder"),
  IMAGE("Image"),
  VIDEO("Video"),
  AUDIO("Audio"),
  PDF("PDF"),
  TEXT("Document"),
  DOCUMENT("Document"),
  ARCHIVE("Archive"),
  APK("APK"),
  OTHER("File"),
}

object FormatUtils {

  private val imageExts = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp", "heic", "heif")
  private val videoExts = setOf("mp4", "mkv", "avi", "mov", "webm", "3gp", "m4v", "ts")
  private val audioExts = setOf("mp3", "wav", "ogg", "flac", "aac", "m4a", "opus", "wma")
  private val textExts = setOf(
    "txt", "md", "json", "xml", "kt", "kts", "java", "py", "js", "ts", "html", "css",
    "csv", "log", "ini", "cfg", "conf", "yaml", "yml", "properties", "sh", "gradle", "sql",
  )
  private val docExts = setOf("doc", "docx", "xls", "xlsx", "ppt", "pptx", "odt", "rtf")
  private val archiveExts = setOf("zip", "rar", "7z", "tar", "gz", "tgz", "bz2", "xz", "jar")

  fun getExtension(name: String): String {
    val dot = name.lastIndexOf('.')
    return if (dot >= 0 && dot < name.length - 1) {
      name.substring(dot + 1).lowercase(Locale.US)
    } else {
      ""
    }
  }

  fun classifyFile(file: File): FileCategory {
    if (file.isDirectory) return FileCategory.FOLDER
    return classifyName(file.name, isDirectory = false)
  }

  fun classifyName(name: String, isDirectory: Boolean): FileCategory {
    if (isDirectory) return FileCategory.FOLDER
    return when (getExtension(name)) {
      in imageExts -> FileCategory.IMAGE
      in videoExts -> FileCategory.VIDEO
      in audioExts -> FileCategory.AUDIO
      "pdf" -> FileCategory.PDF
      in textExts -> FileCategory.TEXT
      in docExts -> FileCategory.DOCUMENT
      in archiveExts -> FileCategory.ARCHIVE
      "apk", "apks", "xapk" -> FileCategory.APK
      else -> FileCategory.OTHER
    }
  }

  fun getMimeType(file: File): String {
    val ext = getExtension(file.name)
    if (ext.isEmpty()) return "*/*"
    return MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: when (ext) {
      "apk" -> "application/vnd.android.package-archive"
      "7z" -> "application/x-7z-compressed"
      "rar" -> "application/vnd.rar"
      "zip" -> "application/zip"
      "md", "kt", "kts", "log", "json", "yaml", "yml" -> "text/plain"
      else -> "*/*"
    }
  }

  fun formatFileSize(bytes: Long): String {
    if (bytes <= 0L) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (log10(bytes.toDouble()) / log10(1024.0)).toInt().coerceIn(0, units.lastIndex)
    val value = bytes / 1024.0.pow(digitGroups.toDouble())
    return if (digitGroups == 0) {
      "$bytes B"
    } else {
      String.format(Locale.US, "%.1f %s", value, units[digitGroups])
    }
  }

  fun formatDate(millis: Long): String {
    if (millis <= 0L) return "--"
    val sdf = SimpleDateFormat("yyyy/MM/dd", Locale.getDefault())
    return sdf.format(Date(millis))
  }

  fun formatDateTime(millis: Long): String {
    if (millis <= 0L) return "--"
    val sdf = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())
    return sdf.format(Date(millis))
  }

  fun formatRelativeTime(millis: Long): String {
    if (millis <= 0L) return ""
    val diff = System.currentTimeMillis() - millis
    val minutes = diff / 60_000L
    val hours = diff / 3_600_000L
    val days = diff / 86_400_000L
    return when {
      minutes < 1 -> "Just now"
      minutes < 60 -> "${minutes}m ago"
      hours < 24 -> "${hours}h ago"
      days < 7 -> "${days}d ago"
      else -> formatDate(millis)
    }
  }

  fun formatDuration(millis: Long): String {
    val totalSeconds = (millis / 1000L).coerceAtLeast(0L)
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
      String.format(Locale.US, "%d:%02d:%02d", hours, minutes, seconds)
    } else {
      String.format(Locale.US, "%02d:%02d", minutes, seconds)
    }
  }

  fun computeDigest(file: File, algorithm: String): String {
    return try {
      val digest = MessageDigest.getInstance(algorithm)
      file.inputStream().use { input ->
        val buffer = ByteArray(16 * 1024)
        var read: Int
        while (input.read(buffer).also { read = it } != -1) {
          digest.update(buffer, 0, read)
        }
      }
      digest.digest().joinToString("") { "%02x".format(it) }
    } catch (e: Exception) {
      "Unavailable"
    }
  }
}
