package com.example.viewers

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.components.FilePropertiesDialog
import com.example.components.LiquidGlassBackground
import com.example.components.LiquidGlassCard
import com.example.data.FileItem
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalLiquidGlassPalette
import com.example.utils.FileCategory
import com.example.utils.FormatUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun TextViewerScreen(
  filePath: String,
  onBack: () -> Unit,
  onShare: (FileItem) -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  val scope = rememberCoroutineScope()
  val snackbarHostState = remember { SnackbarHostState() }
  val file = remember(filePath) { File(filePath) }
  val item = remember(filePath) {
    FileItem(
      path = file.absolutePath,
      name = file.name,
      isDirectory = false,
      sizeBytes = file.length(),
      lastModified = file.lastModified(),
      category = FileCategory.TEXT,
      extension = FormatUtils.getExtension(file.name),
    )
  }

  var isLoading by remember { mutableStateOf(true) }
  var isEditing by remember { mutableStateOf(false) }
  var truncated by remember { mutableStateOf(false) }
  var content by remember { mutableStateOf("") }
  var errorMsg by remember { mutableStateOf<String?>(null) }
  var showInfo by remember { mutableStateOf(false) }

  LaunchedEffect(filePath) {
    isLoading = true
    withContext(Dispatchers.IO) {
      try {
        val maxBytes = 512 * 1024L
        if (file.length() > maxBytes) {
          truncated = true
          file.inputStream().bufferedReader().use { reader ->
            val buf = CharArray(256 * 1024)
            val count = reader.read(buf)
            content = if (count > 0) String(buf, 0, count) else ""
          }
        } else {
          truncated = false
          content = file.readText()
        }
      } catch (e: Exception) {
        errorMsg = "Could not read file: ${e.message ?: "unsupported encoding"}"
      }
    }
    isLoading = false
  }

  if (showInfo) {
    FilePropertiesDialog(item = item, onDismiss = { showInfo = false })
  }

  LiquidGlassBackground {
    Box(modifier = Modifier.fillMaxSize()) {
      Column(
        modifier = Modifier
          .fillMaxSize()
          .statusBarsPadding()
          .navigationBarsPadding()
          .padding(horizontal = 16.dp, vertical = 10.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          IconButton(onClick = onBack) {
            Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back",
              tint = palette.textPrimary,
            )
          }
          Column(modifier = Modifier.weight(1f)) {
            Text(
              text = file.name,
              style = MaterialTheme.typography.titleMedium,
              color = palette.textPrimary,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )
            Text(
              text = "${FormatUtils.formatFileSize(file.length())} • ${if (truncated) "Preview (first 512 KB)" else "Text Document"}",
              style = MaterialTheme.typography.bodySmall,
              color = palette.textSecondary,
            )
          }
          if (!truncated && file.canWrite() && errorMsg == null) {
            IconButton(
              onClick = {
                if (isEditing) {
                  scope.launch {
                    val saved = withContext(Dispatchers.IO) {
                      runCatching { file.writeText(content) }
                    }
                    saved.onSuccess {
                      isEditing = false
                      snackbarHostState.showSnackbar("Saved changes to ${file.name}")
                    }.onFailure { err ->
                      snackbarHostState.showSnackbar("Save failed: ${err.message}")
                    }
                  }
                } else {
                  isEditing = true
                }
              },
            ) {
              Icon(
                imageVector = if (isEditing) Icons.Filled.Save else Icons.Filled.Edit,
                contentDescription = if (isEditing) "Save" else "Edit",
                tint = palette.accent.primary,
              )
            }
          }
          IconButton(onClick = { onShare(item) }) {
            Icon(Icons.Filled.Share, contentDescription = "Share", tint = palette.textPrimary)
          }
          IconButton(onClick = { showInfo = true }) {
            Icon(Icons.Filled.Info, contentDescription = "Info", tint = palette.textPrimary)
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LiquidGlassCard(
          elevated = true,
          shape = RoundedCornerShape(24.dp),
          contentPadding = PaddingValues(12.dp),
          modifier = Modifier
            .fillMaxWidth()
            .weight(1f),
        ) {
          when {
            isLoading -> {
              Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = palette.accent.primary)
              }
            }
            errorMsg != null -> {
              Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(errorMsg!!, color = MaterialTheme.colorScheme.error)
              }
            }
            isEditing -> {
              OutlinedTextField(
                value = content,
                onValueChange = { content = it },
                textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFontFamily),
                modifier = Modifier.fillMaxSize(),
              )
            }
            else -> {
              val lines = remember(content) { content.lines() }
              LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(2.dp),
              ) {
                itemsIndexed(lines) { index, line ->
                  Row(modifier = Modifier.fillMaxWidth()) {
                    Text(
                      text = "${index + 1}",
                      fontFamily = JetBrainsMonoFontFamily,
                      style = MaterialTheme.typography.labelSmall,
                      color = palette.textMuted,
                      modifier = Modifier.width(38.dp),
                    )
                    Text(
                      text = line,
                      fontFamily = JetBrainsMonoFontFamily,
                      style = MaterialTheme.typography.bodySmall,
                      color = palette.textPrimary,
                      modifier = Modifier.weight(1f),
                    )
                  }
                }
              }
            }
          }
        }
      }

      SnackbarHost(
        hostState = snackbarHostState,
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .navigationBarsPadding()
          .padding(16.dp),
      )
    }
  }
}
