package com.example.viewers

import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Forward10
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.example.components.FilePropertiesDialog
import com.example.components.LiquidGlassBackground
import com.example.components.LiquidGlassCard
import com.example.data.FileItem
import com.example.ui.theme.LocalLiquidGlassPalette
import com.example.utils.FileCategory
import com.example.utils.FormatUtils
import kotlinx.coroutines.delay
import java.io.File

@Composable
fun AudioPlayerScreen(
  filePath: String,
  onBack: () -> Unit,
  onShare: (FileItem) -> Unit,
) {
  val context = LocalContext.current
  val palette = LocalLiquidGlassPalette.current
  val file = remember(filePath) { File(filePath) }
  val item = remember(filePath) {
    FileItem(
      path = file.absolutePath,
      name = file.name,
      isDirectory = false,
      sizeBytes = file.length(),
      lastModified = file.lastModified(),
      category = FileCategory.AUDIO,
      extension = FormatUtils.getExtension(file.name),
    )
  }

  val metadata = remember(filePath) {
    val mmr = MediaMetadataRetriever()
    try {
      mmr.setDataSource(file.absolutePath)
      val title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
        ?.takeIf { it.isNotBlank() } ?: file.nameWithoutExtension
      val artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
        ?.takeIf { it.isNotBlank() } ?: "Unknown Artist"
      val album = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
        ?.takeIf { it.isNotBlank() } ?: file.extension.uppercase()
      Triple(title, artist, album)
    } catch (_: Exception) {
      Triple(file.nameWithoutExtension, "Local Audio", file.extension.uppercase())
    } finally {
      runCatching { mmr.release() }
    }
  }

  var isPlaying by remember { mutableStateOf(true) }
  var positionMs by remember { mutableLongStateOf(0L) }
  var durationMs by remember { mutableLongStateOf(0L) }
  var showInfo by remember { mutableStateOf(false) }

  val exoPlayer = remember(filePath) {
    ExoPlayer.Builder(context).build().apply {
      setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
      prepare()
      playWhenReady = true
    }
  }

  DisposableEffect(exoPlayer) {
    val listener = object : Player.Listener {
      override fun onIsPlayingChanged(playing: Boolean) {
        isPlaying = playing
      }
    }
    exoPlayer.addListener(listener)
    onDispose {
      exoPlayer.removeListener(listener)
      exoPlayer.release()
    }
  }

  LaunchedEffect(exoPlayer) {
    while (true) {
      positionMs = exoPlayer.currentPosition.coerceAtLeast(0L)
      durationMs = exoPlayer.duration.coerceAtLeast(1L)
      delay(250L)
    }
  }

  val spinTransition = rememberInfiniteTransition(label = "discSpin")
  val discAngle by spinTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(durationMillis = 12_000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart,
    ),
    label = "discAngle",
  )

  if (showInfo) {
    FilePropertiesDialog(item = item, onDismiss = { showInfo = false })
  }

  LiquidGlassBackground {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(horizontal = 20.dp, vertical = 12.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        IconButton(onClick = onBack) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back",
            tint = palette.textPrimary,
          )
        }
        Text(
          text = "Audio Player",
          style = MaterialTheme.typography.titleLarge,
          color = palette.textPrimary,
          modifier = Modifier.weight(1f),
        )
        IconButton(onClick = { onShare(item) }) {
          Icon(Icons.Filled.Share, contentDescription = "Share", tint = palette.textPrimary)
        }
        IconButton(onClick = { showInfo = true }) {
          Icon(Icons.Filled.Info, contentDescription = "Info", tint = palette.textPrimary)
        }
      }

      Spacer(modifier = Modifier.weight(1f))

      LiquidGlassCard(
        elevated = true,
        shape = RoundedCornerShape(32.dp),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 18.dp, horizontal = 8.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          Box(
            modifier = Modifier
              .size(164.dp)
              .graphicsLayer { rotationZ = if (isPlaying) discAngle else 0f }
              .shadow(16.dp, CircleShape, ambientColor = palette.shadowColor)
              .clip(CircleShape)
              .background(
                Brush.radialGradient(
                  colors = listOf(
                    palette.accent.softTint,
                    palette.accent.primary.copy(alpha = 0.35f),
                    Color.White.copy(alpha = 0.85f),
                  ),
                ),
              )
              .border(2.dp, palette.glassBorderTop, CircleShape),
            contentAlignment = Alignment.Center,
          ) {
            Icon(
              imageVector = Icons.Filled.MusicNote,
              contentDescription = "Audio Track",
              tint = palette.accent.primary,
              modifier = Modifier.size(64.dp),
            )
          }

          Spacer(modifier = Modifier.height(22.dp))

          Text(
            text = metadata.first,
            style = MaterialTheme.typography.headlineMedium,
            color = palette.textPrimary,
            textAlign = TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "${metadata.second} • ${metadata.third}",
            style = MaterialTheme.typography.bodyMedium,
            color = palette.textSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "${FormatUtils.formatFileSize(file.length())} • ${file.extension.uppercase()}",
            style = MaterialTheme.typography.labelSmall,
            color = palette.textMuted,
          )

          Spacer(modifier = Modifier.height(20.dp))

          Slider(
            value = positionMs.toFloat().coerceIn(0f, durationMs.toFloat()),
            onValueChange = { exoPlayer.seekTo(it.toLong()) },
            valueRange = 0f..durationMs.toFloat().coerceAtLeast(1f),
            colors = SliderDefaults.colors(
              thumbColor = palette.accent.primary,
              activeTrackColor = palette.accent.primary,
              inactiveTrackColor = palette.accent.softTint,
            ),
            modifier = Modifier.fillMaxWidth(),
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Text(
              text = FormatUtils.formatDuration(positionMs),
              style = MaterialTheme.typography.labelSmall,
              color = palette.textSecondary,
            )
            Text(
              text = FormatUtils.formatDuration(durationMs),
              style = MaterialTheme.typography.labelSmall,
              color = palette.textSecondary,
            )
          }

          Spacer(modifier = Modifier.height(14.dp))

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
          ) {
            IconButton(
              onClick = { exoPlayer.seekTo((positionMs - 10_000L).coerceAtLeast(0L)) },
              modifier = Modifier.size(52.dp),
            ) {
              Icon(
                imageVector = Icons.Filled.Replay10,
                contentDescription = "Rewind 10s",
                tint = palette.textPrimary,
                modifier = Modifier.size(30.dp),
              )
            }
            Spacer(modifier = Modifier.width(18.dp))
            IconButton(
              onClick = {
                if (exoPlayer.isPlaying) exoPlayer.pause() else exoPlayer.play()
              },
              modifier = Modifier
                .size(68.dp)
                .shadow(12.dp, CircleShape, ambientColor = palette.shadowColor)
                .clip(CircleShape)
                .background(
                  Brush.linearGradient(listOf(palette.accent.secondary, palette.accent.primary)),
                ),
            ) {
              Icon(
                imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                contentDescription = if (isPlaying) "Pause" else "Play",
                tint = Color.White,
                modifier = Modifier.size(34.dp),
              )
            }
            Spacer(modifier = Modifier.width(18.dp))
            IconButton(
              onClick = { exoPlayer.seekTo((positionMs + 10_000L).coerceAtMost(durationMs)) },
              modifier = Modifier.size(52.dp),
            ) {
              Icon(
                imageVector = Icons.Filled.Forward10,
                contentDescription = "Forward 10s",
                tint = palette.textPrimary,
                modifier = Modifier.size(30.dp),
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.weight(1f))
    }
  }
}
