package com.example.ui.theme

import androidx.compose.ui.graphics.Color

enum class ThemeMode(val label: String) {
  LIQUID_GLASS("Liquid Glass"),
  LIGHT("Light"),
  DARK("Dark"),
}

enum class AccentPalette(
  val label: String,
  val primary: Color,
  val secondary: Color,
  val softTint: Color,
  val glow: Color,
) {
  LAVENDER(
    label = "Huzuni Lavender",
    primary = Color(0xFF7B6CF6),
    secondary = Color(0xFF9F92FF),
    softTint = Color(0xFFECE9FE),
    glow = Color(0x558E7CFF),
  ),
  PERIWINKLE(
    label = "Crystal Blue",
    primary = Color(0xFF5B8DEF),
    secondary = Color(0xFF88B2FF),
    softTint = Color(0xFFE7F0FE),
    glow = Color(0x555B8DEF),
  ),
  ROSE_QUARTZ(
    label = "Rose Quartz",
    primary = Color(0xFFD66A9E),
    secondary = Color(0xFFEC96BF),
    softTint = Color(0xFFFCEBF3),
    glow = Color(0x55D66A9E),
  ),
  MINT_FROST(
    label = "Mint Frost",
    primary = Color(0xFF39A28C),
    secondary = Color(0xFF69C6B1),
    softTint = Color(0xFFE5F6F2),
    glow = Color(0x5539A28C),
  ),
}

// Core White Liquid Glass Palette
val GlassPureWhite = Color(0xFFFFFFFF)
val GlassSnowCanvas = Color(0xFFF6F6FB)
val GlassLavenderMist = Color(0xFFEDEAF8)
val GlassSoftLilac = Color(0xFFE3DDF8)
val GlassInkPrimary = Color(0xFF1A1829)
val GlassInkSecondary = Color(0xFF5D5A72)
val GlassInkMuted = Color(0xFF8A87A0)

// Dark Mode Liquid Glass Palette
val DarkGlassCanvas = Color(0xFF10101A)
val DarkGlassSurface = Color(0xCC1C1B2B)
val DarkGlassElevated = Color(0xE6252438)
val DarkInkPrimary = Color(0xFFF4F3FA)
val DarkInkSecondary = Color(0xFFB8B4CE)

// Semantic File & Category Colors
val FolderGold = Color(0xFFF6B93B)
val FolderGoldDeep = Color(0xFFE59D18)
val CategoryImageTint = Color(0xFF7B6CF6)
val CategoryVideoTint = Color(0xFF5B8DEF)
val CategoryAudioTint = Color(0xFFD66A9E)
val CategoryDocTint = Color(0xFF39A28C)
val CategoryPdfTint = Color(0xFFE55353)
val CategoryArchiveTint = Color(0xFF8667F2)
val CategoryApkTint = Color(0xFF43A047)
val DangerRed = Color(0xFFD93B4E)
val SuccessGreen = Color(0xFF28A76E)
