package com.example.viewers

import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.components.FilePropertiesDialog
import com.example.components.LiquidGlassBackground
import com.example.data.FileItem
import com.example.ui.theme.LocalLiquidGlassPalette
import com.example.utils.FileCategory
import com.example.utils.FormatUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.io.File

@Composable
fun PdfViewerScreen(
  filePath: String,
  onBack: () -> Unit,
  onShare: (FileItem) -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  val file = remember(filePath) { File(filePath) }
  val item = remember(filePath) {
    FileItem(
      path = file.absolutePath,
      name = file.name,
      isDirectory = false,
      sizeBytes = file.length(),
      lastModified = file.lastModified(),
      category = FileCategory.PDF,
      extension = "pdf",
    )
  }

  var pageCount by remember { mutableIntStateOf(0) }
  var errorMsg by remember { mutableStateOf<String?>(null) }
  var renderer by remember { mutableStateOf<PdfRenderer?>(null) }
  var pfd by remember { mutableStateOf<ParcelFileDescriptor?>(null) }
  val renderMutex = remember { Mutex() }
  var showInfo by remember { mutableStateOf(false) }

  LaunchedEffect(filePath) {
    withContext(Dispatchers.IO) {
      try {
        val descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
        val pdfRenderer = PdfRenderer(descriptor)
        pfd = descriptor
        renderer = pdfRenderer
        pageCount = pdfRenderer.pageCount
      } catch (e: Exception) {
        errorMsg = "Cannot open PDF: ${e.message ?: "invalid or password-protected PDF"}"
      }
    }
  }

  DisposableEffect(filePath) {
    onDispose {
      runCatching { renderer?.close() }
      runCatching { pfd?.close() }
    }
  }

  val listState = rememberLazyListState()
  val currentPage by remember {
    derivedStateOf { (listState.firstVisibleItemIndex + 1).coerceAtLeast(1) }
  }

  if (showInfo) {
    FilePropertiesDialog(item = item, onDismiss = { showInfo = false })
  }

  LiquidGlassBackground {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
        .navigationBarsPadding(),
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        IconButton(onClick = onBack) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back",
            tint = palette.textPrimary,
          )
        }
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = file.name,
            style = MaterialTheme.typography.titleMedium,
            color = palette.textPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          Text(
            text = if (pageCount > 0) "Page $currentPage of $pageCount • ${FormatUtils.formatFileSize(file.length())}" else FormatUtils.formatFileSize(file.length()),
            style = MaterialTheme.typography.bodySmall,
            color = palette.textSecondary,
          )
        }
        IconButton(onClick = { onShare(item) }) {
          Icon(Icons.Filled.Share, contentDescription = "Share", tint = palette.textPrimary)
        }
        IconButton(onClick = { showInfo = true }) {
          Icon(Icons.Filled.Info, contentDescription = "Info", tint = palette.textPrimary)
        }
      }

      when {
        errorMsg != null -> {
          Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text(errorMsg!!, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(24.dp))
          }
        }
        renderer == null -> {
          Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = palette.accent.primary)
          }
        }
        else -> {
          LazyColumn(
            state = listState,
            contentPadding = PaddingValues(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize(),
          ) {
            items(pageCount) { index ->
              PdfPageCard(
                renderer = renderer!!,
                pageIndex = index,
                mutex = renderMutex,
              )
            }
          }
        }
      }
    }
  }
}

@Composable
private fun PdfPageCard(
  renderer: PdfRenderer,
  pageIndex: Int,
  mutex: Mutex,
) {
  val palette = LocalLiquidGlassPalette.current
  val bitmap by produceState<Bitmap?>(initialValue = null, pageIndex, renderer) {
    value = withContext(Dispatchers.IO) {
      mutex.withLock {
        runCatching {
          renderer.openPage(pageIndex).use { page ->
            val targetWidth = 1080
            val targetHeight = ((page.height.toFloat() / page.width.toFloat()) * targetWidth).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(android.graphics.Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            bmp
          }
        }.getOrNull()
      }
    }
  }

  val shape = RoundedCornerShape(18.dp)
  val bmp = bitmap
  if (bmp != null) {
    Image(
      bitmap = bmp.asImageBitmap(),
      contentDescription = "PDF Page ${pageIndex + 1}",
      contentScale = ContentScale.FillWidth,
      modifier = Modifier
        .fillMaxWidth()
        .shadow(8.dp, shape, ambientColor = palette.shadowColor)
        .clip(shape)
        .background(Color.White),
    )
  } else {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .aspectRatio(0.75f)
        .clip(shape)
        .background(palette.glassSurface),
      contentAlignment = Alignment.Center,
    ) {
      CircularProgressIndicator(color = palette.accent.primary)
    }
  }
}
