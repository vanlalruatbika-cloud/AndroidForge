package com.example.ui.theme

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

@Immutable
data class LiquidGlassPalette(
  val themeMode: ThemeMode,
  val accent: AccentPalette,
  val isDark: Boolean,
  val backgroundBase: Color,
  val backgroundMistPrimary: Color,
  val backgroundMistSecondary: Color,
  val glassSurface: Color,
  val glassSurfaceElevated: Color,
  val glassBorderTop: Color,
  val glassBorderBottom: Color,
  val glassHighlight: Color,
  val shadowColor: Color,
  val navBarSurface: Color,
  val navActivePill: Color,
  val textPrimary: Color,
  val textSecondary: Color,
  val textMuted: Color,
  val divider: Color,
)

val LocalLiquidGlassPalette = staticCompositionLocalOf {
  createLiquidGlassPalette(ThemeMode.LIQUID_GLASS, AccentPalette.LAVENDER)
}

fun createLiquidGlassPalette(mode: ThemeMode, accent: AccentPalette): LiquidGlassPalette {
  return when (mode) {
    ThemeMode.LIQUID_GLASS -> LiquidGlassPalette(
      themeMode = mode,
      accent = accent,
      isDark = false,
      backgroundBase = Color(0xFFF6F6FC),
      backgroundMistPrimary = Color(0xFFE7E2FA),
      backgroundMistSecondary = Color(0xFFFDFDFF),
      glassSurface = Color(0xC8FFFFFF),
      glassSurfaceElevated = Color(0xE8FFFFFF),
      glassBorderTop = Color(0xF5FFFFFF),
      glassBorderBottom = accent.primary.copy(alpha = 0.22f),
      glassHighlight = Color(0x88FFFFFF),
      shadowColor = Color(0x1C6A5ACD),
      navBarSurface = Color(0xE0FFFFFF),
      navActivePill = accent.softTint,
      textPrimary = GlassInkPrimary,
      textSecondary = GlassInkSecondary,
      textMuted = GlassInkMuted,
      divider = Color(0x1A6B6299),
    )

    ThemeMode.LIGHT -> LiquidGlassPalette(
      themeMode = mode,
      accent = accent,
      isDark = false,
      backgroundBase = Color(0xFFFAFAFD),
      backgroundMistPrimary = accent.softTint.copy(alpha = 0.55f),
      backgroundMistSecondary = Color(0xFFFFFFFF),
      glassSurface = Color(0xF5FFFFFF),
      glassSurfaceElevated = Color(0xFFFFFFFF),
      glassBorderTop = Color(0xFFEAE8F4),
      glassBorderBottom = Color(0xFFDCD8EE),
      glassHighlight = Color(0x66FFFFFF),
      shadowColor = Color(0x142A244D),
      navBarSurface = Color(0xFAFFFFFF),
      navActivePill = accent.softTint,
      textPrimary = GlassInkPrimary,
      textSecondary = GlassInkSecondary,
      textMuted = GlassInkMuted,
      divider = Color(0x18000000),
    )

    ThemeMode.DARK -> LiquidGlassPalette(
      themeMode = mode,
      accent = accent,
      isDark = true,
      backgroundBase = DarkGlassCanvas,
      backgroundMistPrimary = accent.primary.copy(alpha = 0.24f),
      backgroundMistSecondary = Color(0xFF1A192A),
      glassSurface = Color(0xBF1E1D2F),
      glassSurfaceElevated = Color(0xE026253C),
      glassBorderTop = Color(0x38FFFFFF),
      glassBorderBottom = accent.primary.copy(alpha = 0.28f),
      glassHighlight = Color(0x22FFFFFF),
      shadowColor = Color(0x4D000000),
      navBarSurface = Color(0xDB1C1B2E),
      navActivePill = accent.primary.copy(alpha = 0.26f),
      textPrimary = DarkInkPrimary,
      textSecondary = DarkInkSecondary,
      textMuted = Color(0xFF8C88A6),
      divider = Color(0x26FFFFFF),
    )
  }
}

private val AppShapes = Shapes(
  extraSmall = RoundedCornerShape(10.dp),
  small = RoundedCornerShape(14.dp),
  medium = RoundedCornerShape(20.dp),
  large = RoundedCornerShape(26.dp),
  extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun HzFileManagerTheme(
  themeMode: ThemeMode = ThemeMode.LIQUID_GLASS,
  accentPalette: AccentPalette = AccentPalette.LAVENDER,
  content: @Composable () -> Unit,
) {
  val effectiveMode = if (themeMode == ThemeMode.DARK) ThemeMode.DARK else themeMode
  val palette = createLiquidGlassPalette(effectiveMode, accentPalette)

  val colorScheme = if (palette.isDark) {
    darkColorScheme(
      primary = accentPalette.secondary,
      onPrimary = Color(0xFF141126),
      primaryContainer = accentPalette.primary.copy(alpha = 0.28f),
      onPrimaryContainer = DarkInkPrimary,
      secondary = accentPalette.primary,
      onSecondary = Color.White,
      background = palette.backgroundBase,
      onBackground = palette.textPrimary,
      surface = palette.glassSurfaceElevated,
      onSurface = palette.textPrimary,
      surfaceVariant = Color(0xFF28263D),
      onSurfaceVariant = palette.textSecondary,
      outline = Color(0xFF474463),
      error = DangerRed,
    )
  } else {
    lightColorScheme(
      primary = accentPalette.primary,
      onPrimary = Color.White,
      primaryContainer = accentPalette.softTint,
      onPrimaryContainer = GlassInkPrimary,
      secondary = accentPalette.secondary,
      onSecondary = Color.White,
      background = palette.backgroundBase,
      onBackground = palette.textPrimary,
      surface = palette.glassSurfaceElevated,
      onSurface = palette.textPrimary,
      surfaceVariant = GlassLavenderMist,
      onSurfaceVariant = palette.textSecondary,
      outline = Color(0xFFD5D0EA),
      error = DangerRed,
    )
  }

  val view = LocalView.current
  if (!view.isInEditMode) {
    SideEffect {
      val window = (view.context as? Activity)?.window
      if (window != null) {
        WindowCompat.getInsetsController(window, view).isAppearanceLightStatusBars = !palette.isDark
        WindowCompat.getInsetsController(window, view).isAppearanceLightNavigationBars = !palette.isDark
      }
    }
  }

  CompositionLocalProvider(LocalLiquidGlassPalette provides palette) {
    MaterialTheme(
      colorScheme = colorScheme,
      typography = Typography,
      shapes = AppShapes,
      content = content,
    )
  }
}
