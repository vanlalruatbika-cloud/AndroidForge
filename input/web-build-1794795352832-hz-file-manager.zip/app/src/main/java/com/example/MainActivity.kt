package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.navigation.HzNavHost
import com.example.permissions.StoragePermissionHelper
import com.example.screens.MainAppViewModel
import com.example.ui.theme.HzFileManagerTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      val sharedVm: MainAppViewModel = viewModel()
      val settings by sharedVm.settings.collectAsStateWithLifecycle()

      // Legacy runtime storage permission launcher for Android 7–10 (API 24–29)
      val legacyPermLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions(),
      ) {
        sharedVm.recheckPermissionsAndRefresh()
      }

      LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.R &&
          !StoragePermissionHelper.hasAllFilesAccess(this@MainActivity)
        ) {
          legacyPermLauncher.launch(
            arrayOf(
              Manifest.permission.READ_EXTERNAL_STORAGE,
              Manifest.permission.WRITE_EXTERNAL_STORAGE,
            ),
          )
        }
      }

      // Recheck MANAGE_EXTERNAL_STORAGE whenever user returns from Android Settings
      LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        sharedVm.recheckPermissionsAndRefresh()
      }

      HzFileManagerTheme(
        themeMode = settings.themeMode,
        accentPalette = settings.accentPalette,
      ) {
        HzNavHost(sharedVm = sharedVm)
      }
    }
  }
}
