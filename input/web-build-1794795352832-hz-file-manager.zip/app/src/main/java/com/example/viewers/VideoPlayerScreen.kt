package com.example.viewers

import android.app.Activity
import android.content.pm.ActivityInfo
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.example.components.FilePropertiesDialog
import com.example.data.FileItem
import com.example.utils.FileCategory
import com.example.utils.FormatUtils
import java.io.File

@Composable
fun VideoPlayerScreen(
  filePath: String,
  onBack: () -> Unit,
  onShare: (FileItem) -> Unit,
) {
  val context = LocalContext.current
  val file = remember(filePath) { File(filePath) }
  val item = remember(filePath) {
    FileItem(
      path = file.absolutePath,
      name = file.name,
      isDirectory = false,
      sizeBytes = file.length(),
      lastModified = file.lastModified(),
      category = FileCategory.VIDEO,
      extension = FormatUtils.getExtension(file.name),
    )
  }

  var isFullscreen by remember { mutableStateOf(false) }
  var showInfo by remember { mutableStateOf(false) }

  val exoPlayer = remember(filePath) {
    ExoPlayer.Builder(context).build().apply {
      setMediaItem(MediaItem.fromUri(Uri.fromFile(file)))
      prepare()
      playWhenReady = true
    }
  }

  DisposableEffect(exoPlayer) {
    onDispose {
      exoPlayer.release()
      val act = context as? Activity
      act?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
    }
  }

  if (showInfo) {
    FilePropertiesDialog(item = item, onDismiss = { showInfo = false })
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(Color.Black),
  ) {
    AndroidView(
      factory = { ctx ->
        PlayerView(ctx).apply {
          player = exoPlayer
          useController = true
        }
      },
      modifier = Modifier
        .fillMaxSize()
        .navigationBarsPadding(),
    )

    Row(
      modifier = Modifier
        .fillMaxWidth()
        .align(Alignment.TopCenter)
        .background(Color.Black.copy(alpha = 0.5f))
        .statusBarsPadding()
        .padding(horizontal = 8.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      IconButton(onClick = onBack) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowBack,
          contentDescription = "Back",
          tint = Color.White,
        )
      }
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = file.name,
          style = MaterialTheme.typography.titleMedium,
          color = Color.White,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Text(
          text = FormatUtils.formatFileSize(file.length()),
          style = MaterialTheme.typography.bodySmall,
          color = Color.White.copy(alpha = 0.7f),
        )
      }
      IconButton(
        onClick = {
          val act = context as? Activity
          isFullscreen = !isFullscreen
          act?.requestedOrientation = if (isFullscreen) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
          } else {
            ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
          }
        },
      ) {
        Icon(
          imageVector = if (isFullscreen) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen,
          contentDescription = "Toggle fullscreen",
          tint = Color.White,
        )
      }
      IconButton(onClick = { onShare(item) }) {
        Icon(Icons.Filled.Share, contentDescription = "Share", tint = Color.White)
      }
      IconButton(onClick = { showInfo = true }) {
        Icon(Icons.Filled.Info, contentDescription = "Properties", tint = Color.White)
      }
    }
  }
}
