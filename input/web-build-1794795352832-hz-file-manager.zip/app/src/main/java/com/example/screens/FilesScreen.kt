package com.example.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.automirrored.filled.Sort
import androidx.compose.material.icons.automirrored.filled.ViewList
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Compress
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DriveFileMove
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.FolderOff
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SelectAll
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.components.ConfirmDeleteDialog
import com.example.components.FileContextMenuDialog
import com.example.components.FileItemThumbnail
import com.example.components.FilePropertiesDialog
import com.example.components.FolderPickerDialog
import com.example.components.GlossyAccentButton
import com.example.components.InputNameDialog
import com.example.components.LiquidGlassCard
import com.example.data.ClipboardMode
import com.example.data.FileItem
import com.example.data.SortDirection
import com.example.data.SortField
import com.example.data.ViewMode
import com.example.filemanager.DirectoryListingResult
import com.example.ui.theme.DangerRed
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.ui.theme.LocalLiquidGlassPalette
import com.example.utils.FormatUtils
import kotlinx.coroutines.launch
import java.io.File

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun FilesScreen(
  sharedVm: MainAppViewModel,
  initialPath: String?,
  onOpenSearch: () -> Unit,
  onOpenFile: (FileItem) -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  val scope = rememberCoroutineScope()
  val settings by sharedVm.settings.collectAsStateWithLifecycle()
  val overview by sharedVm.storageOverview.collectAsStateWithLifecycle()
  val clipboard by sharedVm.clipboard.collectAsStateWithLifecycle()
  val hasAccess by sharedVm.hasAllFilesAccess.collectAsStateWithLifecycle()

  val primaryRoot = remember(overview.primaryVolume) {
    overview.primaryVolume?.rootPath ?: sharedVm.storageRepository.getPrimaryRootPath()
  }

  var currentPath by remember { mutableStateOf(initialPath ?: primaryRoot) }
  LaunchedEffect(initialPath) {
    if (!initialPath.isNullOrBlank()) {
      currentPath = initialPath
    }
  }

  var listingState by remember { mutableStateOf<DirectoryListingResult?>(null) }
  var isLoading by remember { mutableStateOf(true) }
  var refreshTrigger by remember { mutableStateOf(0) }

  var viewMode by remember(settings.defaultViewMode) { mutableStateOf(settings.defaultViewMode) }
  var sortField by remember(settings.sortField) { mutableStateOf(settings.sortField) }
  var sortDirection by remember(settings.sortDirection) { mutableStateOf(settings.sortDirection) }

  var selectionMode by remember { mutableStateOf(false) }
  var selectedPaths by remember { mutableStateOf<Set<String>>(emptySet()) }

  var showVolumeMenu by remember { mutableStateOf(false) }
  var showNewMenu by remember { mutableStateOf(false) }
  var showNewFolderDialog by remember { mutableStateOf(false) }
  var showNewTextDialog by remember { mutableStateOf(false) }
  var showSortDialog by remember { mutableStateOf(false) }

  var contextTarget by remember { mutableStateOf<FileItem?>(null) }
  var renameTarget by remember { mutableStateOf<FileItem?>(null) }
  var deleteTargets by remember { mutableStateOf<List<FileItem>?>(null) }
  var propertiesTarget by remember { mutableStateOf<FileItem?>(null) }
  var compressTargets by remember { mutableStateOf<List<FileItem>?>(null) }
  var movePickerTargets by remember { mutableStateOf<List<FileItem>?>(null) }

  fun triggerRefresh() {
    refreshTrigger++
  }

  LaunchedEffect(currentPath, settings.showHiddenFiles, sortField, sortDirection, refreshTrigger, hasAccess) {
    isLoading = true
    listingState = sharedVm.fileOpsRepository.listDirectory(
      path = currentPath,
      showHidden = settings.showHiddenFiles,
      sortField = sortField,
      sortDirection = sortDirection,
    )
    isLoading = false
  }

  val activeVolume = remember(currentPath, overview.volumes) {
    overview.volumes.firstOrNull { currentPath.startsWith(it.rootPath) } ?: overview.primaryVolume
  }
  val activeRootPath = activeVolume?.rootPath ?: primaryRoot

  val canNavigateUp = currentPath.trimEnd('/') != activeRootPath.trimEnd('/') &&
    File(currentPath).parentFile != null

  BackHandler(enabled = selectionMode || canNavigateUp) {
    if (selectionMode) {
      selectionMode = false
      selectedPaths = emptySet()
    } else if (canNavigateUp) {
      File(currentPath).parentFile?.absolutePath?.let { currentPath = it }
    }
  }

  val currentItems = (listingState as? DirectoryListingResult.Success)?.items ?: emptyList()
  val selectedItems = remember(currentItems, selectedPaths) {
    currentItems.filter { it.path in selectedPaths }
  }

  // Dialogs
  if (showNewFolderDialog) {
    InputNameDialog(
      title = "Create New Folder",
      initialValue = "",
      placeholder = "Folder name",
      confirmLabel = "Create",
      onDismiss = { showNewFolderDialog = false },
      onConfirm = { name, _ ->
        showNewFolderDialog = false
        scope.launch {
          sharedVm.fileOpsRepository.createFolder(currentPath, name)
            .onSuccess {
              sharedVm.emitMessage("Created folder \"$name\".")
              triggerRefresh()
            }
            .onFailure {
              sharedVm.emitMessage(it.message ?: "Failed to create folder.")
            }
        }
      },
    )
  }

  if (showNewTextDialog) {
    InputNameDialog(
      title = "Create Text File",
      initialValue = "note.txt",
      placeholder = "File name (e.g. notes.txt)",
      confirmLabel = "Create",
      extraContentLabel = "Initial content (optional)",
      onDismiss = { showNewTextDialog = false },
      onConfirm = { name, extra ->
        showNewTextDialog = false
        scope.launch {
          sharedVm.fileOpsRepository.createTextFile(currentPath, name, extra)
            .onSuccess {
              sharedVm.emitMessage("Created \"$name\".")
              triggerRefresh()
            }
            .onFailure {
              sharedVm.emitMessage(it.message ?: "Failed to create text file.")
            }
        }
      },
    )
  }

  if (showSortDialog) {
    SortOptionsDialog(
      currentField = sortField,
      currentDirection = sortDirection,
      onDismiss = { showSortDialog = false },
      onApply = { field, dir ->
        sortField = field
        sortDirection = dir
        sharedVm.updateSort(field, dir)
        showSortDialog = false
      },
    )
  }

  contextTarget?.let { item ->
    FileContextMenuDialog(
      item = item,
      onDismiss = { contextTarget = null },
      onOpen = {
        if (item.isDirectory) {
          currentPath = item.path
        } else {
          onOpenFile(item)
        }
      },
      onOpenWith = { sharedVm.openWithExternal(item) },
      onShare = { sharedVm.shareItems(listOf(item)) },
      onCopy = { sharedVm.setClipboard(listOf(item), ClipboardMode.COPY) },
      onMove = {
        sharedVm.setClipboard(listOf(item), ClipboardMode.MOVE)
        movePickerTargets = listOf(item)
      },
      onRename = { renameTarget = item },
      onDelete = {
        if (settings.confirmBeforeDelete) {
          deleteTargets = listOf(item)
        } else {
          sharedVm.deleteItems(listOf(item)) { triggerRefresh() }
        }
      },
      onCompress = { compressTargets = listOf(item) },
      onProperties = { propertiesTarget = item },
    )
  }

  renameTarget?.let { item ->
    InputNameDialog(
      title = "Rename",
      initialValue = item.name,
      placeholder = "New name",
      confirmLabel = "Rename",
      onDismiss = { renameTarget = null },
      onConfirm = { newName, _ ->
        renameTarget = null
        sharedVm.renameItem(item, newName) { triggerRefresh() }
      },
    )
  }

  deleteTargets?.let { targets ->
    ConfirmDeleteDialog(
      items = targets,
      onDismiss = { deleteTargets = null },
      onConfirm = {
        sharedVm.deleteItems(targets) {
          selectionMode = false
          selectedPaths = emptySet()
          triggerRefresh()
        }
      },
    )
  }

  propertiesTarget?.let { item ->
    FilePropertiesDialog(item = item, onDismiss = { propertiesTarget = null })
  }

  compressTargets?.let { targets ->
    CompressOptionsDialog(
      defaultBaseName = if (targets.size == 1) targets.first().file.nameWithoutExtension else "Huzuni_Archive",
      onDismiss = { compressTargets = null },
      onConfirm = { fileName, format ->
        compressTargets = null
        val ext = if (format == "7Z") "7z" else "zip"
        val clean = if (fileName.endsWith(".$ext", ignoreCase = true)) fileName else "$fileName.$ext"
        val outPath = File(currentPath, clean).absolutePath
        sharedVm.compressToArchive(targets, outPath, format) {
          selectionMode = false
          selectedPaths = emptySet()
          triggerRefresh()
        }
      },
    )
  }

  movePickerTargets?.let { targets ->
    FolderPickerDialog(
      title = "Move ${targets.size} item(s) to",
      initialPath = currentPath,
      onDismiss = { movePickerTargets = null },
      onSelectFolder = { dest ->
        movePickerTargets = null
        sharedVm.setClipboard(targets, ClipboardMode.MOVE)
        sharedVm.pasteClipboard(dest) {
          selectionMode = false
          selectedPaths = emptySet()
          triggerRefresh()
        }
      },
    )
  }

  Box(
    modifier = Modifier.fillMaxSize(),
    contentAlignment = Alignment.TopCenter,
  ) {
    Column(
      modifier = Modifier
        .widthIn(max = 640.dp)
        .fillMaxSize()
        .statusBarsPadding()
        .padding(bottom = 86.dp),
    ) {
      // Top Navigation & Volume Switcher Header (matching reference panel 3)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        if (selectionMode) {
          IconButton(
            onClick = {
              selectionMode = false
              selectedPaths = emptySet()
            },
          ) {
            Icon(Icons.Filled.Close, contentDescription = "Exit selection", tint = palette.textPrimary)
          }
          Text(
            text = "${selectedPaths.size} selected",
            style = MaterialTheme.typography.titleLarge,
            color = palette.textPrimary,
            modifier = Modifier.weight(1f),
          )
          IconButton(
            onClick = {
              selectedPaths = if (selectedPaths.size == currentItems.size) {
                emptySet()
              } else {
                currentItems.map { it.path }.toSet()
              }
            },
          ) {
            Icon(Icons.Filled.SelectAll, contentDescription = "Select all", tint = palette.accent.primary)
          }
        } else {
          if (canNavigateUp) {
            IconButton(
              onClick = { File(currentPath).parentFile?.absolutePath?.let { currentPath = it } },
            ) {
              Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = "Parent folder",
                tint = palette.textPrimary,
              )
            }
          }

          Box(modifier = Modifier.weight(1f)) {
            Row(
              modifier = Modifier
                .clip(RoundedCornerShape(14.dp))
                .clickable { showVolumeMenu = true }
                .padding(horizontal = 8.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = activeVolume?.name ?: "Internal Storage",
                style = MaterialTheme.typography.titleLarge,
                color = palette.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
              )
              Spacer(modifier = Modifier.width(4.dp))
              Icon(
                imageVector = Icons.Filled.ExpandMore,
                contentDescription = "Switch storage volume",
                tint = palette.textPrimary,
              )
            }

            DropdownMenu(
              expanded = showVolumeMenu,
              onDismissRequest = { showVolumeMenu = false },
            ) {
              overview.volumes.forEach { vol ->
                DropdownMenuItem(
                  text = {
                    Column {
                      Text(vol.name, fontWeight = FontWeight.SemiBold)
                      Text(
                        "${FormatUtils.formatFileSize(vol.availableBytes)} free / ${FormatUtils.formatFileSize(vol.totalBytes)}",
                        style = MaterialTheme.typography.bodySmall,
                      )
                    }
                  },
                  onClick = {
                    showVolumeMenu = false
                    currentPath = vol.rootPath
                  },
                )
              }
            }
          }

          IconButton(onClick = { selectionMode = true }) {
            Icon(Icons.Filled.CheckCircle, contentDescription = "Multi-select", tint = palette.textSecondary)
          }
          IconButton(onClick = onOpenSearch) {
            Icon(Icons.Filled.Search, contentDescription = "Search", tint = palette.textPrimary)
          }
        }
      }

      // Interactive Breadcrumb Bar
      BreadcrumbBar(
        currentPath = currentPath,
        rootPath = activeRootPath,
        rootLabel = activeVolume?.name ?: "Internal Storage",
        onNavigate = { targetPath -> currentPath = targetPath },
      )

      // Multi-select Batch Action Strip
      AnimatedVisibility(visible = selectionMode && selectedItems.isNotEmpty()) {
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(palette.accent.softTint)
            .padding(horizontal = 8.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceEvenly,
        ) {
          BatchIconAction(Icons.Filled.ContentCopy, "Copy") {
            sharedVm.setClipboard(selectedItems, ClipboardMode.COPY)
            selectionMode = false
            selectedPaths = emptySet()
          }
          BatchIconAction(Icons.Filled.DriveFileMove, "Move") {
            sharedVm.setClipboard(selectedItems, ClipboardMode.MOVE)
            selectionMode = false
            selectedPaths = emptySet()
          }
          BatchIconAction(Icons.Filled.Compress, "Zip") {
            compressTargets = selectedItems
          }
          BatchIconAction(Icons.Filled.Share, "Share") {
            sharedVm.shareItems(selectedItems)
          }
          BatchIconAction(Icons.Filled.DeleteOutline, "Delete", tint = DangerRed) {
            if (settings.confirmBeforeDelete) {
              deleteTargets = selectedItems
            } else {
              sharedVm.deleteItems(selectedItems) {
                selectionMode = false
                selectedPaths = emptySet()
                triggerRefresh()
              }
            }
          }
        }
      }

      // Directory Listing Content
      Box(
        modifier = Modifier
          .fillMaxWidth()
          .weight(1f),
      ) {
        when {
          isLoading -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
              CircularProgressIndicator(color = palette.accent.primary)
            }
          }
          listingState is DirectoryListingResult.ProtectedSystemFolder -> {
            val info = listingState as DirectoryListingResult.ProtectedSystemFolder
            Box(
              modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
              contentAlignment = Alignment.Center,
            ) {
              LiquidGlassCard(elevated = true, shape = RoundedCornerShape(26.dp)) {
                Column(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                  Icon(
                    imageVector = Icons.Filled.Lock,
                    contentDescription = null,
                    tint = palette.accent.primary,
                    modifier = Modifier.size(44.dp),
                  )
                  Spacer(modifier = Modifier.height(12.dp))
                  Text(
                    text = "Protected System Directory",
                    style = MaterialTheme.typography.titleLarge,
                    color = palette.textPrimary,
                    textAlign = TextAlign.Center,
                  )
                  Spacer(modifier = Modifier.height(6.dp))
                  Text(
                    text = info.reason,
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.textSecondary,
                    textAlign = TextAlign.Center,
                  )
                  Spacer(modifier = Modifier.height(14.dp))
                  GlossyAccentButton(
                    text = "Go Back",
                    onClick = { File(currentPath).parentFile?.absolutePath?.let { currentPath = it } },
                  )
                }
              }
            }
          }
          listingState is DirectoryListingResult.Error -> {
            val err = listingState as DirectoryListingResult.Error
            Box(
              modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
              contentAlignment = Alignment.Center,
            ) {
              LiquidGlassCard(elevated = true, shape = RoundedCornerShape(26.dp)) {
                Column(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                  Icon(
                    imageVector = Icons.Filled.FolderOff,
                    contentDescription = null,
                    tint = DangerRed,
                    modifier = Modifier.size(44.dp),
                  )
                  Spacer(modifier = Modifier.height(10.dp))
                  Text(
                    text = err.message,
                    style = MaterialTheme.typography.bodyMedium,
                    color = palette.textPrimary,
                    textAlign = TextAlign.Center,
                  )
                  if (!hasAccess) {
                    Spacer(modifier = Modifier.height(14.dp))
                    GlossyAccentButton(
                      text = "Allow All Files Access",
                      onClick = { sharedVm.openPermissionDialog() },
                    )
                  }
                }
              }
            }
          }
          currentItems.isEmpty() -> {
            Box(
              modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
              contentAlignment = Alignment.Center,
            ) {
              LiquidGlassCard(shape = RoundedCornerShape(24.dp)) {
                Column(
                  modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                  horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                  Icon(
                    imageVector = Icons.Filled.FolderOff,
                    contentDescription = null,
                    tint = palette.textMuted,
                    modifier = Modifier.size(42.dp),
                  )
                  Spacer(modifier = Modifier.height(8.dp))
                  Text(
                    text = "Empty Folder",
                    style = MaterialTheme.typography.titleMedium,
                    color = palette.textPrimary,
                  )
                  Text(
                    text = "Tap + New below to create a folder or text file.",
                    style = MaterialTheme.typography.bodySmall,
                    color = palette.textSecondary,
                  )
                }
              }
            }
          }
          viewMode == ViewMode.LIST -> {
            LazyColumn(
              contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp),
              modifier = Modifier.fillMaxSize(),
            ) {
              items(currentItems, key = { it.path }) { item ->
                val isSelected = item.path in selectedPaths
                LiquidGlassCard(
                  shape = RoundedCornerShape(20.dp),
                  contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                  modifier = Modifier
                    .fillMaxWidth()
                    .then(
                      if (isSelected) {
                        Modifier.border(1.5.dp, palette.accent.primary, RoundedCornerShape(20.dp))
                      } else {
                        Modifier
                      },
                    )
                    .combinedClickable(
                      onClick = {
                        if (selectionMode) {
                          selectedPaths = if (isSelected) selectedPaths - item.path else selectedPaths + item.path
                        } else if (item.isDirectory) {
                          currentPath = item.path
                        } else {
                          onOpenFile(item)
                        }
                      },
                      onLongClick = {
                        if (selectionMode) {
                          selectedPaths = if (isSelected) selectedPaths - item.path else selectedPaths + item.path
                        } else {
                          contextTarget = item
                        }
                      },
                    ),
                ) {
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                  ) {
                    if (selectionMode) {
                      Icon(
                        imageVector = if (isSelected) Icons.Filled.CheckBox else Icons.Filled.CheckBoxOutlineBlank,
                        contentDescription = if (isSelected) "Selected" else "Not selected",
                        tint = if (isSelected) palette.accent.primary else palette.textMuted,
                        modifier = Modifier.size(22.dp),
                      )
                      Spacer(modifier = Modifier.width(10.dp))
                    }
                    FileItemThumbnail(item = item, size = 44.dp)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                      Text(
                        text = item.name,
                        style = MaterialTheme.typography.titleSmall,
                        color = palette.textPrimary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                      )
                      Spacer(modifier = Modifier.height(2.dp))
                      val meta = if (item.isDirectory) {
                        "${item.childCount} items • ${FormatUtils.formatDate(item.lastModified)}"
                      } else {
                        "${FormatUtils.formatFileSize(item.sizeBytes)} • ${FormatUtils.formatDate(item.lastModified)}"
                      }
                      Text(
                        text = meta,
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary,
                        maxLines = 1,
                      )
                    }
                    if (!selectionMode) {
                      IconButton(onClick = { contextTarget = item }) {
                        Icon(
                          imageVector = Icons.Filled.MoreVert,
                          contentDescription = "Options for ${item.name}",
                          tint = palette.textSecondary,
                        )
                      }
                    }
                  }
                }
              }
            }
          }
          else -> {
            LazyVerticalGrid(
              columns = GridCells.Adaptive(minSize = 112.dp),
              contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
              modifier = Modifier.fillMaxSize(),
            ) {
              items(currentItems, key = { it.path }) { item ->
                val isSelected = item.path in selectedPaths
                LiquidGlassCard(
                  shape = RoundedCornerShape(20.dp),
                  contentPadding = PaddingValues(10.dp),
                  modifier = Modifier
                    .fillMaxWidth()
                    .then(
                      if (isSelected) {
                        Modifier.border(1.5.dp, palette.accent.primary, RoundedCornerShape(20.dp))
                      } else {
                        Modifier
                      },
                    )
                    .combinedClickable(
                      onClick = {
                        if (selectionMode) {
                          selectedPaths = if (isSelected) selectedPaths - item.path else selectedPaths + item.path
                        } else if (item.isDirectory) {
                          currentPath = item.path
                        } else {
                          onOpenFile(item)
                        }
                      },
                      onLongClick = { contextTarget = item },
                    ),
                ) {
                  Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                  ) {
                    FileItemThumbnail(item = item, size = 56.dp)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                      text = item.name,
                      style = MaterialTheme.typography.labelLarge,
                      color = palette.textPrimary,
                      maxLines = 2,
                      overflow = TextOverflow.Ellipsis,
                      textAlign = TextAlign.Center,
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                      text = if (item.isDirectory) "${item.childCount} items" else FormatUtils.formatFileSize(item.sizeBytes),
                      style = MaterialTheme.typography.bodySmall,
                      color = palette.textSecondary,
                      maxLines = 1,
                    )
                  }
                }
              }
            }
          }
        }
      }

      // Bottom Glass Action Bar (+ New, Sort, View, Paste) matching reference panel 3
      LiquidGlassCard(
        elevated = true,
        shape = RoundedCornerShape(22.dp),
        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 6.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceEvenly,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Box {
            ToolbarPillButton(
              icon = Icons.Filled.Add,
              label = "New",
              onClick = { showNewMenu = true },
              modifier = Modifier.testTag("files_new_button"),
            )
            DropdownMenu(
              expanded = showNewMenu,
              onDismissRequest = { showNewMenu = false },
            ) {
              DropdownMenuItem(
                leadingIcon = { Icon(Icons.Filled.CreateNewFolder, contentDescription = null) },
                text = { Text("New Folder") },
                onClick = {
                  showNewMenu = false
                  showNewFolderDialog = true
                },
              )
              DropdownMenuItem(
                leadingIcon = { Icon(Icons.Filled.NoteAdd, contentDescription = null) },
                text = { Text("New Text File") },
                onClick = {
                  showNewMenu = false
                  showNewTextDialog = true
                },
              )
            }
          }

          ToolbarPillButton(
            icon = Icons.AutoMirrored.Filled.Sort,
            label = "Sort",
            onClick = { showSortDialog = true },
            modifier = Modifier.testTag("files_sort_button"),
          )

          ToolbarPillButton(
            icon = if (viewMode == ViewMode.LIST) Icons.Filled.GridView else Icons.AutoMirrored.Filled.ViewList,
            label = if (viewMode == ViewMode.LIST) "Grid" else "List",
            onClick = {
              val next = if (viewMode == ViewMode.LIST) ViewMode.GRID else ViewMode.LIST
              viewMode = next
              sharedVm.updateDefaultViewMode(next)
            },
            modifier = Modifier.testTag("files_view_button"),
          )

          ToolbarPillButton(
            icon = Icons.Filled.ContentPaste,
            label = if (clipboard.isEmpty) "Paste" else "Paste (${clipboard.count})",
            enabled = !clipboard.isEmpty,
            highlight = !clipboard.isEmpty,
            onClick = {
              sharedVm.pasteClipboard(currentPath) { triggerRefresh() }
            },
            modifier = Modifier.testTag("files_paste_button"),
          )
        }
      }
    }
  }
}

@Composable
private fun BreadcrumbBar(
  currentPath: String,
  rootPath: String,
  rootLabel: String,
  onNavigate: (String) -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  val segments = remember(currentPath, rootPath) {
    val cleanRoot = rootPath.trimEnd('/')
    val cleanCurrent = currentPath.trimEnd('/')
    val list = mutableListOf(rootLabel to cleanRoot)
    if (cleanCurrent.startsWith(cleanRoot) && cleanCurrent.length > cleanRoot.length) {
      val rel = cleanCurrent.removePrefix(cleanRoot).trimStart('/')
      var running = cleanRoot
      rel.split('/').filter { it.isNotEmpty() }.forEach { part ->
        running = "$running/$part"
        list.add(part to running)
      }
    }
    list
  }

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 2.dp),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      segments.forEachIndexed { idx, (label, path) ->
        val isLast = idx == segments.lastIndex
        Text(
          text = label,
          style = MaterialTheme.typography.labelLarge,
          color = if (isLast) palette.accent.primary else palette.textSecondary,
          modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable { onNavigate(path) }
            .padding(horizontal = 6.dp, vertical = 4.dp),
        )
        if (!isLast) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
            contentDescription = null,
            tint = palette.textMuted,
            modifier = Modifier.size(16.dp),
          )
        }
      }
    }
    Text(
      text = currentPath,
      fontFamily = JetBrainsMonoFontFamily,
      style = MaterialTheme.typography.labelSmall,
      color = palette.textMuted,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
      modifier = Modifier.padding(horizontal = 6.dp),
    )
  }
}

@Composable
private fun ToolbarPillButton(
  icon: ImageVector,
  label: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true,
  highlight: Boolean = false,
) {
  val palette = LocalLiquidGlassPalette.current
  val tint = when {
    !enabled -> palette.textMuted.copy(alpha = 0.45f)
    highlight -> palette.accent.primary
    else -> palette.textPrimary
  }
  Column(
    modifier = modifier
      .clip(RoundedCornerShape(14.dp))
      .clickable(enabled = enabled, onClick = onClick)
      .padding(horizontal = 14.dp, vertical = 6.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Icon(imageVector = icon, contentDescription = label, tint = tint, modifier = Modifier.size(20.dp))
    Spacer(modifier = Modifier.height(2.dp))
    Text(text = label, style = MaterialTheme.typography.labelMedium, color = tint)
  }
}

@Composable
private fun BatchIconAction(
  icon: ImageVector,
  label: String,
  tint: Color? = null,
  onClick: () -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  val effective = tint ?: palette.accent.primary
  Column(
    modifier = Modifier
      .clip(RoundedCornerShape(12.dp))
      .clickable(onClick = onClick)
      .padding(horizontal = 10.dp, vertical = 4.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    Icon(imageVector = icon, contentDescription = label, tint = effective, modifier = Modifier.size(20.dp))
    Text(text = label, style = MaterialTheme.typography.labelSmall, color = effective)
  }
}

@Composable
private fun SortOptionsDialog(
  currentField: SortField,
  currentDirection: SortDirection,
  onDismiss: () -> Unit,
  onApply: (SortField, SortDirection) -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  var selectedField by remember { mutableStateOf(currentField) }
  var selectedDir by remember { mutableStateOf(currentDirection) }

  Dialog(onDismissRequest = onDismiss) {
    LiquidGlassCard(elevated = true, shape = RoundedCornerShape(26.dp)) {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text("Sort Files", style = MaterialTheme.typography.titleLarge, color = palette.textPrimary)
        Spacer(modifier = Modifier.height(10.dp))
        SortField.entries.forEach { field ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(12.dp))
              .clickable { selectedField = field }
              .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            RadioButton(selected = selectedField == field, onClick = { selectedField = field })
            Text(field.label, style = MaterialTheme.typography.bodyLarge, color = palette.textPrimary)
          }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Text("Order", style = MaterialTheme.typography.titleSmall, color = palette.textSecondary)
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          SortDirection.entries.forEach { dir ->
            Row(
              modifier = Modifier
                .weight(1f)
                .clip(RoundedCornerShape(12.dp))
                .clickable { selectedDir = dir }
                .padding(vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              RadioButton(selected = selectedDir == dir, onClick = { selectedDir = dir })
              Text(dir.label, style = MaterialTheme.typography.bodyMedium, color = palette.textPrimary)
            }
          }
        }
        Spacer(modifier = Modifier.height(14.dp))
        GlossyAccentButton(
          text = "Apply Sort",
          onClick = { onApply(selectedField, selectedDir) },
          modifier = Modifier.fillMaxWidth(),
        )
      }
    }
  }
}

@Composable
private fun CompressOptionsDialog(
  defaultBaseName: String,
  onDismiss: () -> Unit,
  onConfirm: (fileName: String, format: String) -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  var name by remember { mutableStateOf(defaultBaseName) }
  var format by remember { mutableStateOf("ZIP") }

  Dialog(onDismissRequest = onDismiss) {
    LiquidGlassCard(elevated = true, shape = RoundedCornerShape(26.dp)) {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text("Create Archive", style = MaterialTheme.typography.titleLarge, color = palette.textPrimary)
        Spacer(modifier = Modifier.height(12.dp))
        androidx.compose.material3.OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          singleLine = true,
          label = { Text("Archive name") },
          modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text("Format", style = MaterialTheme.typography.titleSmall, color = palette.textSecondary)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
          listOf("ZIP", "7Z").forEach { fmt ->
            Row(
              modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable { format = fmt }
                .padding(end = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              RadioButton(selected = format == fmt, onClick = { format = fmt })
              Text(fmt, style = MaterialTheme.typography.bodyLarge, color = palette.textPrimary)
            }
          }
        }
        Spacer(modifier = Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          GlossyAccentButton(
            text = "Cancel",
            isSecondary = true,
            onClick = onDismiss,
            modifier = Modifier.weight(1f),
          )
          GlossyAccentButton(
            text = "Compress",
            enabled = name.trim().isNotEmpty(),
            onClick = { onConfirm(name.trim(), format) },
            modifier = Modifier.weight(1f),
          )
        }
      }
    }
  }
}
