package com.example.screens

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.archive.ArchiveRepository
import com.example.data.ClipboardMode
import com.example.data.ClipboardState
import com.example.data.FileItem
import com.example.data.OperationProgress
import com.example.data.SettingsRepository
import com.example.data.SortDirection
import com.example.data.SortField
import com.example.data.StorageOverviewState
import com.example.data.UserSettings
import com.example.data.ViewMode
import com.example.filemanager.FileOperationsRepository
import com.example.permissions.StoragePermissionHelper
import com.example.storage.StorageRepository
import com.example.ui.theme.AccentPalette
import com.example.ui.theme.ThemeMode
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File

class MainAppViewModel(application: Application) : AndroidViewModel(application) {

  val settingsRepository = SettingsRepository(application)
  val storageRepository = StorageRepository(application)
  val fileOpsRepository = FileOperationsRepository(application)
  val archiveRepository = ArchiveRepository()

  val settings: StateFlow<UserSettings> = settingsRepository.settingsFlow
    .stateIn(viewModelScope, SharingStarted.Eagerly, UserSettings())

  private val _hasAllFilesAccess = MutableStateFlow(StoragePermissionHelper.hasAllFilesAccess(application))
  val hasAllFilesAccess: StateFlow<Boolean> = _hasAllFilesAccess.asStateFlow()

  private val _showPermissionPrompt = MutableStateFlow(!_hasAllFilesAccess.value)
  val showPermissionPrompt: StateFlow<Boolean> = _showPermissionPrompt.asStateFlow()

  private val _storageOverview = MutableStateFlow(StorageOverviewState(isLoading = true))
  val storageOverview: StateFlow<StorageOverviewState> = _storageOverview.asStateFlow()

  private val _clipboard = MutableStateFlow(ClipboardState())
  val clipboard: StateFlow<ClipboardState> = _clipboard.asStateFlow()

  private val _operationProgress = MutableStateFlow<OperationProgress?>(null)
  val operationProgress: StateFlow<OperationProgress?> = _operationProgress.asStateFlow()

  private val _discoveredArchives = MutableStateFlow<List<FileItem>>(emptyList())
  val discoveredArchives: StateFlow<List<FileItem>> = _discoveredArchives.asStateFlow()

  private val _archivesLoading = MutableStateFlow(false)
  val archivesLoading: StateFlow<Boolean> = _archivesLoading.asStateFlow()

  private val _events = MutableSharedFlow<String>(extraBufferCapacity = 8)
  val events = _events.asSharedFlow()

  private var activeOpJob: Job? = null

  init {
    refreshAll()
  }

  fun recheckPermissionsAndRefresh() {
    val granted = StoragePermissionHelper.hasAllFilesAccess(getApplication())
    val changed = granted != _hasAllFilesAccess.value
    _hasAllFilesAccess.value = granted
    if (granted) {
      _showPermissionPrompt.value = false
    }
    if (changed || _storageOverview.value.primaryVolume == null) {
      refreshAll()
    }
  }

  fun openPermissionDialog() {
    _showPermissionPrompt.value = true
  }

  fun dismissPermissionDialog() {
    _showPermissionPrompt.value = false
  }

  fun refreshAll() {
    viewModelScope.launch {
      _storageOverview.value = _storageOverview.value.copy(isLoading = true)
      val overview = storageRepository.loadStorageOverview(settings.value.showHiddenFiles)
      _storageOverview.value = overview
    }
    refreshArchives()
  }

  fun refreshArchives() {
    viewModelScope.launch {
      _archivesLoading.value = true
      _discoveredArchives.value = archiveRepository.discoverArchives(settings.value.showHiddenFiles)
      _archivesLoading.value = false
    }
  }

  fun setClipboard(items: List<FileItem>, mode: ClipboardMode) {
    _clipboard.value = ClipboardState(files = items, mode = mode)
    val verb = if (mode == ClipboardMode.COPY) "Copied" else "Ready to move"
    emitMessage("$verb ${items.size} item${if (items.size == 1) "" else "s"} — navigate and tap Paste.")
  }

  fun clearClipboard() {
    _clipboard.value = ClipboardState()
  }

  fun pasteClipboard(destinationDir: String, onComplete: () -> Unit = {}) {
    val current = _clipboard.value
    if (current.isEmpty) return
    val isMove = current.mode == ClipboardMode.MOVE

    activeOpJob?.cancel()
    activeOpJob = viewModelScope.launch {
      try {
        val result = fileOpsRepository.copyOrMove(
          sources = current.files,
          destinationDirPath = destinationDir,
          isMove = isMove,
          overwrite = !settings.value.confirmOverwrite,
          onProgress = { _operationProgress.value = it },
        )
        _operationProgress.value = null
        if (result.isFullSuccess && isMove) {
          _clipboard.value = ClipboardState()
        }
        emitMessage(result.message)
        refreshAll()
        onComplete()
      } catch (_: Exception) {
        _operationProgress.value = null
        emitMessage("Operation cancelled.")
      }
    }
  }

  fun deleteItems(items: List<FileItem>, onComplete: () -> Unit = {}) {
    if (items.isEmpty()) return
    activeOpJob?.cancel()
    activeOpJob = viewModelScope.launch {
      try {
        val result = fileOpsRepository.deleteFiles(items) { _operationProgress.value = it }
        _operationProgress.value = null
        emitMessage(result.message)
        refreshAll()
        onComplete()
      } catch (_: Exception) {
        _operationProgress.value = null
        emitMessage("Delete cancelled.")
      }
    }
  }

  fun renameItem(item: FileItem, newName: String, onComplete: () -> Unit = {}) {
    viewModelScope.launch {
      fileOpsRepository.renameFile(item, newName)
        .onSuccess {
          emitMessage("Renamed to ${it.name}.")
          refreshAll()
          onComplete()
        }
        .onFailure {
          emitMessage(it.message ?: "Rename failed.")
        }
    }
  }

  fun compressToArchive(
    sources: List<FileItem>,
    outputPath: String,
    format: String,
    onComplete: () -> Unit = {},
  ) {
    if (sources.isEmpty()) return
    activeOpJob?.cancel()
    activeOpJob = viewModelScope.launch {
      try {
        val files = sources.map { it.file }
        val res = if (format.equals("7Z", ignoreCase = true)) {
          archiveRepository.createSevenZArchive(files, outputPath) { _operationProgress.value = it }
        } else {
          archiveRepository.createZipArchive(files, outputPath) { _operationProgress.value = it }
        }
        _operationProgress.value = null
        emitMessage(res.message)
        refreshAll()
        onComplete()
      } catch (_: Exception) {
        _operationProgress.value = null
        emitMessage("Compression cancelled.")
      }
    }
  }

  fun extractArchiveTo(
    archivePath: String,
    destDir: String,
    selectedEntries: Set<String>? = null,
    onComplete: () -> Unit = {},
  ) {
    activeOpJob?.cancel()
    activeOpJob = viewModelScope.launch {
      try {
        val res = archiveRepository.extractArchive(
          archivePath = archivePath,
          destinationDirPath = destDir,
          selectedEntryPaths = selectedEntries,
          onProgress = { _operationProgress.value = it },
        )
        _operationProgress.value = null
        emitMessage(res.message)
        refreshAll()
        onComplete()
      } catch (_: Exception) {
        _operationProgress.value = null
        emitMessage("Extraction cancelled.")
      }
    }
  }

  fun cancelActiveOperation() {
    activeOpJob?.cancel()
    _operationProgress.value = null
  }

  fun shareItems(items: List<FileItem>) {
    fileOpsRepository.shareFiles(items).onFailure {
      emitMessage(it.message ?: "Unable to share selected item(s).")
    }
  }

  fun openWithExternal(item: FileItem) {
    fileOpsRepository.openWithExternalApp(item).onFailure {
      emitMessage("No compatible app found to open ${item.name}.")
    }
  }

  fun updateThemeMode(mode: ThemeMode) = viewModelScope.launch { settingsRepository.setThemeMode(mode) }
  fun updateAccentPalette(palette: AccentPalette) = viewModelScope.launch { settingsRepository.setAccentPalette(palette) }
  fun updateDefaultViewMode(mode: ViewMode) = viewModelScope.launch { settingsRepository.setDefaultViewMode(mode) }
  fun updateSort(field: SortField, dir: SortDirection) = viewModelScope.launch { settingsRepository.setSort(field, dir) }
  fun updateShowHidden(show: Boolean) = viewModelScope.launch {
    settingsRepository.setShowHiddenFiles(show)
    refreshAll()
  }
  fun updateConfirmDelete(confirm: Boolean) = viewModelScope.launch { settingsRepository.setConfirmBeforeDelete(confirm) }
  fun updateConfirmOverwrite(confirm: Boolean) = viewModelScope.launch { settingsRepository.setConfirmOverwrite(confirm) }
  fun addRecentSearch(query: String) = viewModelScope.launch { settingsRepository.addRecentSearch(query) }
  fun clearRecentSearches() = viewModelScope.launch { settingsRepository.clearRecentSearches() }

  fun emitMessage(msg: String) {
    _events.tryEmit(msg)
  }

  fun defaultArchiveOutputPath(sourceItems: List<FileItem>, ext: String): String {
    val first = sourceItems.firstOrNull()?.file
    val parent = first?.parentFile ?: File(storageRepository.getPrimaryRootPath())
    val baseName = if (sourceItems.size == 1) {
      first?.nameWithoutExtension ?: "Archive"
    } else {
      "Huzuni_Archive"
    }
    var candidate = File(parent, "$baseName.$ext")
    var idx = 1
    while (candidate.exists()) {
      candidate = File(parent, "${baseName}_$idx.$ext")
      idx++
    }
    return candidate.absolutePath
  }
}
