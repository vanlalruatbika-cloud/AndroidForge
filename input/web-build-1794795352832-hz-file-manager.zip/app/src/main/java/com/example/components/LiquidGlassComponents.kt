package com.example.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Android
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.PictureAsPdf
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VideoFile
import androidx.compose.material.icons.outlined.Folder
import androidx.compose.material.icons.outlined.FolderZip
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ripple
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.example.R
import com.example.data.FileItem
import com.example.ui.theme.CategoryApkTint
import com.example.ui.theme.CategoryArchiveTint
import com.example.ui.theme.CategoryAudioTint
import com.example.ui.theme.CategoryDocTint
import com.example.ui.theme.CategoryImageTint
import com.example.ui.theme.CategoryPdfTint
import com.example.ui.theme.CategoryVideoTint
import com.example.ui.theme.FolderGold
import com.example.ui.theme.FolderGoldDeep
import com.example.ui.theme.LocalLiquidGlassPalette
import com.example.ui.theme.OutfitFontFamily
import com.example.utils.FileCategory
import java.io.File

@Composable
fun LiquidGlassBackground(
  modifier: Modifier = Modifier,
  content: @Composable BoxScope.() -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  Box(
    modifier = modifier
      .fillMaxSize()
      .background(palette.backgroundBase),
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val w = size.width
      val h = size.height

      // Soft upper-right lavender pearl glow
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(
            palette.backgroundMistPrimary.copy(alpha = 0.85f),
            Color.Transparent,
          ),
          center = Offset(w * 0.85f, h * 0.14f),
          radius = w * 0.85f,
        ),
        radius = w * 0.85f,
        center = Offset(w * 0.85f, h * 0.14f),
      )

      // Soft lower-left silk aura
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(
            palette.accent.softTint.copy(alpha = if (palette.isDark) 0.14f else 0.72f),
            Color.Transparent,
          ),
          center = Offset(w * 0.12f, h * 0.72f),
          radius = w * 0.9f,
        ),
        radius = w * 0.9f,
        center = Offset(w * 0.12f, h * 0.72f),
      )

      // Flowing translucent liquid glass ribbon wave
      val silkPath = Path().apply {
        moveTo(0f, h * 0.24f)
        cubicTo(w * 0.35f, h * 0.10f, w * 0.68f, h * 0.36f, w, h * 0.20f)
        lineTo(w, h * 0.56f)
        cubicTo(w * 0.65f, h * 0.44f, w * 0.30f, h * 0.68f, 0f, h * 0.50f)
        close()
      }
      drawPath(
        path = silkPath,
        brush = Brush.linearGradient(
          colors = listOf(
            palette.glassHighlight.copy(alpha = if (palette.isDark) 0.08f else 0.55f),
            palette.accent.softTint.copy(alpha = if (palette.isDark) 0.06f else 0.35f),
            Color.Transparent,
          ),
          start = Offset(0f, h * 0.18f),
          end = Offset(w, h * 0.56f),
        ),
      )
    }
    content()
  }
}

@Composable
fun LiquidGlassCard(
  modifier: Modifier = Modifier,
  shape: Shape = RoundedCornerShape(24.dp),
  elevated: Boolean = false,
  contentPadding: PaddingValues = PaddingValues(16.dp),
  onClick: (() -> Unit)? = null,
  content: @Composable BoxScope.() -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  val fillColor = if (elevated) palette.glassSurfaceElevated else palette.glassSurface
  val borderBrush = Brush.linearGradient(
    colors = listOf(
      palette.glassBorderTop,
      palette.glassBorderBottom,
    ),
  )

  val clickModifier = if (onClick != null) {
    Modifier
      .clip(shape)
      .clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = ripple(color = palette.accent.primary),
        onClick = onClick,
      )
  } else {
    Modifier
  }

  Box(
    modifier = modifier
      .shadow(
        elevation = if (elevated) 14.dp else 8.dp,
        shape = shape,
        ambientColor = palette.shadowColor,
        spotColor = palette.shadowColor,
      )
      .clip(shape)
      .background(
        brush = Brush.verticalGradient(
          colors = listOf(
            fillColor,
            fillColor.copy(alpha = (fillColor.alpha * 0.90f).coerceIn(0f, 1f)),
          ),
        ),
      )
      .border(width = 1.dp, brush = borderBrush, shape = shape)
      .then(clickModifier)
      .padding(contentPadding),
    content = content,
  )
}

@Composable
fun GlossyAccentButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  icon: ImageVector? = null,
  enabled: Boolean = true,
  isSecondary: Boolean = false,
) {
  val palette = LocalLiquidGlassPalette.current
  val shape = RoundedCornerShape(18.dp)
  val bgBrush = if (isSecondary) {
    Brush.verticalGradient(
      colors = listOf(
        palette.glassSurfaceElevated,
        palette.glassSurface,
      ),
    )
  } else {
    Brush.linearGradient(
      colors = listOf(
        palette.accent.secondary,
        palette.accent.primary,
      ),
    )
  }

  val contentColor = if (isSecondary) palette.textPrimary else Color.White

  Surface(
    onClick = onClick,
    enabled = enabled,
    shape = shape,
    color = Color.Transparent,
    shadowElevation = if (isSecondary) 4.dp else 8.dp,
    border = BorderStroke(
      1.dp,
      if (isSecondary) palette.glassBorderTop else Color.White.copy(alpha = 0.45f),
    ),
    modifier = modifier.height(50.dp),
  ) {
    Box(
      modifier = Modifier
        .background(if (enabled) bgBrush else Brush.linearGradient(listOf(Color.Gray.copy(0.3f), Color.Gray.copy(0.3f))))
        .padding(horizontal = 18.dp),
      contentAlignment = Alignment.Center,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
      ) {
        if (icon != null) {
          Icon(
            imageVector = icon,
            contentDescription = null,
            tint = contentColor,
            modifier = Modifier.size(19.dp),
          )
          Spacer(modifier = Modifier.width(8.dp))
        }
        Text(
          text = text,
          style = MaterialTheme.typography.labelLarge,
          color = contentColor,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
      }
    }
  }
}

@Composable
fun HzGlossyBadge(
  modifier: Modifier = Modifier,
  size: Dp = 44.dp,
) {
  val palette = LocalLiquidGlassPalette.current
  Box(
    modifier = modifier
      .size(size)
      .shadow(8.dp, RoundedCornerShape(14.dp), ambientColor = palette.shadowColor)
      .clip(RoundedCornerShape(14.dp))
      .background(
        Brush.linearGradient(
          colors = listOf(
            Color.White.copy(alpha = 0.96f),
            palette.accent.softTint,
          ),
        ),
      )
      .border(
        1.2.dp,
        Brush.linearGradient(listOf(Color.White, palette.accent.primary.copy(alpha = 0.4f))),
        RoundedCornerShape(14.dp),
      ),
    contentAlignment = Alignment.Center,
  ) {
    Text(
      text = "Hz",
      fontFamily = OutfitFontFamily,
      fontWeight = FontWeight.Bold,
      fontSize = (size.value * 0.44f).sp,
      color = palette.accent.primary,
    )
  }
}

@Composable
fun HuzuniMascotAvatar(
  modifier: Modifier = Modifier,
  size: Dp = 46.dp,
  onClick: (() -> Unit)? = null,
) {
  val palette = LocalLiquidGlassPalette.current
  Box(
    modifier = modifier
      .size(size)
      .shadow(8.dp, CircleShape, ambientColor = palette.shadowColor)
      .clip(CircleShape)
      .border(
        width = 2.dp,
        brush = Brush.linearGradient(listOf(Color.White, palette.accent.primary)),
        shape = CircleShape,
      )
      .then(
        if (onClick != null) {
          Modifier.clickable(onClick = onClick)
        } else {
          Modifier
        },
      ),
    contentAlignment = Alignment.Center,
  ) {
    Image(
      painter = painterResource(id = R.drawable.huzuni_mascot),
      contentDescription = "Huzuni Mascot",
      contentScale = ContentScale.Crop,
      alignment = Alignment.TopCenter,
      modifier = Modifier.fillMaxSize(),
    )
  }
}

enum class BottomNavTab(
  val label: String,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
  val testTag: String,
) {
  HOME("Home", Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
  FILES("Files", Icons.Filled.Folder, Icons.Outlined.Folder, "nav_files"),
  ARCHIVES("Archives", Icons.Filled.FolderZip, Icons.Outlined.FolderZip, "nav_archives"),
  SETTINGS("Settings", Icons.Filled.Settings, Icons.Outlined.Settings, "nav_settings"),
}

@Composable
fun LiquidGlassFloatingNavBar(
  selectedTab: BottomNavTab,
  onSelectTab: (BottomNavTab) -> Unit,
  modifier: Modifier = Modifier,
) {
  val palette = LocalLiquidGlassPalette.current
  val shape = RoundedCornerShape(28.dp)

  Box(
    modifier = modifier
      .fillMaxWidth()
      .navigationBarsPadding()
      .padding(horizontal = 16.dp, vertical = 10.dp),
    contentAlignment = Alignment.Center,
  ) {
    Row(
      modifier = Modifier
        .widthIn(max = 520.dp)
        .fillMaxWidth()
        .shadow(18.dp, shape, ambientColor = palette.shadowColor, spotColor = palette.shadowColor)
        .clip(shape)
        .background(palette.navBarSurface)
        .border(
          width = 1.dp,
          brush = Brush.linearGradient(listOf(palette.glassBorderTop, palette.glassBorderBottom)),
          shape = shape,
        )
        .padding(horizontal = 8.dp, vertical = 6.dp),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      BottomNavTab.entries.forEach { tab ->
        val isSelected = tab == selectedTab
        val pillColor by animateColorAsState(
          targetValue = if (isSelected) palette.navActivePill else Color.Transparent,
          animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
          label = "navPill",
        )
        val iconTint by animateColorAsState(
          targetValue = if (isSelected) palette.accent.primary else palette.textSecondary,
          label = "navTint",
        )
        val scale by animateFloatAsState(
          targetValue = if (isSelected) 1.04f else 1f,
          animationSpec = spring(dampingRatio = 0.7f),
          label = "navScale",
        )

        Column(
          modifier = Modifier
            .weight(1f)
            .graphicsLayer {
              scaleX = scale
              scaleY = scale
            }
            .clip(RoundedCornerShape(22.dp))
            .background(pillColor)
            .clickable(
              interactionSource = remember { MutableInteractionSource() },
              indication = ripple(color = palette.accent.primary),
              onClick = { onSelectTab(tab) },
            )
            .padding(vertical = 8.dp)
            .testTag(tab.testTag),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.Center,
        ) {
          Icon(
            imageVector = if (isSelected) tab.selectedIcon else tab.unselectedIcon,
            contentDescription = tab.label,
            tint = iconTint,
            modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.height(2.dp))
          Text(
            text = tab.label,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Medium,
            color = iconTint,
            maxLines = 1,
          )
        }
      }
    }
  }
}

@Composable
fun FileItemThumbnail(
  item: FileItem,
  size: Dp = 44.dp,
  modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val palette = LocalLiquidGlassPalette.current

  if (item.isDirectory) {
    Box(
      modifier = modifier
        .size(size)
        .clip(RoundedCornerShape(14.dp))
        .background(
          Brush.linearGradient(
            colors = listOf(
              FolderGold.copy(alpha = 0.22f),
              FolderGoldDeep.copy(alpha = 0.10f),
            ),
          ),
        ),
      contentAlignment = Alignment.Center,
    ) {
      Icon(
        imageVector = Icons.Filled.Folder,
        contentDescription = "Folder",
        tint = FolderGold,
        modifier = Modifier.size(size * 0.68f),
      )
    }
    return
  }

  if (item.category == FileCategory.IMAGE || item.category == FileCategory.VIDEO) {
    Box(
      modifier = modifier
        .size(size)
        .clip(RoundedCornerShape(12.dp))
        .background(palette.accent.softTint),
      contentAlignment = Alignment.Center,
    ) {
      AsyncImage(
        model = ImageRequest.Builder(context)
          .data(File(item.path))
          .crossfade(true)
          .size(160)
          .build(),
        contentDescription = item.name,
        contentScale = ContentScale.Crop,
        modifier = Modifier.fillMaxSize(),
      )
      if (item.category == FileCategory.VIDEO) {
        Box(
          modifier = Modifier
            .size(20.dp)
            .clip(CircleShape)
            .background(Color.Black.copy(alpha = 0.55f)),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Filled.VideoFile,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(12.dp),
          )
        }
      }
    }
    return
  }

  val (icon, tint) = when (item.category) {
    FileCategory.AUDIO -> Icons.Filled.AudioFile to CategoryAudioTint
    FileCategory.PDF -> Icons.Filled.PictureAsPdf to CategoryPdfTint
    FileCategory.TEXT, FileCategory.DOCUMENT -> Icons.Filled.Description to CategoryDocTint
    FileCategory.ARCHIVE -> Icons.Filled.Archive to CategoryArchiveTint
    FileCategory.APK -> Icons.Filled.Android to CategoryApkTint
    FileCategory.IMAGE -> Icons.Filled.Image to CategoryImageTint
    FileCategory.VIDEO -> Icons.Filled.VideoFile to CategoryVideoTint
    else -> Icons.Filled.InsertDriveFile to palette.textSecondary
  }

  Box(
    modifier = modifier
      .size(size)
      .clip(RoundedCornerShape(13.dp))
      .background(tint.copy(alpha = 0.14f))
      .border(1.dp, tint.copy(alpha = 0.25f), RoundedCornerShape(13.dp)),
    contentAlignment = Alignment.Center,
  ) {
    Icon(
      imageVector = icon,
      contentDescription = item.category.label,
      tint = tint,
      modifier = Modifier.size(size * 0.54f),
    )
  }
}
