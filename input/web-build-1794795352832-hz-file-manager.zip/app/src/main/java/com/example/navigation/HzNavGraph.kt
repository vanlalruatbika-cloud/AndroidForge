package com.example.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.components.BottomNavTab
import com.example.components.LiquidGlassBackground
import com.example.components.LiquidGlassFloatingNavBar
import com.example.components.OperationProgressOverlay
import com.example.data.FileItem
import com.example.data.SearchFilter
import com.example.permissions.AllowAllFilesAccessDialog
import com.example.permissions.StoragePermissionHelper
import com.example.screens.ArchiveDetailScreen
import com.example.screens.ArchivesScreen
import com.example.screens.FilesScreen
import com.example.screens.HomeScreen
import com.example.screens.MainAppViewModel
import com.example.screens.SearchScreen
import com.example.screens.SettingsScreen
import com.example.screens.SplashScreen
import com.example.utils.FileCategory
import com.example.viewers.AudioPlayerScreen
import com.example.viewers.ImageViewerScreen
import com.example.viewers.PdfViewerScreen
import com.example.viewers.TextViewerScreen
import com.example.viewers.VideoPlayerScreen
import kotlinx.serialization.Serializable

@Serializable data object SplashRoute
@Serializable data object HomeRoute
@Serializable data class FilesRoute(val initialPath: String? = null)
@Serializable data object ArchivesRoute
@Serializable data object SettingsRoute
@Serializable data class SearchRoute(val filterName: String = SearchFilter.ALL.name)
@Serializable data class ArchiveDetailRoute(val archivePath: String)
@Serializable data class ImageViewerRoute(val filePath: String)
@Serializable data class VideoPlayerRoute(val filePath: String)
@Serializable data class AudioPlayerRoute(val filePath: String)
@Serializable data class TextViewerRoute(val filePath: String)
@Serializable data class PdfViewerRoute(val filePath: String)

@Composable
fun HzNavHost(sharedVm: MainAppViewModel) {
  val context = LocalContext.current
  val navController = rememberNavController()
  val snackbarHostState = remember { SnackbarHostState() }

  val showPermDialog by sharedVm.showPermissionPrompt.collectAsStateWithLifecycle()
  val opProgress by sharedVm.operationProgress.collectAsStateWithLifecycle()
  val backStackEntry by navController.currentBackStackEntryAsState()
  val destination = backStackEntry?.destination

  LaunchedEffect(sharedVm) {
    sharedVm.events.collect { msg ->
      snackbarHostState.showSnackbar(msg)
    }
  }

  fun openFileItem(item: FileItem) {
    when (item.category) {
      FileCategory.FOLDER -> navController.navigate(FilesRoute(item.path))
      FileCategory.IMAGE -> navController.navigate(ImageViewerRoute(item.path))
      FileCategory.VIDEO -> navController.navigate(VideoPlayerRoute(item.path))
      FileCategory.AUDIO -> navController.navigate(AudioPlayerRoute(item.path))
      FileCategory.PDF -> navController.navigate(PdfViewerRoute(item.path))
      FileCategory.TEXT -> navController.navigate(TextViewerRoute(item.path))
      FileCategory.ARCHIVE -> navController.navigate(ArchiveDetailRoute(item.path))
      else -> sharedVm.openWithExternal(item)
    }
  }

  val selectedTab = when {
    destination?.hasRoute<HomeRoute>() == true -> BottomNavTab.HOME
    destination?.hasRoute<FilesRoute>() == true -> BottomNavTab.FILES
    destination?.hasRoute<ArchivesRoute>() == true -> BottomNavTab.ARCHIVES
    destination?.hasRoute<SettingsRoute>() == true -> BottomNavTab.SETTINGS
    else -> null
  }

  if (showPermDialog && destination?.hasRoute<SplashRoute>() != true) {
    AllowAllFilesAccessDialog(
      onAllowAccess = {
        sharedVm.dismissPermissionDialog()
        StoragePermissionHelper.openAllFilesAccessSettings(context)
      },
      onDismiss = { sharedVm.dismissPermissionDialog() },
    )
  }

  opProgress?.let { progress ->
    OperationProgressOverlay(
      progress = progress,
      onCancel = { sharedVm.cancelActiveOperation() },
    )
  }

  LiquidGlassBackground {
    Box(modifier = Modifier.fillMaxSize()) {
      NavHost(
        navController = navController,
        startDestination = SplashRoute,
        enterTransition = { fadeIn(tween(240)) + slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Up, tween(240)) { it / 16 } },
        exitTransition = { fadeOut(tween(200)) },
        popEnterTransition = { fadeIn(tween(220)) },
        popExitTransition = { fadeOut(tween(200)) },
      ) {
        composable<SplashRoute> {
          SplashScreen(
            onSplashComplete = {
              navController.navigate(HomeRoute) {
                popUpTo<SplashRoute> { inclusive = true }
              }
            },
          )
        }

        composable<HomeRoute> {
          HomeScreen(
            sharedVm = sharedVm,
            onOpenFilesPath = { path ->
              navController.navigate(FilesRoute(path)) {
                popUpTo(navController.graph.findStartDestination().id) { saveState = false }
                launchSingleTop = true
              }
            },
            onOpenQuickCategory = { filter ->
              navController.navigate(SearchRoute(filter.name))
            },
            onOpenArchives = {
              navController.navigate(ArchivesRoute) {
                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true
                restoreState = true
              }
            },
            onOpenSearch = { navController.navigate(SearchRoute()) },
            onOpenSettings = {
              navController.navigate(SettingsRoute) {
                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                launchSingleTop = true
                restoreState = true
              }
            },
            onOpenFile = ::openFileItem,
          )
        }

        composable<FilesRoute> { entry ->
          val args = entry.toRoute<FilesRoute>()
          FilesScreen(
            sharedVm = sharedVm,
            initialPath = args.initialPath,
            onOpenSearch = { navController.navigate(SearchRoute()) },
            onOpenFile = ::openFileItem,
          )
        }

        composable<ArchivesRoute> {
          ArchivesScreen(
            sharedVm = sharedVm,
            onOpenArchiveDetail = { path -> navController.navigate(ArchiveDetailRoute(path)) },
            onOpenSearch = { navController.navigate(SearchRoute(SearchFilter.ARCHIVES.name)) },
          )
        }

        composable<SettingsRoute> {
          SettingsScreen(sharedVm = sharedVm)
        }

        composable<SearchRoute> { entry ->
          val args = entry.toRoute<SearchRoute>()
          val initialFilter = runCatching { SearchFilter.valueOf(args.filterName) }.getOrDefault(SearchFilter.ALL)
          SearchScreen(
            sharedVm = sharedVm,
            initialFilter = initialFilter,
            onBack = { navController.popBackStack() },
            onOpenFolder = { path ->
              navController.navigate(FilesRoute(path)) {
                popUpTo(navController.graph.findStartDestination().id)
              }
            },
            onOpenFile = ::openFileItem,
          )
        }

        composable<ArchiveDetailRoute> { entry ->
          val args = entry.toRoute<ArchiveDetailRoute>()
          ArchiveDetailScreen(
            archivePath = args.archivePath,
            sharedVm = sharedVm,
            onBack = { navController.popBackStack() },
          )
        }

        composable<ImageViewerRoute> { entry ->
          val args = entry.toRoute<ImageViewerRoute>()
          ImageViewerScreen(
            filePath = args.filePath,
            onBack = { navController.popBackStack() },
            onShare = { sharedVm.shareItems(listOf(it)) },
            onDelete = { item, onDeleted ->
              sharedVm.deleteItems(listOf(item)) { onDeleted() }
            },
          )
        }

        composable<VideoPlayerRoute> { entry ->
          val args = entry.toRoute<VideoPlayerRoute>()
          VideoPlayerScreen(
            filePath = args.filePath,
            onBack = { navController.popBackStack() },
            onShare = { sharedVm.shareItems(listOf(it)) },
          )
        }

        composable<AudioPlayerRoute> { entry ->
          val args = entry.toRoute<AudioPlayerRoute>()
          AudioPlayerScreen(
            filePath = args.filePath,
            onBack = { navController.popBackStack() },
            onShare = { sharedVm.shareItems(listOf(it)) },
          )
        }

        composable<TextViewerRoute> { entry ->
          val args = entry.toRoute<TextViewerRoute>()
          TextViewerScreen(
            filePath = args.filePath,
            onBack = { navController.popBackStack() },
            onShare = { sharedVm.shareItems(listOf(it)) },
          )
        }

        composable<PdfViewerRoute> { entry ->
          val args = entry.toRoute<PdfViewerRoute>()
          PdfViewerScreen(
            filePath = args.filePath,
            onBack = { navController.popBackStack() },
            onShare = { sharedVm.shareItems(listOf(it)) },
          )
        }
      }

      // Floating Liquid Glass Bottom Navigation Bar on top-level tabs
      if (selectedTab != null) {
        LiquidGlassFloatingNavBar(
          selectedTab = selectedTab,
          onSelectTab = { tab ->
            val route: Any = when (tab) {
              BottomNavTab.HOME -> HomeRoute
              BottomNavTab.FILES -> FilesRoute()
              BottomNavTab.ARCHIVES -> ArchivesRoute
              BottomNavTab.SETTINGS -> SettingsRoute
            }
            navController.navigate(route) {
              popUpTo(navController.graph.findStartDestination().id) {
                saveState = tab != BottomNavTab.FILES
              }
              launchSingleTop = true
              restoreState = tab != BottomNavTab.FILES
            }
          },
          modifier = Modifier.align(Alignment.BottomCenter),
        )
      }

      SnackbarHost(
        hostState = snackbarHostState,
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .navigationBarsPadding()
          .padding(bottom = if (selectedTab != null) 88.dp else 16.dp, start = 16.dp, end = 16.dp),
      )
    }
  }
}
