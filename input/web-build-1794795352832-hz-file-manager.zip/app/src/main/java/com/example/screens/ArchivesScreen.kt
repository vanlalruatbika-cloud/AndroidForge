package com.example.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.CheckBox
import androidx.compose.material.icons.filled.CheckBoxOutlineBlank
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.DriveFileRenameOutline
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderZip
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.InsertDriveFile
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.archive.ArchiveListingResult
import com.example.components.ConfirmDeleteDialog
import com.example.components.FileItemThumbnail
import com.example.components.FolderPickerDialog
import com.example.components.GlossyAccentButton
import com.example.components.InputNameDialog
import com.example.components.LiquidGlassBackground
import com.example.components.LiquidGlassCard
import com.example.data.ArchiveInfo
import com.example.data.FileItem
import com.example.ui.theme.CategoryArchiveTint
import com.example.ui.theme.DangerRed
import com.example.ui.theme.FolderGold
import com.example.ui.theme.LocalLiquidGlassPalette
import com.example.utils.FormatUtils
import java.io.File

@Composable
fun ArchivesScreen(
  sharedVm: MainAppViewModel,
  onOpenArchiveDetail: (String) -> Unit,
  onOpenSearch: () -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  val archives by sharedVm.discoveredArchives.collectAsStateWithLifecycle()
  val isLoading by sharedVm.archivesLoading.collectAsStateWithLifecycle()
  val settings by sharedVm.settings.collectAsStateWithLifecycle()

  var showCreateArchivePicker by remember { mutableStateOf(false) }
  var showExtractPicker by remember { mutableStateOf(false) }
  var extractTargetArchive by remember { mutableStateOf<FileItem?>(null) }
  var renameTarget by remember { mutableStateOf<FileItem?>(null) }
  var deleteTarget by remember { mutableStateOf<FileItem?>(null) }
  var infoTarget by remember { mutableStateOf<ArchiveInfo?>(null) }
  var pendingInspectPath by remember { mutableStateOf<String?>(null) }

  LaunchedEffect(pendingInspectPath) {
    val path = pendingInspectPath ?: return@LaunchedEffect
    when (val res = sharedVm.archiveRepository.inspectArchive(path)) {
      is ArchiveListingResult.Success -> infoTarget = res.info
      is ArchiveListingResult.Unsupported -> sharedVm.emitMessage(res.reason)
      is ArchiveListingResult.Error -> sharedVm.emitMessage(res.message)
    }
    pendingInspectPath = null
  }

  if (showCreateArchivePicker) {
    MultiSourceCompressDialog(
      rootPath = sharedVm.storageRepository.getPrimaryRootPath(),
      onDismiss = { showCreateArchivePicker = false },
      onCompress = { sources, outputPath, format ->
        showCreateArchivePicker = false
        sharedVm.compressToArchive(sources, outputPath, format) {
          sharedVm.refreshArchives()
        }
      },
    )
  }

  if (showExtractPicker) {
    ArchiveSelectDialog(
      archives = archives,
      onDismiss = { showExtractPicker = false },
      onSelect = { item ->
        showExtractPicker = false
        extractTargetArchive = item
      },
    )
  }

  extractTargetArchive?.let { item ->
    FolderPickerDialog(
      title = "Extract ${item.name} to",
      initialPath = item.file.parent ?: sharedVm.storageRepository.getPrimaryRootPath(),
      onDismiss = { extractTargetArchive = null },
      onSelectFolder = { dest ->
        extractTargetArchive = null
        sharedVm.extractArchiveTo(item.path, dest)
      },
    )
  }

  renameTarget?.let { item ->
    InputNameDialog(
      title = "Rename Archive",
      initialValue = item.name,
      placeholder = "Archive filename",
      confirmLabel = "Rename",
      onDismiss = { renameTarget = null },
      onConfirm = { newName, _ ->
        renameTarget = null
        sharedVm.renameItem(item, newName) { sharedVm.refreshArchives() }
      },
    )
  }

  deleteTarget?.let { item ->
    ConfirmDeleteDialog(
      items = listOf(item),
      onDismiss = { deleteTarget = null },
      onConfirm = {
        sharedVm.deleteItems(listOf(item)) { sharedVm.refreshArchives() }
      },
    )
  }

  infoTarget?.let { info ->
    ArchiveInfoDialog(info = info, onDismiss = { infoTarget = null })
  }

  Box(
    modifier = Modifier.fillMaxSize(),
    contentAlignment = Alignment.TopCenter,
  ) {
    LazyColumn(
      modifier = Modifier
        .widthIn(max = 640.dp)
        .fillMaxSize()
        .statusBarsPadding(),
      contentPadding = PaddingValues(start = 18.dp, end = 18.dp, top = 12.dp, bottom = 108.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
      // Header bar
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "Archive Manager",
            style = MaterialTheme.typography.headlineMedium,
            color = palette.textPrimary,
            modifier = Modifier.weight(1f),
          )
          IconButton(onClick = { sharedVm.refreshArchives() }) {
            Icon(Icons.Filled.Refresh, contentDescription = "Scan archives", tint = palette.textSecondary)
          }
          IconButton(onClick = onOpenSearch) {
            Icon(Icons.Filled.Search, contentDescription = "Search", tint = palette.textPrimary)
          }
        }
      }

      // Hero Glass Card matching reference panel 5
      item {
        LiquidGlassCard(
          elevated = true,
          shape = RoundedCornerShape(30.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(
            modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 8.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
          ) {
            Box(
              modifier = Modifier
                .size(88.dp)
                .shadow(14.dp, RoundedCornerShape(26.dp), ambientColor = palette.shadowColor)
                .clip(RoundedCornerShape(26.dp))
                .background(
                  Brush.linearGradient(
                    listOf(Color.White, palette.accent.softTint),
                  ),
                )
                .border(1.5.dp, palette.glassBorderTop, RoundedCornerShape(26.dp)),
              contentAlignment = Alignment.Center,
            ) {
              Icon(
                imageVector = Icons.Filled.FolderZip,
                contentDescription = "Archives",
                tint = CategoryArchiveTint,
                modifier = Modifier.size(48.dp),
              )
            }

            Spacer(modifier = Modifier.height(14.dp))
            Text(
              text = "ZIP, 7Z, TAR & RAR4",
              style = MaterialTheme.typography.titleLarge,
              color = palette.textPrimary,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = "Compress • Extract • Browse • Manage",
              style = MaterialTheme.typography.bodySmall,
              color = palette.textSecondary,
            )

            Spacer(modifier = Modifier.height(18.dp))

            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
              GlossyAccentButton(
                text = "Compress",
                icon = Icons.Filled.Add,
                onClick = { showCreateArchivePicker = true },
                modifier = Modifier
                  .weight(1f)
                  .testTag("archives_compress_button"),
              )
              GlossyAccentButton(
                text = "Extract",
                icon = Icons.Filled.Unarchive,
                isSecondary = true,
                onClick = {
                  if (archives.isEmpty()) {
                    sharedVm.emitMessage("No archive files found on storage.")
                  } else {
                    showExtractPicker = true
                  }
                },
                modifier = Modifier
                  .weight(1f)
                  .testTag("archives_extract_button"),
              )
            }
          }
        }
      }

      // Discovered Archives List Header
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = "Archives on Device",
            style = MaterialTheme.typography.titleLarge,
            color = palette.textPrimary,
          )
          Text(
            text = "${archives.size} archives",
            style = MaterialTheme.typography.labelMedium,
            color = palette.textSecondary,
          )
        }
      }

      if (isLoading && archives.isEmpty()) {
        item {
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .padding(24.dp),
            contentAlignment = Alignment.Center,
          ) {
            CircularProgressIndicator(color = palette.accent.primary)
          }
        }
      } else if (archives.isEmpty()) {
        item {
          LiquidGlassCard(shape = RoundedCornerShape(24.dp), modifier = Modifier.fillMaxWidth()) {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
            ) {
              Icon(
                imageVector = Icons.Filled.Archive,
                contentDescription = null,
                tint = palette.textMuted,
                modifier = Modifier.size(40.dp),
              )
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = "No archives found",
                style = MaterialTheme.typography.titleMedium,
                color = palette.textPrimary,
              )
              Text(
                text = "Tap Compress above to create a ZIP or 7Z archive.",
                style = MaterialTheme.typography.bodySmall,
                color = palette.textSecondary,
                textAlign = TextAlign.Center,
              )
            }
          }
        }
      } else {
        items(archives, key = { it.path }) { item ->
          var showMenu by remember { mutableStateOf(false) }
          LiquidGlassCard(
            shape = RoundedCornerShape(20.dp),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
            onClick = { onOpenArchiveDetail(item.path) },
            modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              FileItemThumbnail(item = item, size = 44.dp)
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = item.name,
                  style = MaterialTheme.typography.titleSmall,
                  color = palette.textPrimary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = "${FormatUtils.formatFileSize(item.sizeBytes)} • ${item.extension.uppercase()} • ${FormatUtils.formatDate(item.lastModified)}",
                  style = MaterialTheme.typography.bodySmall,
                  color = palette.textSecondary,
                )
              }

              Box {
                IconButton(onClick = { showMenu = true }) {
                  Icon(Icons.Filled.MoreVert, contentDescription = "Archive options", tint = palette.textSecondary)
                }
                DropdownMenu(expanded = showMenu, onDismissRequest = { showMenu = false }) {
                  DropdownMenuItem(
                    leadingIcon = { Icon(Icons.Filled.FolderZip, null) },
                    text = { Text("Browse Contents") },
                    onClick = { showMenu = false; onOpenArchiveDetail(item.path) },
                  )
                  DropdownMenuItem(
                    leadingIcon = { Icon(Icons.Filled.Unarchive, null) },
                    text = { Text("Extract Here") },
                    onClick = {
                      showMenu = false
                      val folderName = item.file.nameWithoutExtension
                      val dest = File(item.file.parentFile ?: File(sharedVm.storageRepository.getPrimaryRootPath()), folderName).absolutePath
                      sharedVm.extractArchiveTo(item.path, dest)
                    },
                  )
                  DropdownMenuItem(
                    leadingIcon = { Icon(Icons.Filled.Folder, null) },
                    text = { Text("Extract To...") },
                    onClick = { showMenu = false; extractTargetArchive = item },
                  )
                  DropdownMenuItem(
                    leadingIcon = { Icon(Icons.Filled.DriveFileRenameOutline, null) },
                    text = { Text("Rename") },
                    onClick = { showMenu = false; renameTarget = item },
                  )
                  DropdownMenuItem(
                    leadingIcon = { Icon(Icons.Filled.Info, null) },
                    text = { Text("Archive Info") },
                    onClick = { showMenu = false; pendingInspectPath = item.path },
                  )
                  DropdownMenuItem(
                    leadingIcon = { Icon(Icons.Filled.DeleteOutline, null, tint = DangerRed) },
                    text = { Text("Delete", color = DangerRed) },
                    onClick = {
                      showMenu = false
                      if (settings.confirmBeforeDelete) {
                        deleteTarget = item
                      } else {
                        sharedVm.deleteItems(listOf(item)) { sharedVm.refreshArchives() }
                      }
                    },
                  )
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun ArchiveDetailScreen(
  archivePath: String,
  sharedVm: MainAppViewModel,
  onBack: () -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  val archiveFile = remember(archivePath) { File(archivePath) }
  var listingResult by remember { mutableStateOf<ArchiveListingResult?>(null) }
  var selectedEntries by remember { mutableStateOf<Set<String>>(emptySet()) }
  var showDestPicker by remember { mutableStateOf(false) }
  var extractSelectedOnly by remember { mutableStateOf(false) }
  var showInfoDialog by remember { mutableStateOf(false) }

  LaunchedEffect(archivePath) {
    listingResult = sharedVm.archiveRepository.inspectArchive(archivePath)
  }

  val successState = listingResult as? ArchiveListingResult.Success

  if (showDestPicker) {
    FolderPickerDialog(
      title = if (extractSelectedOnly) "Extract ${selectedEntries.size} selected item(s) to" else "Extract all to",
      initialPath = archiveFile.parent ?: sharedVm.storageRepository.getPrimaryRootPath(),
      onDismiss = { showDestPicker = false },
      onSelectFolder = { dest ->
        showDestPicker = false
        sharedVm.extractArchiveTo(
          archivePath = archivePath,
          destDir = dest,
          selectedEntries = if (extractSelectedOnly) selectedEntries else null,
        )
      },
    )
  }

  if (showInfoDialog && successState != null) {
    ArchiveInfoDialog(info = successState.info, onDismiss = { showInfoDialog = false })
  }

  LiquidGlassBackground {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(horizontal = 16.dp, vertical = 10.dp),
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        IconButton(onClick = onBack) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = palette.textPrimary)
        }
        Column(modifier = Modifier.weight(1f)) {
          Text(
            text = archiveFile.name,
            style = MaterialTheme.typography.titleLarge,
            color = palette.textPrimary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
          )
          successState?.let {
            Text(
              text = "${it.info.format} • ${it.info.entryCount} entries • ${FormatUtils.formatFileSize(it.info.fileSizeBytes)}",
              style = MaterialTheme.typography.bodySmall,
              color = palette.textSecondary,
            )
          }
        }
        if (successState != null) {
          IconButton(onClick = { showInfoDialog = true }) {
            Icon(Icons.Filled.Info, contentDescription = "Archive info", tint = palette.textPrimary)
          }
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      when (val res = listingResult) {
        null -> {
          Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = palette.accent.primary)
          }
        }
        is ArchiveListingResult.Unsupported -> {
          Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            LiquidGlassCard(elevated = true, shape = RoundedCornerShape(28.dp)) {
              Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
              ) {
                Icon(Icons.Filled.WarningAmber, null, tint = DangerRed, modifier = Modifier.size(46.dp))
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                  text = "Unsupported Format (${res.format})",
                  style = MaterialTheme.typography.titleLarge,
                  color = palette.textPrimary,
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                  text = res.reason,
                  style = MaterialTheme.typography.bodyMedium,
                  color = palette.textSecondary,
                  textAlign = TextAlign.Center,
                )
                Spacer(modifier = Modifier.height(16.dp))
                GlossyAccentButton(text = "Go Back", onClick = onBack)
              }
            }
          }
        }
        is ArchiveListingResult.Error -> {
          Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            LiquidGlassCard(elevated = true, shape = RoundedCornerShape(28.dp)) {
              Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
              ) {
                Icon(Icons.Filled.WarningAmber, null, tint = DangerRed, modifier = Modifier.size(46.dp))
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                  text = res.message,
                  style = MaterialTheme.typography.bodyMedium,
                  color = palette.textPrimary,
                  textAlign = TextAlign.Center,
                )
                Spacer(modifier = Modifier.height(16.dp))
                GlossyAccentButton(text = "Go Back", onClick = onBack)
              }
            }
          }
        }
        is ArchiveListingResult.Success -> {
          LazyColumn(
            modifier = Modifier
              .fillMaxWidth()
              .weight(1f),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            contentPadding = PaddingValues(bottom = 12.dp),
          ) {
            items(res.entries, key = { it.fullPath }) { entry ->
              val isSelected = entry.fullPath in selectedEntries
              LiquidGlassCard(
                shape = RoundedCornerShape(18.dp),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                onClick = {
                  selectedEntries = if (isSelected) {
                    selectedEntries - entry.fullPath
                  } else {
                    selectedEntries + entry.fullPath
                  }
                },
              ) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Icon(
                    imageVector = if (isSelected) Icons.Filled.CheckBox else Icons.Filled.CheckBoxOutlineBlank,
                    contentDescription = null,
                    tint = if (isSelected) palette.accent.primary else palette.textMuted,
                    modifier = Modifier.size(22.dp),
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Icon(
                    imageVector = if (entry.isDirectory) Icons.Filled.Folder else Icons.Filled.InsertDriveFile,
                    contentDescription = null,
                    tint = if (entry.isDirectory) FolderGold else palette.accent.primary,
                    modifier = Modifier.size(22.dp),
                  )
                  Spacer(modifier = Modifier.width(10.dp))
                  Column(modifier = Modifier.weight(1f)) {
                    Text(
                      text = entry.fullPath.trimEnd('/'),
                      style = MaterialTheme.typography.bodyMedium,
                      fontWeight = FontWeight.Medium,
                      color = palette.textPrimary,
                      maxLines = 2,
                      overflow = TextOverflow.Ellipsis,
                    )
                    if (!entry.isDirectory) {
                      Text(
                        text = FormatUtils.formatFileSize(entry.uncompressedSize),
                        style = MaterialTheme.typography.bodySmall,
                        color = palette.textSecondary,
                      )
                    }
                  }
                }
              }
            }
          }

          Row(
            modifier = Modifier
              .fillMaxWidth()
              .padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            GlossyAccentButton(
              text = if (selectedEntries.isEmpty()) "Select Entries" else "Extract (${selectedEntries.size})",
              enabled = selectedEntries.isNotEmpty(),
              isSecondary = true,
              onClick = {
                extractSelectedOnly = true
                showDestPicker = true
              },
              modifier = Modifier.weight(1f),
            )
            GlossyAccentButton(
              text = "Extract All",
              icon = Icons.Filled.Unarchive,
              onClick = {
                extractSelectedOnly = false
                showDestPicker = true
              },
              modifier = Modifier.weight(1f),
            )
          }
        }
      }
    }
  }
}

@Composable
private fun ArchiveInfoDialog(
  info: ArchiveInfo,
  onDismiss: () -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  val ratio = if (info.uncompressedBytes > 0) {
    ((1.0 - (info.fileSizeBytes.toDouble() / info.uncompressedBytes.toDouble())) * 100.0).toInt().coerceIn(0, 99)
  } else {
    0
  }

  Dialog(onDismissRequest = onDismiss) {
    LiquidGlassCard(elevated = true, shape = RoundedCornerShape(26.dp)) {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text("Archive Info", style = MaterialTheme.typography.titleLarge, color = palette.textPrimary)
        Spacer(modifier = Modifier.height(10.dp))
        HorizontalDivider(color = palette.divider)
        Spacer(modifier = Modifier.height(10.dp))
        InfoRow("Name", info.name)
        InfoRow("Format", info.format)
        InfoRow("Entries", "${info.entryCount}")
        InfoRow("Archive Size", FormatUtils.formatFileSize(info.fileSizeBytes))
        InfoRow("Uncompressed Size", FormatUtils.formatFileSize(info.uncompressedBytes))
        InfoRow("Space Saved", "$ratio%")
        Spacer(modifier = Modifier.height(14.dp))
        GlossyAccentButton(text = "Close", onClick = onDismiss, modifier = Modifier.fillMaxWidth())
      }
    }
  }
}

@Composable
private fun InfoRow(label: String, value: String) {
  val palette = LocalLiquidGlassPalette.current
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .padding(vertical = 4.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
  ) {
    Text(label, style = MaterialTheme.typography.bodyMedium, color = palette.textSecondary)
    Text(value, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = palette.textPrimary)
  }
}

@Composable
private fun ArchiveSelectDialog(
  archives: List<FileItem>,
  onDismiss: () -> Unit,
  onSelect: (FileItem) -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  Dialog(onDismissRequest = onDismiss) {
    LiquidGlassCard(elevated = true, shape = RoundedCornerShape(26.dp)) {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text("Select Archive to Extract", style = MaterialTheme.typography.titleLarge, color = palette.textPrimary)
        Spacer(modifier = Modifier.height(10.dp))
        LazyColumn(modifier = Modifier.heightIn(max = 320.dp)) {
          items(archives, key = { it.path }) { item ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .clickable { onSelect(item) }
                .padding(horizontal = 8.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              FileItemThumbnail(item = item, size = 36.dp)
              Spacer(modifier = Modifier.width(10.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(item.name, style = MaterialTheme.typography.bodyMedium, color = palette.textPrimary, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(FormatUtils.formatFileSize(item.sizeBytes), style = MaterialTheme.typography.bodySmall, color = palette.textSecondary)
              }
            }
          }
        }
        Spacer(modifier = Modifier.height(10.dp))
        GlossyAccentButton(text = "Cancel", isSecondary = true, onClick = onDismiss, modifier = Modifier.fillMaxWidth())
      }
    }
  }
}

@Composable
private fun MultiSourceCompressDialog(
  rootPath: String,
  onDismiss: () -> Unit,
  onCompress: (sources: List<FileItem>, outputPath: String, format: String) -> Unit,
) {
  val palette = LocalLiquidGlassPalette.current
  var browsePath by remember { mutableStateOf(rootPath) }
  var selectedPaths by remember { mutableStateOf<Set<String>>(emptySet()) }
  var archiveName by remember { mutableStateOf("Huzuni_Backup") }
  var format by remember { mutableStateOf("ZIP") }

  val entries = remember(browsePath) {
    File(browsePath).listFiles()
      ?.filter { !it.name.startsWith(".") }
      ?.sortedWith(compareByDescending<File> { it.isDirectory }.thenBy { it.name.lowercase() })
      ?: emptyList()
  }

  Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
  ) {
    LiquidGlassCard(
      elevated = true,
      shape = RoundedCornerShape(28.dp),
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 18.dp),
    ) {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text("Create Archive", style = MaterialTheme.typography.titleLarge, color = palette.textPrimary)
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "Select files or folders from $browsePath",
          style = MaterialTheme.typography.bodySmall,
          color = palette.textSecondary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
        )
        Spacer(modifier = Modifier.height(8.dp))

        val parent = File(browsePath).parentFile
        if (parent != null && parent.canRead() && browsePath != rootPath) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(10.dp))
              .clickable { browsePath = parent.absolutePath }
              .padding(6.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(Icons.Filled.ArrowUpward, null, tint = palette.accent.primary, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(".. (Up)", style = MaterialTheme.typography.bodySmall, color = palette.accent.primary)
          }
        }

        LazyColumn(
          modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = 140.dp, max = 220.dp)
            .border(1.dp, palette.divider, RoundedCornerShape(14.dp))
            .padding(4.dp),
        ) {
          items(entries, key = { it.absolutePath }) { file ->
            val checked = file.absolutePath in selectedPaths
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .clickable {
                  if (file.isDirectory && !checked) {
                    selectedPaths = selectedPaths + file.absolutePath
                  } else {
                    selectedPaths = if (checked) selectedPaths - file.absolutePath else selectedPaths + file.absolutePath
                  }
                }
                .padding(horizontal = 6.dp, vertical = 7.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = if (checked) Icons.Filled.CheckBox else Icons.Filled.CheckBoxOutlineBlank,
                contentDescription = null,
                tint = if (checked) palette.accent.primary else palette.textMuted,
                modifier = Modifier.size(20.dp),
              )
              Spacer(modifier = Modifier.width(8.dp))
              Icon(
                imageVector = if (file.isDirectory) Icons.Filled.Folder else Icons.Filled.InsertDriveFile,
                contentDescription = null,
                tint = if (file.isDirectory) FolderGold else palette.accent.primary,
                modifier = Modifier.size(20.dp),
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = file.name,
                style = MaterialTheme.typography.bodyMedium,
                color = palette.textPrimary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
              )
              if (file.isDirectory) {
                Text(
                  text = "Open",
                  style = MaterialTheme.typography.labelSmall,
                  color = palette.accent.primary,
                  modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { browsePath = file.absolutePath }
                    .padding(horizontal = 6.dp, vertical = 2.dp),
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
          value = archiveName,
          onValueChange = { archiveName = it },
          singleLine = true,
          label = { Text("Archive name") },
          modifier = Modifier.fillMaxWidth(),
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
          listOf("ZIP", "7Z").forEach { fmt ->
            Row(
              modifier = Modifier
                .clip(RoundedCornerShape(10.dp))
                .clickable { format = fmt }
                .padding(end = 12.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              RadioButton(selected = format == fmt, onClick = { format = fmt })
              Text(fmt, style = MaterialTheme.typography.bodyMedium, color = palette.textPrimary)
            }
          }
        }
        Spacer(modifier = Modifier.height(10.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          GlossyAccentButton(
            text = "Cancel",
            isSecondary = true,
            onClick = onDismiss,
            modifier = Modifier.weight(1f),
          )
          GlossyAccentButton(
            text = "Compress (${selectedPaths.size})",
            enabled = selectedPaths.isNotEmpty() && archiveName.trim().isNotEmpty(),
            onClick = {
              val ext = if (format == "7Z") "7z" else "zip"
              val clean = archiveName.trim().let { if (it.endsWith(".$ext", true)) it else "$it.$ext" }
              val outPath = File(browsePath, clean).absolutePath
              val items = selectedPaths.map { path ->
                val f = File(path)
                FileItem(
                  path = f.absolutePath,
                  name = f.name,
                  isDirectory = f.isDirectory,
                  sizeBytes = f.length(),
                  lastModified = f.lastModified(),
                  category = FormatUtils.classifyFile(f),
                  extension = FormatUtils.getExtension(f.name),
                )
              }
              onCompress(items, outPath, format)
            },
            modifier = Modifier.weight(1f),
          )
        }
      }
    }
  }
}
