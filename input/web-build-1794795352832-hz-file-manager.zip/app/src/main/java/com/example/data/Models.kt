package com.example.data

import com.example.utils.FileCategory
import java.io.File

enum class SortField(val label: String) {
  NAME("Name"),
  SIZE("Size"),
  DATE("Date"),
  TYPE("Type"),
}

enum class SortDirection(val label: String) {
  ASCENDING("Ascending"),
  DESCENDING("Descending"),
}

enum class ViewMode(val label: String) {
  LIST("List"),
  GRID("Grid"),
}

enum class ClipboardMode {
  COPY,
  MOVE,
}

data class ClipboardState(
  val files: List<FileItem> = emptyList(),
  val mode: ClipboardMode = ClipboardMode.COPY,
) {
  val isEmpty: Boolean get() = files.isEmpty()
  val count: Int get() = files.size
}

data class FileItem(
  val path: String,
  val name: String,
  val isDirectory: Boolean,
  val sizeBytes: Long,
  val lastModified: Long,
  val category: FileCategory,
  val extension: String,
  val childCount: Int = 0,
  val isHidden: Boolean = false,
  val canRead: Boolean = true,
  val canWrite: Boolean = true,
) {
  val file: File get() = File(path)
}

data class StorageVolumeInfo(
  val id: String,
  val name: String,
  val rootPath: String,
  val totalBytes: Long,
  val availableBytes: Long,
  val usedBytes: Long,
  val isPrimary: Boolean,
  val isRemovable: Boolean,
) {
  val usedPercent: Float
    get() = if (totalBytes > 0) (usedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f) else 0f
}

data class StorageCategorySlice(
  val label: String,
  val bytes: Long,
  val count: Int,
)

data class StorageOverviewState(
  val volumes: List<StorageVolumeInfo> = emptyList(),
  val primaryVolume: StorageVolumeInfo? = null,
  val categories: List<StorageCategorySlice> = emptyList(),
  val recentFiles: List<FileItem> = emptyList(),
  val isLoading: Boolean = false,
)

data class OperationProgress(
  val title: String,
  val currentItem: String,
  val completedCount: Int,
  val totalCount: Int,
  val fraction: Float,
)

data class ArchiveEntryItem(
  val fullPath: String,
  val name: String,
  val isDirectory: Boolean,
  val compressedSize: Long,
  val uncompressedSize: Long,
  val lastModified: Long,
)

data class ArchiveInfo(
  val path: String,
  val name: String,
  val format: String,
  val fileSizeBytes: Long,
  val uncompressedBytes: Long,
  val entryCount: Int,
  val isSupported: Boolean,
  val note: String? = null,
)

enum class SearchFilter(val label: String) {
  ALL("All"),
  FOLDERS("Folders"),
  IMAGES("Images"),
  VIDEOS("Videos"),
  AUDIO("Audio"),
  DOCUMENTS("Docs"),
  ARCHIVES("Archives"),
  APKS("APKs"),
}
